import 'package:flutter/material.dart';
import 'package:flutter_native_splash/flutter_native_splash.dart';
import 'package:get/get.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'src/core/theme/app_theme.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/screens/splash_screen.dart';

void main() async {
  await _initializeApp();
  WidgetsFlutterBinding.ensureInitialized();
  // await dotenv.load(fileName: '.env');

  //Debugging for Shared Pref
  try {
    final prefs = await SharedPreferences.getInstance();
    print("SharedPreferences initialized successfully!");
  } catch (e) {
    print("Error initializing SharedPreferences: $e");
  }

  runApp(const MyApp());
  FlutterNativeSplash.remove();
}

Future<void> _initializeApp() async {
  WidgetsBinding widgetsBinding = WidgetsFlutterBinding.ensureInitialized();
  FlutterNativeSplash.preserve(widgetsBinding: widgetsBinding);
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      defaultTransition: Transition.rightToLeft,
      title: 'Stayfinder',
      theme: AppTheme.lightTheme(),
      themeMode: ThemeMode.light,
      home: const SplashScreen(),
    );
  }
}
