import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class DividerSpacer extends StatelessWidget {
  const DividerSpacer({super.key});

  @override
  Widget build(BuildContext context) {
    return const Column(
      children: [
        Gap(12),
        Divider(),
        Gap(12),
      ],
    );
  }
}
