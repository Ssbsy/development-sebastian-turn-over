import 'package:flutter/material.dart';

// Color Palettes

class AppColors {
  static const transparent = Colors.transparent;
  static const white = Color(0xFFFFFFFF);
  static const black = Color(0xFF0A0A0A);
  static const green = Color(0xFF20653D);
  static const gray = Color(0xFF232323);
  static const red = Color(0xFFEC1C24);
  static const yellow = Color(0xFFFFD666);
}
