// app_theme.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../constants/colors.dart';

class AppTheme {
  static ThemeData lightTheme() {
    SystemChrome.setPreferredOrientations(
      [
        DeviceOrientation.portraitUp,
        DeviceOrientation.portraitDown,
      ],
    );

    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: AppColors.transparent,
        statusBarIconBrightness: Brightness.light,
        systemNavigationBarColor: AppColors.white,
        systemNavigationBarIconBrightness: Brightness.light,
      ),
    );

    return ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: AppColors.white,
      dialogTheme: DialogTheme(
        shape: RoundedRectangleBorder(
          side: BorderSide(
            color: AppColors.black.withOpacity(0.5),
          ),
          borderRadius: BorderRadius.circular(8),
        ),
        elevation: 0,
        backgroundColor: AppColors.white,
      ),
      bottomSheetTheme: const BottomSheetThemeData(
        showDragHandle: true,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(8),
            topRight: Radius.circular(8),
          ),
        ),
      ),
      textButtonTheme: const TextButtonThemeData(
        style: ButtonStyle(
          overlayColor: WidgetStatePropertyAll(AppColors.transparent),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          overlayColor: AppColors.transparent,
        ),
      ),
      floatingActionButtonTheme: FloatingActionButtonThemeData(
        elevation: 0,
        hoverElevation: 0,
        focusElevation: 0,
        backgroundColor: AppColors.green,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(40),
        ),
      ),
      tabBarTheme: TabBarTheme(
        unselectedLabelStyle: GoogleFonts.poppins(
          fontSize: 12,
        ),
        labelStyle: GoogleFonts.poppins(
          fontSize: 12,
        ),
        tabAlignment: TabAlignment.start,
        indicatorSize: TabBarIndicatorSize.tab,
        indicatorColor: AppColors.green,
        labelColor: AppColors.green,
        unselectedLabelColor: AppColors.black,
      ),
      datePickerTheme: DatePickerThemeData(
        backgroundColor: AppColors.transparent,
        weekdayStyle: GoogleFonts.poppins(),
        dayStyle: GoogleFonts.poppins(
          color: AppColors.white,
          fontWeight: FontWeight.w600,
        ),
        yearStyle: GoogleFonts.poppins(),
        headerHelpStyle: GoogleFonts.poppins(),
        rangePickerHeaderHeadlineStyle: GoogleFonts.poppins(),
        todayBackgroundColor: const WidgetStatePropertyAll(AppColors.green),
      ),
      primaryColor: AppColors.green,
      appBarTheme: const AppBarTheme(
        iconTheme: IconThemeData(color: AppColors.green),
        backgroundColor: AppColors.transparent,
        centerTitle: true,
      ),
    );
  }
}
