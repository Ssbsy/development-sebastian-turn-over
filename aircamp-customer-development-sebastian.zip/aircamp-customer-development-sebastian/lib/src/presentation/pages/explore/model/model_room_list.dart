class RoomList {
  final String listingId;
  final String image;
  final String name;
  final String location;
  final String dates;
  final double price;
  final double rating;

  RoomList({
    required this.listingId,
    required this.image,
    required this.name,
    required this.location,
    required this.dates,
    required this.price,
    required this.rating,
  });

  // Factory constructor to create a Hotel instance from a Map (useful for parsing data)
  factory RoomList.fromMap(Map<String, dynamic> map) {
    return RoomList(
      listingId: map['id'] ?? '',
      image: (map['listingImages'] != null && map['listingImages'].isNotEmpty)
          ? map['listingImages'][0]['image'] ?? ''
          : '',
      name: map['name'] ?? 'Unknown',
      location: '${map['address_country'] ?? ''}, ${map['address_city'] ?? ''}',
      dates: map['dates'] ?? '',
      price: double.tryParse(map['price']?.toString() ?? '0') ?? 0.0,
      rating: double.tryParse(map['averageRating']?.toString() ?? '0') ?? 0.0,
    );
  }

  // Method to convert Hotel instance back to Map (useful for serialization)
  Map<String, dynamic> toMap() {
    return {
      'listing_id': listingId,
      'image': image,
      'name': name,
      'location': location,
      'dates': dates,
      'price': price,
      'rating': rating,
    };
  }
}
