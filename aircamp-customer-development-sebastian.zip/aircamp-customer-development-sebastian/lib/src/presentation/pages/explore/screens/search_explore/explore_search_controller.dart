import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/screens/tabs/stays_tab.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class ExploreSearchController extends StatefulWidget {
  const ExploreSearchController({super.key});

  @override
  State<ExploreSearchController> createState() =>
      _ExploreSearchControllerState();
}

class _ExploreSearchControllerState extends State<ExploreSearchController> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          bottom: TabBar(
            tabAlignment: TabAlignment.fill,
            indicatorSize: TabBarIndicatorSize.label,
            unselectedLabelStyle: GoogleFonts.poppins(
              fontSize: 16,
              fontWeight: FontWeight.w400,
            ),
            labelStyle: GoogleFonts.poppins(
              fontSize: 16,
              fontWeight: FontWeight.w700,
            ),
            labelPadding: const EdgeInsets.all(8),
            tabs: const [
              Text('Stays'),
              Text('Experiences'),
            ],
          ),
        ),
        body: const TabBarView(
          physics: NeverScrollableScrollPhysics(),
          children: [
            StaysTab(),
            Center(child: Text('Experiences')),
          ],
        ),
      ),
    );
  }
}
