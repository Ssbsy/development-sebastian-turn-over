import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/screens/booking_process/booking_infos/cancellation_rules_info.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/screens/booking_process/booking_infos/payment_form_info.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/screens/booking_process/booking_infos/price_details_info.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/screens/booking_process/booking_infos/reservetion_req_info.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/screens/booking_process/booking_infos/room_details_info.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/screens/booking_process/booking_infos/your_reservation_info.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_button.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class PaymentMethod extends StatefulWidget {
  const PaymentMethod({super.key});

  @override
  State<PaymentMethod> createState() => _PaymentMethodState();
}

class _PaymentMethodState extends State<PaymentMethod> {
  void book() async {}
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        forceMaterialTransparency: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            const Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    YourReservationInfo(),
                    Gap(24),
                    PaymentFormInfo(),
                    Gap(24),
                    ReservetionReqInfo(),
                    Gap(24),
                    CancellationRulesInfo(),
                    Gap(24),
                    RoomDetailsInfo(),
                    Gap(24),
                    PriceDetailsInfo(),
                    Gap(24),
                  ],
                ),
              ),
            ),
            WidgetButton(
              text: 'Request to Book',
              borderRadius: 50,
              onPressed: () {},
            ),
          ],
        ),
      ),
    );
  }
}
