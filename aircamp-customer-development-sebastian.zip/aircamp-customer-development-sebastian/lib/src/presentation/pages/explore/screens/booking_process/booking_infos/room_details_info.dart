import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class RoomDetailsInfo extends StatefulWidget {
  const RoomDetailsInfo({super.key});

  @override
  State<RoomDetailsInfo> createState() => _RoomDetailsInfoState();
}

class _RoomDetailsInfoState extends State<RoomDetailsInfo> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const WidgetText(
          text: 'Room Details',
          color: AppColors.green,
          fontSize: 16,
          fontWeight: FontWeight.w600,
        ),
        const Gap(12),
        Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.asset(
                'assets/images/hotel_room_1.jpg',
                height: 60,
                width: 60,
                fit: BoxFit.cover,
              ),
            ),
            const Gap(8),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                WidgetText(
                  text: 'Hotel Room One',
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
                Row(
                  children: [
                    Icon(Icons.star, color: AppColors.yellow),
                    Gap(8),
                    WidgetText(
                      text: '5.0',
                      fontSize: 12,
                      fontWeight: FontWeight.w400,
                    ),
                  ],
                ),
                WidgetText(
                  text: 'Host: Juan Dela Cruz',
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                ),
              ],
            ),
          ],
        ),
      ],
    );
  }
}