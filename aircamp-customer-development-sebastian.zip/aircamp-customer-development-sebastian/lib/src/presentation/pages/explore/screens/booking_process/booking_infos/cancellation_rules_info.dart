import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';

class CancellationRulesInfo extends StatefulWidget {
  const CancellationRulesInfo({super.key});

  @override
  State<CancellationRulesInfo> createState() => _CancellationRulesInfoState();
}

class _CancellationRulesInfoState extends State<CancellationRulesInfo> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const WidgetText(
          text: 'Cancellation Rules',
          color: AppColors.green,
          fontSize: 16,
          fontWeight: FontWeight.w600,
        ),
        const Gap(12),
        const WidgetText(
          text:
              'Cancel before Jan 8 for a partial refund. After that, this reservation is non-refundable. Learn more about the rules',
          fontSize: 14,
          fontWeight: FontWeight.w400,
        ),
        const Gap(12),
        Row(
          children: [
            Image.asset(
              'assets/icons/ic_charge.png',
              height: 50,
            ),
            const Gap(12),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  WidgetText(
                    text:
                        'The reservation won’t be confirmed until the Host accept your request.',
                    color: AppColors.green,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                  WidgetText(
                    text: 'You won’t be charged until then.',
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                  ),
                ],
              ),
            ),
          ],
        ),
        const Gap(12),
        RichText(
          text: TextSpan(
            style: GoogleFonts.poppins(
              fontSize: 12,
              fontWeight: FontWeight.w400,
              color: Colors.black,
            ),
            children: <TextSpan>[
              const TextSpan(
                text:
                    'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\n',
              ),
              const TextSpan(
                text: 'Agree the ',
              ),
              TextSpan(
                text: 'Terms and Conditions, and Policies',
                style: GoogleFonts.poppins(
                  fontSize: 12,
                  fontWeight: FontWeight.w400,
                  color: Colors.blue,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
