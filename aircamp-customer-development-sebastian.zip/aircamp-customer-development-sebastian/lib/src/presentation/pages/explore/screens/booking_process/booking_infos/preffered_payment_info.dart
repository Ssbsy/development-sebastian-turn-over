import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class PrefferedPaymentInfo extends StatefulWidget {
  const PrefferedPaymentInfo({super.key});

  @override
  State<PrefferedPaymentInfo> createState() => _PrefferedPaymentInfoState();
}

class _PrefferedPaymentInfoState extends State<PrefferedPaymentInfo> {
  @override
  Widget build(BuildContext context) {
    return const Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        WidgetText(
          text: 'Preferred Payment',
          color: AppColors.green,
          fontSize: 16,
          fontWeight: FontWeight.w600,
        ),
        Gap(12),
        Row(
          children: [
            Radio.adaptive(
              value: false,
              groupValue: null,
              onChanged: null,
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                WidgetText(
                  text: 'Pay Now',
                  fontSize: 12,
                  fontWeight: FontWeight.w400,
                ),
                WidgetText(
                  text: '₱ 3000.00 now',
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ],
            ),
          ],
        ),
        Row(
          children: [
            Radio.adaptive(
              value: false,
              groupValue: null,
              onChanged: null,
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                WidgetText(
                  text: 'Installment Only',
                  fontSize: 12,
                  fontWeight: FontWeight.w400,
                ),
                WidgetText(
                  text: '₱ 1500.00 now, and ₱ 1500.00 later. ',
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ],
            ),
          ],
        ),
      ],
    );
  }
}
