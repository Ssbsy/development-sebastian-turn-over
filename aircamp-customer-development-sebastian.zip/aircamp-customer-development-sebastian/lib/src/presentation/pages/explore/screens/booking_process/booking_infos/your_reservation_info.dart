import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/widgets/widget_row_textbutton.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class YourReservationInfo extends StatefulWidget {
  const YourReservationInfo({super.key});

  @override
  State<YourReservationInfo> createState() => _YourReservationInfoState();
}

class _YourReservationInfoState extends State<YourReservationInfo> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const WidgetText(
          text: 'Your Reservation',
          color: AppColors.green,
          fontSize: 16,
          fontWeight: FontWeight.w600,
        ),
        const Gap(12),
        WidgetRowTextbutton(
          leadingText: 'Date',
          trailingText: '30 December 2024 - 31 December 2024',
          onPressed: () {},
        ),
        WidgetRowTextbutton(
          leadingText: 'Travelers',
          trailingText: '2 Travelers Only',
          onPressed: () {},
        ),
      ],
    );
  }
}
