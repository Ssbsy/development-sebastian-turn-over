import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/core/constants/divider_spacer.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/screens/booking_process/booking_room_details_page.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/screens/view/view_staggered_room_gallery.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/widgets/widget_circle_icon_button.dart';
import 'package:airbnb_stayfinder_mobile/src/services/base_api_services.dart';
import 'package:airbnb_stayfinder_mobile/src/services/get_listing_by_id_services.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_button.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';

class ViewRoomDetails extends StatefulWidget {
  final String listingId;
  const ViewRoomDetails({super.key, required this.listingId});

  @override
  State<ViewRoomDetails> createState() => _ViewRoomDetailsState();
}

Widget _roomDetails(
    String? hotelName, String? rate, String? review, String? location) {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      _textWidget(hotelName, 20, FontWeight.w400),
      Row(
        children: [
          const Icon(Icons.star, color: AppColors.yellow),
          const Gap(8),
          _textWidget('${rate!} • ${review!}', 14, FontWeight.w400),
        ],
      ),
      _textWidget(location, 14, FontWeight.w400, color: AppColors.green),
    ],
  );
}

Widget _descriptionShowBtn(
    String? headerText, String? descriptionText, VoidCallback? onPressed) {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      if (headerText != null) _textWidget(headerText, 24, FontWeight.w600),
      _textWidget(descriptionText ?? '', 14, FontWeight.w400, opacity: 0.5),
      TextButton(
          onPressed: onPressed,
          child: _textWidget(
            'Show more >',
            14,
            FontWeight.w500,
          )),
    ],
  );
}

Widget _hostDetails(String? title, String? subTitle, String? imageAsset) {
  return Row(
    children: [
      Expanded(
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _textWidget(title, 22, FontWeight.w600),
        _textWidget(subTitle, 16, FontWeight.w400),
      ])),
      const Gap(12),
      CircleAvatar(radius: 25, backgroundImage: AssetImage(imageAsset!)),
    ],
  );
}

Widget _scrollContainer() {
  final thingsToKnow = {
    'Check-in': 'after 1:00 P.M',
    'Check-out': 'before 11:00 A.M',
    'Pets': 'No pets allowed',
    'Smoking': 'No smoking indoors',
  };
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      _textWidget('Things you need to know', 22, FontWeight.w600),
      const Gap(8),
      SizedBox(
        height: 80,
        child: ListView.builder(
          shrinkWrap: true,
          scrollDirection: Axis.horizontal,
          itemCount: thingsToKnow.length,
          itemBuilder: (context, index) {
            final key = thingsToKnow.keys.elementAt(index);
            final value = thingsToKnow[key]!;
            return Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                height: 80,
                width: 150,
                decoration: BoxDecoration(
                  border: Border.all(color: AppColors.gray.withOpacity(0.2)),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _textWidget(key, 14, FontWeight.w600),
                      _textWidget(value, 12, FontWeight.w400, opacity: 0.5),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    ],
  );
}

Widget _roomAmenities() {
  final offers = [
    {'icon': Icons.lock_outline, 'text': 'Lock on bedroom door'},
    {'icon': Icons.work_outline, 'text': 'Dedicated workspace'},
    {'icon': Icons.wifi_outlined, 'text': 'Wifi'},
    {'icon': Icons.landscape_outlined, 'text': 'City skyline view'},
    {'icon': Icons.security_outlined, 'text': 'Security cameras on property'},
    {'icon': Icons.smoke_free_outlined, 'text': 'Carbon monoxide alarm'},
  ];
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      _textWidget('What this place offers', 22, FontWeight.w600),
      ListView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: offers.length,
        itemBuilder: (context, index) {
          final offer = offers[index];
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Icon(offer['icon'] as IconData?, color: AppColors.black),
                const Gap(8),
                _textWidget(offer['text'] as String?, 12, FontWeight.w400),
              ],
            ),
          );
        },
      ),
      WidgetButton(
        backgroundColor: AppColors.white,
        borderColor: AppColors.black.withOpacity(0.5),
        borderRadius: 8,
        text: 'Show all 28 amenities',
        textColor: AppColors.black,
        fontWeight: FontWeight.w600,
        onPressed: () {},
      ),
    ],
  );
}

Widget _locationDescription(String? descriptionText, VoidCallback? onPressed) {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      _textWidget("Where you'll be", 22, FontWeight.w600),
      Container(
          height: 280,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(8))),
      _textWidget(descriptionText, 14, FontWeight.w400),
      TextButton(
          onPressed: onPressed,
          child: _textWidget('Show more >', 14, FontWeight.w500)),
    ],
  );
}

Widget _descriptionForwardBtn(
    String? titleText, String? descriptionText, VoidCallback? onTap) {
  return GestureDetector(
    onTap: onTap,
    child: Row(
      children: [
        Expanded(
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _textWidget(titleText, 22, FontWeight.w600),
          _textWidget(descriptionText, 14, FontWeight.w400, opacity: 0.5),
        ])),
        const Gap(12),
        const Icon(Icons.arrow_forward_ios, color: AppColors.black, size: 14),
      ],
    ),
  );
}

Widget _textWidget(String? text, double fontSize, FontWeight fontWeight,
    {Color color = AppColors.black, double opacity = 1.0}) {
  return WidgetText(
    text: text ?? '',
    color: color.withOpacity(opacity),
    fontSize: fontSize,
    fontWeight: fontWeight,
  );
}

class _ViewRoomDetailsState extends State<ViewRoomDetails> {
  bool isLoading = false;
  Map<dynamic, dynamic>? listingDetails;

  GetListingByIdServices getListingById =
      GetListingByIdServices(BaseApiServices());

  void getListingByIdMethod() async {
    print("Fetching listing with ID: ${widget.listingId}");
    setState(() => isLoading = true);
    FocusScope.of(context).unfocus();

    try {
      final response = await getListingById.getListingId(widget.listingId);

      print("Response received: $response");

      if (response is Map<String, dynamic> &&
          response.containsKey("success") &&
          response["success"] == true) {
        print("Get listing successful.");
        setState(() => listingDetails = response);
      } else {
        print("Get listing failed: ${response['message']}");
      }
    } catch (e) {
      print("Exception caught: $e");
    } finally {
      setState(() => isLoading = false);
    }
  }

  @override
  void initState() {
    super.initState();
    print("ViewRoomLists initState called");
    WidgetsBinding.instance.addPostFrameCallback((_) {
      getListingByIdMethod();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : listingDetails == null
              ? const Center(child: Text("No data available"))
              : SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      GestureDetector(
                        onTap: () {
                          Get.to(() => const ViewStaggeredRoomGallery());
                        },
                        child: Stack(
                          children: [
                            Image.network(listingDetails?['imageUrl'] ??
                                'https://picsum.photos/400'),
                            AppBar(
                              leading: WidgetCircleIconButton(
                                  icon: Icons.arrow_back,
                                  onPressed: () => Get.back()),
                              actions: [
                                WidgetCircleIconButton(
                                    icon: Icons.upload_outlined,
                                    onPressed: () {}),
                                WidgetCircleIconButton(
                                    icon: Icons.favorite_border_outlined,
                                    onPressed: () {}),
                              ],
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _roomDetails(
                                listingDetails?['hotelName'] ?? 'Hotel Name',
                                listingDetails?['rating']?.toString() ?? '0.0',
                                listingDetails?['reviewsCount']?.toString() ??
                                    '0 Reviews',
                                listingDetails?['location'] ??
                                    'Unknown Location'),
                            const DividerSpacer(),
                            _hostDetails(
                                listingDetails?['hostName'] ?? 'Unknown Host',
                                listingDetails?['hostInfo'] ?? 'Host Details',
                                listingDetails?['hostImage'] ??
                                    'assets/icons/ai_profile.jpg'),
                            const DividerSpacer(),
                            _descriptionShowBtn(
                                null, listingDetails?['description'] ?? '', () {
                              _showReadMore(context);
                            }),
                            const DividerSpacer(),
                            _scrollContainer(),
                            const DividerSpacer(),
                            _roomAmenities(),
                            const DividerSpacer(),
                            _locationDescription(
                                listingDetails?['locationDetails'] ?? '',
                                () {}),
                            const DividerSpacer(),
                            _descriptionForwardBtn(
                                'Availability',
                                listingDetails?['availability'] ?? 'N/A',
                                () {}),
                            const DividerSpacer(),
                            _descriptionForwardBtn(
                                'Cancellation Policy',
                                listingDetails?['cancellationPolicy'] ?? 'N/A',
                                () {}),
                            const DividerSpacer(),
                            _descriptionShowBtn('House Rules',
                                listingDetails?['houseRules'] ?? 'N/A', () {}),
                            const DividerSpacer(),
                            _descriptionShowBtn('Safety & property',
                                listingDetails?['safetyInfo'] ?? 'N/A', () {}),
                            const DividerSpacer(),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: WidgetButton(
                                text: 'Reserve',
                                fontSize: 16,
                                backgroundColor: AppColors.green,
                                borderRadius: 25,
                                onPressed: () {
                                  Get.to(() => BookingRoomDetails(
                                      room: listingDetails?['room']));
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
    );
  }

  void _showReadMore(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: SizedBox(
            width: MediaQuery.sizeOf(context).width,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _textWidget('About this Place', 26, FontWeight.w600),
                _textWidget(
                    'Enjoy an elegant private room of 20 m2 in a renovated apartment of 160 m2 in the heart of the city center of Nantes in the Graslin district.',
                    12,
                    FontWeight.w400),
              ],
            ),
          ),
        );
      },
    );
  }
}
