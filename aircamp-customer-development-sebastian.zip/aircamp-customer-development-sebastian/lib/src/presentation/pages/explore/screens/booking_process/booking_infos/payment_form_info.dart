import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_textfield.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class PaymentFormInfo extends StatefulWidget {
  const PaymentFormInfo({super.key});

  @override
  State<PaymentFormInfo> createState() => _PaymentFormInfoState();
}

class _PaymentFormInfoState extends State<PaymentFormInfo> {
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          WidgetText(
            text: 'Payment Method',
            color: AppColors.green,
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
          Gap(12),
          WidgetTextField(
            fillColor: AppColors.white,
            enabled: true,
            hintText: 'Debit/Credit Card',
            borderRadius: 50,
            borderColor: AppColors.black,
          ),
          Gap(12),
          WidgetTextField(
            fillColor: AppColors.white,
            enabled: true,
            hintText: 'Card Number',
            borderRadius: 50,
            borderColor: AppColors.black,
          ),
          Gap(12),
          Row(
            children: [
              Expanded(
                child: WidgetTextField(
                  fillColor: AppColors.white,
                  enabled: true,
                  hintText: 'Expiration',
                  borderRadius: 50,
                  borderColor: AppColors.black,
                ),
              ),
              Gap(12),
              Expanded(
                child: WidgetTextField(
                  fillColor: AppColors.white,
                  enabled: true,
                  hintText: 'CVV',
                  borderRadius: 50,
                  borderColor: AppColors.black,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
