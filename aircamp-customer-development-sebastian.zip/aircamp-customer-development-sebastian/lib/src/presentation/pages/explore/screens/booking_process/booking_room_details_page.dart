import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/screens/booking_process/payment_method_page.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/screens/booking_process/booking_infos/preffered_payment_info.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/screens/booking_process/booking_infos/price_details_info.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/screens/booking_process/booking_infos/room_details_info.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/screens/booking_process/booking_infos/your_reservation_info.dart';
import 'package:airbnb_stayfinder_mobile/src/services/booking_services.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_button.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';

class BookingRoomDetails extends StatefulWidget {
  final dynamic room;
  const BookingRoomDetails({super.key, required this.room});

  @override
  State<BookingRoomDetails> createState() => _BookingRoomDetailsState();
}

class _BookingRoomDetailsState extends State<BookingRoomDetails> {
  void passBookingDetails() {
    Get.to(() => const PaymentMethod());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const WidgetText(
          text: 'Booking Details',
          color: AppColors.green,
          fontSize: 20,
          fontWeight: FontWeight.w700,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            const Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    RoomDetailsInfo(),
                    Gap(24),
                    PriceDetailsInfo(),
                    Gap(24),
                    YourReservationInfo(),
                    Gap(24),
                    PrefferedPaymentInfo(),
                  ],
                ),
              ),
            ),
            WidgetButton(
              text: 'Proceed',
              borderRadius: 50,
              onPressed: () => passBookingDetails(),
            ),
          ],
        ),
      ),
    );
  }
}
