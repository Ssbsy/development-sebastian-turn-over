import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/model/model_room_list.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/screens/view/view_room_details.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/widgets/widget_circle_icon_button.dart';
import 'package:airbnb_stayfinder_mobile/src/services/base_api_services.dart';
import 'package:airbnb_stayfinder_mobile/src/services/get_all_listing_services.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:get/get.dart';
import 'package:carousel_slider/carousel_slider.dart';

class ViewRoomLists extends StatefulWidget {
  ViewRoomLists({super.key});

  @override
  State<ViewRoomLists> createState() => _ViewRoomListsState();
}

class _ViewRoomListsState extends State<ViewRoomLists> {
  List<RoomList> roomData = [];
  bool isLoading = true;

  GetAllListingServices getAllListings =
      GetAllListingServices(BaseApiServices());

  @override
  void initState() {
    super.initState();
    fetchRoomListings();
  }

  Future<void> fetchRoomListings() async {
    try {
      final response = await getAllListings.getAllListing();

      if (response['success'] == true && response.containsKey('data')) {
        final List<dynamic> data = response['data'];

        setState(() {
          roomData = data.map((item) => RoomList.fromMap(item)).toList();

          isLoading = false;
        });
        print(
            "Room Data (After Mapping): ${roomData.map((room) => room.listingId)}");
      } else {
        throw Exception("Invalid API response format or no data found");
      }
    } catch (e) {
      print("Error fetching room listings: $e");
      setState(() {
        isLoading = false;
      });
    }
  }

  Widget _textWidget(String text, double fontSize, FontWeight fontWeight,
      {double opacity = 1.0}) {
    return WidgetText(
      text: text,
      color: AppColors.black.withOpacity(opacity),
      fontSize: fontSize,
      fontWeight: fontWeight,
    );
  }

  @override
  Widget build(BuildContext context) {
    return isLoading
        ? const Center(child: CircularProgressIndicator())
        : roomData.isEmpty
            ? const Center(child: Text("No rooms available"))
            : ListView.builder(
                shrinkWrap: true,
                physics: const BouncingScrollPhysics(),
                itemCount: roomData.length,
                itemBuilder: (context, index) {
                  return _hotelItem(roomData[index]);
                },
              );
  }

  Widget _hotelItem(RoomList hotel) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: GestureDetector(
        onTap: () {
          print("Navigating with listingId: ${hotel.listingId}");
          if (hotel.listingId.isEmpty) {
            print("Error: listingId is empty!");
            return;
          }
          Get.to(() => ViewRoomDetails(listingId: hotel.listingId));
        },
        child: Column(
          children: [
            Stack(
              children: [
                CarouselSlider(
                  items: [
                    if (hotel.image.isNotEmpty)
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.network(
                          hotel.image,
                          height: 300,
                          width: double.infinity,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) {
                            return Image.asset(
                              'assets/images/hotel_room_1.jpg',
                              height: 300,
                              width: double.infinity,
                              fit: BoxFit.cover,
                            );
                          },
                        ),
                      )
                    else
                      Image.asset(
                        'assets/images/hotel_room_1.jpg',
                        height: 300,
                        width: double.infinity,
                        fit: BoxFit.cover,
                      ),
                  ],
                  options: CarouselOptions(
                    height: 300,
                    enlargeCenterPage: false,
                    autoPlay: true,
                    viewportFraction: 1.0,
                  ),
                ),
                Align(
                  alignment: Alignment.topRight,
                  child: WidgetCircleIconButton(
                    icon: Icons.favorite_outline,
                    onPressed: () {},
                  ),
                ),
              ],
            ),
            const Gap(8),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _textWidget(hotel.name, 14, FontWeight.w400),
                      _textWidget(hotel.location, 14, FontWeight.w400,
                          opacity: 0.5),
                      _textWidget(hotel.dates, 14, FontWeight.w400,
                          opacity: 0.5),
                      _textWidget('₱ ${hotel.price}', 14, FontWeight.w400),
                    ],
                  ),
                ),
                const Icon(Icons.star, color: AppColors.yellow),
                const Gap(8),
                _textWidget(hotel.rating.toString(), 14, FontWeight.w500),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
