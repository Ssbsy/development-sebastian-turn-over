import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/widgets/widget_circle_icon_button.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class SelectGuestPage extends StatefulWidget {
  const SelectGuestPage({super.key});

  @override
  State<SelectGuestPage> createState() => _SelectGuestPageState();
}

class _SelectGuestPageState extends State<SelectGuestPage> {
  // Guest type definitions and initial counts
  final List<Map<String, dynamic>> guestTypes = [
    {
      'type': 'Adults',
      'description': 'Ages 13 or above',
      'count': 0,
      'max': 10
    },
    {'type': 'Children', 'description': 'Ages 2 - 12', 'count': 0, 'max': 10},
    {'type': 'Infants', 'description': 'Under 2', 'count': 0, 'max': 5},
    {
      'type': 'Pets',
      'description': 'Bringing a service animal?',
      'count': 0,
      'max': 5
    },
  ];

  // Increment function
  void increment(int index) {
    if (guestTypes[index]['count'] < guestTypes[index]['max']) {
      setState(() {
        guestTypes[index]['count']++;
      });
    }
  }

  // Decrement function
  void decrement(int index) {
    if (guestTypes[index]['count'] > 0) {
      setState(() {
        guestTypes[index]['count']--;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const WidgetText(
          text: "Who's coming?",
        
          fontSize: 20,
          fontWeight: FontWeight.w500,
        ),
        const Gap(12),
        // ListView.builder for guests
        ListView.builder(
          shrinkWrap: true,
          itemCount: guestTypes.length,
          itemBuilder: (context, index) {
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 10.0),
              child: Row(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      WidgetText(
                        text: guestTypes[index]['type'],
                        color: AppColors.black,
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      ),
                      WidgetText(
                        text: guestTypes[index]['description'],
                        color: AppColors.black.withOpacity(0.5),
                        fontSize: 12,
                        fontWeight: FontWeight.w400,
                      ),
                    ],
                  ),
                  const Spacer(),
                  // Increment Decrement Logic
                  WidgetCircleIconButton(
                    borderColor: AppColors.black,
                    icon: Icons.remove,
                    iconSize: 16,
                    onPressed: guestTypes[index]['count'] > 0
                        ? () => decrement(index)
                        : () {},
                  ),
                  WidgetText(
                    text: guestTypes[index]['count'].toString(),
                   
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                  WidgetCircleIconButton(
                    borderColor: AppColors.black,
                    icon: Icons.add,
                    iconSize: 16,
                    onPressed:
                        guestTypes[index]['count'] < guestTypes[index]['max']
                            ? () => increment(index)
                            : () {},
                  ),
                ],
              ),
            );
          },
        ),
      ],
    );
  }
}
