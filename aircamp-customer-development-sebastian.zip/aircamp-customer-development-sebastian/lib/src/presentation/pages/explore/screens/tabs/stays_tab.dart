import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/screens/search_explore/add_guest/select_guest_page.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/screens/search_explore/calendar_picker/select_calendar_page.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/screens/search_explore/desination/select_destination_page.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/widgets/widget_animated_container.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class StaysTab extends StatefulWidget {
  const StaysTab({super.key});

  @override
  State<StaysTab> createState() => _StaysTabState();
}

class _StaysTabState extends State<StaysTab> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: SingleChildScrollView(
        child: Column(
          children: [
            _selectDestination(),
            const Gap(12),
            _selectDate(),
            const Gap(12),
            _selectGuests(),
          ],
        ),
      ),
    );
  }

  // Destination Container
  WidgetAnimatedContainer _selectDestination() {
    return const WidgetAnimatedContainer(
      leadingText: 'Where to',
      trailingText: 'Select Destination',
      child: SelectDestinationPage(),
    );
  }

  // Date Picker Container
  WidgetAnimatedContainer _selectDate() {
    return const WidgetAnimatedContainer(
      leadingText: 'When',
      trailingText: 'Select Date',
      child: SelectCalendarPage(),
    );
  }

  // Guest Picker Container
  WidgetAnimatedContainer _selectGuests() {
    return const WidgetAnimatedContainer(
      leadingText: 'Who',
      trailingText: 'Add guests',
      child: SelectGuestPage(),
    );
  }
}
