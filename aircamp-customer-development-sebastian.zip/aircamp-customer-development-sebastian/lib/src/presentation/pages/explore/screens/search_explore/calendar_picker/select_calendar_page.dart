import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:animated_segmented_tab_control/animated_segmented_tab_control.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class SelectCalendarPage extends StatefulWidget {
  const SelectCalendarPage({super.key});

  @override
  State<SelectCalendarPage> createState() => _SelectCalendarPageState();
}

class _SelectCalendarPageState extends State<SelectCalendarPage> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          WidgetText(
            text: "When's your trip?",
            fontSize: 20,
            fontWeight: FontWeight.w500,
          ),
          Gap(12),
          SegmentedTabControl(
            tabTextColor: AppColors.black,
            selectedTabTextColor: AppColors.green,
            indicatorPadding: EdgeInsets.all(2),
            indicatorDecoration: BoxDecoration(
              color: AppColors.white,
              border: Border.all(
                color: AppColors.green,
              ),
              borderRadius: BorderRadius.circular(50),
            ),
            barDecoration: BoxDecoration(
              color: AppColors.gray.withOpacity(0.1),
              borderRadius: BorderRadius.circular(50),
            ),
            tabs: [
              SegmentTab(label: 'Dates'),
              SegmentTab(label: 'Flexible'),
            ],
          ),
          Gap(12),
          SizedBox(
            height: 500,
            child: TabBarView(
              physics: NeverScrollableScrollPhysics(),
              children: [
                // Calendar Picker
                CalendarDatePicker(
                  initialDate: DateTime.now(),
                  firstDate: DateTime(2025),
                  lastDate: DateTime(2026),
                  onDateChanged: (onChanged) {},
                ),
                // Month Picker

                Container(
                  decoration: BoxDecoration(
                    color: Colors.blue,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
