import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'dart:math';

class ViewStaggeredRoomGallery extends StatefulWidget {
  const ViewStaggeredRoomGallery({super.key});

  @override
  State<ViewStaggeredRoomGallery> createState() =>
      _ViewStaggeredRoomGalleryState();
}

class _ViewStaggeredRoomGalleryState extends State<ViewStaggeredRoomGallery> {
  // Example list of images, you can add more if needed.
  final List<String> images = [
    'assets/images/hotel_room_1.jpg',
    'assets/images/hotel_room_1.jpg',
    'assets/images/hotel_room_1.jpg',
    'assets/images/hotel_room_1.jpg',
    'assets/images/hotel_room_1.jpg',
  ];

  // Random instance to generate random numbers
  final Random random = Random();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        forceMaterialTransparency: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: MasonryGridView.count(
          crossAxisCount: 2,
          mainAxisSpacing: 4,
          crossAxisSpacing: 4,
          itemCount: images.length,
          itemBuilder: (BuildContext context, int index) {
            // Random height between 150 and 350
            double randomHeight = random.nextInt(200) + 150.0;
            // Random width (either 2 or 3 columns wide)
            double randomWidth = random.nextInt(2) + 2.0;

            return Image.asset(
              images[index],
              height: randomHeight,
              width: randomWidth * MediaQuery.of(context).size.width / 2,
              fit: BoxFit.cover,
            );
          },
        ),
      ),
    );
  }
}
