import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/widgets/widget_row_textbutton.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class ReservetionReqInfo extends StatefulWidget {
  const ReservetionReqInfo({super.key});

  @override
  State<ReservetionReqInfo> createState() => _ReservetionReqInfoState();
}

class _ReservetionReqInfoState extends State<ReservetionReqInfo> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const WidgetText(
          text: 'Reservation’s Requirements',
          color: AppColors.green,
          fontSize: 16,
          fontWeight: FontWeight.w600,
        ),
        const Gap(12),
        WidgetRowTextbutton(
          leadingText: 'Message your host',
          trailingText: '30 December 2024 - 31 December 2024',
          buttonText: 'Add',
          onPressed: () {},
        ),
        WidgetRowTextbutton(
          leadingText: 'Photo',
          trailingText: 'The Host want to see who’s staying at their place',
          buttonText: 'Add',
          onPressed: () {},
        ),
        WidgetRowTextbutton(
          leadingText: 'Phone',
          trailingText:
              'Add a phone number to get an update about your booking',
          buttonText: 'Add',
          onPressed: () {},
        ),
      ],
    );
  }
}
