import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';

class PriceDetailsInfo extends StatefulWidget {
  const PriceDetailsInfo({super.key});

  @override
  State<PriceDetailsInfo> createState() => _PriceDetailsInfoState();
}

class _PriceDetailsInfoState extends State<PriceDetailsInfo> {
   
  @override
  Widget build(BuildContext context) {
    Map<String, String> reservations = {
      'Reservation': '₱ 2500',
      'Service Fee': '₱ 250',
      'Ad-ons': '₱ 500',
    };

    double total = 0.0;
    reservations.forEach((key, value) {
      double price = double.tryParse(value.replaceAll('₱', '').trim()) ?? 0.0;
      total += price;
    });

    String totalFormatted = '₱ ${total.toStringAsFixed(2)}';
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const WidgetText(
          text: 'Price Details',
          color: AppColors.green,
          fontSize: 16,
          fontWeight: FontWeight.w600,
        ),
        const Divider(),
        ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: reservations.length,
          itemBuilder: (context, index) {
            String key = reservations.keys.elementAt(index);
            String value = reservations[key]!;

            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  WidgetText(
                    text: key,
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                  ),
                  WidgetText(
                    text: value,
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                  ),
                ],
              ),
            );
          },
        ),
        const Divider(),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const WidgetText(
              text: 'Total of Payment',
              fontSize: 14,
              fontWeight: FontWeight.w600,
            ),
            WidgetText(
              text: totalFormatted,
              fontSize: 14,
              fontWeight: FontWeight.w600,
            ),
          ],
        ),
      ],
    );
  }
}
