import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_textfield.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class SelectDestinationPage extends StatefulWidget {
  const SelectDestinationPage({super.key});

  @override
  State<SelectDestinationPage> createState() => _SelectDestinationPageState();
}

class _SelectDestinationPageState extends State<SelectDestinationPage> {
  // List of destinations with map image and corresponding text
  final List<Map<String, String>> destinations = [
    {'image': 'assets/images/world_map.png', 'text': "I'm Flexible"},
    {'image': 'assets/images/united_states.png', 'text': 'United States'},
    {'image': 'assets/images/japan.png', 'text': 'Japan'},
    {'image': 'assets/images/southeast_asia.png', 'text': 'Southeast Asia'},
    {'image': 'assets/images/italy.png', 'text': 'Italy'},
    {'image': 'assets/images/middle_east.png', 'text': 'Middle East'},
  ];

  // Variable to store the index of the selected destination
  int selectedDestinationIndex = -1;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const WidgetText(
          text: 'Where to?',
         
          fontSize: 20,
          fontWeight: FontWeight.w500,
        ),
        const Gap(12),
        WidgetTextField(
          hintText: 'Search Destinations',
          prefixIcon: const Icon(Icons.search),
          borderColor: AppColors.black.withOpacity(0.1),
          fillColor: AppColors.white,
        ),
        const Gap(12),
        SizedBox(
          height: 175,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: destinations.length,
            itemBuilder: (context, index) {
              bool isSelected = index == selectedDestinationIndex;

              return Padding(
                padding: const EdgeInsets.only(right: 8.0),
                child: GestureDetector(
                  onTap: () {
                    setState(() {
                      if (isSelected) {
                        selectedDestinationIndex = -1;
                      } else {
                        selectedDestinationIndex = index;
                      }
                    });
                  },
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Container(
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: isSelected
                                  ? Colors.green
                                  : AppColors.black.withOpacity(0.1),
                            ),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Image.asset(
                            destinations[index]['image']!,
                            height: 125,
                            width: 125,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      const Gap(8),
                      WidgetText(
                        text: destinations[index]['text']!,
                        
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
