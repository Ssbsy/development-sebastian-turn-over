import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/screens/search_explore/explore_search_controller.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';

import '../../../../core/constants/colors.dart';

class WidgetExploreSearch extends StatelessWidget {
  const WidgetExploreSearch({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 70,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          elevation: 10,
          backgroundColor: AppColors.white,
          shape: RoundedRectangleBorder(
            side: BorderSide(
              color: AppColors.gray.withOpacity(0.1),
            ),
            borderRadius: BorderRadius.circular(50),
          ),
        ).copyWith(
          shadowColor:
              WidgetStateProperty.all(AppColors.black.withOpacity(0.2)),
        ),
        onPressed: () {
          Get.to(
            () => const ExploreSearchController(),
            transition: Transition.downToUp,
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Icon(
                Icons.search,
                color: AppColors.black,
              ),
              const Gap(16),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    WidgetText(
                      text: 'Where to?',
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                    WidgetText(
                      text: 'Anywhere ∙ Any week ∙ Add guests',
                      color: AppColors.gray,
                      fontSize: 12,
                      fontWeight: FontWeight.w400,
                    ),
                  ],
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: AppColors.black.withOpacity(0.1),
                  ),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Image.asset(
                    'assets/icons/ic_filter.png',
                    height: 18,
                    color: AppColors.black,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
