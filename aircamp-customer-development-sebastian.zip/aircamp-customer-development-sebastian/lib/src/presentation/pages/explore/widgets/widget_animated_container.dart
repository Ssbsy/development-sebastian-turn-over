import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';

class WidgetAnimatedContainer extends StatefulWidget {
  final dynamic child;
  final String? leadingText;
  final String? trailingText;

  const WidgetAnimatedContainer({
    super.key,
    this.child,
    this.leadingText,
    this.trailingText,
  });

  @override
  State<WidgetAnimatedContainer> createState() =>
      _WidgetAnimatedContainerState();
}

class _WidgetAnimatedContainerState extends State<WidgetAnimatedContainer> {
  bool _isTapped = false;
  

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _isTapped = !_isTapped;
        });
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 600),
        width: MediaQuery.sizeOf(context).width,
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 12,
              spreadRadius: 0,
            ),
          ],
          border: Border.all(
            color: Colors.black.withOpacity(0.2),
          ),
          borderRadius: BorderRadius.circular(24),
        ),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: _isTapped
              ? SingleChildScrollView(
                  child: widget.child,
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    WidgetText(
                      text: widget.leadingText,
                     
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                    ),
                    WidgetText(
                      text: widget.trailingText,
                     
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}
