import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class WidgetFloatingButton extends StatelessWidget {
  final VoidCallback? onPressed;
  final String? text;
  final double? fontSize;
  final IconData? icon;

  const WidgetFloatingButton(
      {super.key, this.onPressed, this.text, this.icon, this.fontSize});

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton.extended(
      onPressed: onPressed,
      label: Row(
        children: [
          WidgetText(
            text: text,
            color: AppColors.white,
            fontSize: fontSize,
            fontWeight: FontWeight.w400,
          ),
          if (icon != null) ...[
            const Gap(8),
            Icon(
              icon,
              color: AppColors.white,
            ),
          ],
        ],
      ),
    );
  }
}
