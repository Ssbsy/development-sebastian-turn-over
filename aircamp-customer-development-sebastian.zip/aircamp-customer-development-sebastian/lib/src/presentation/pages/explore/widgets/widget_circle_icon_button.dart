import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:flutter/material.dart';

class WidgetCircleIconButton extends StatelessWidget {
  final IconData? icon;
  final VoidCallback? onPressed;
  final Color? borderColor;
  final double? iconSize;
  const WidgetCircleIconButton(
      {super.key, this.icon, this.onPressed, this.borderColor, this.iconSize});

  @override
  Widget build(BuildContext context) {
    return IconButton(
      onPressed: onPressed,
      icon: Container(
        decoration: BoxDecoration(
          color: AppColors.white,
          shape: BoxShape.circle,
          border: Border.all(
            color: borderColor ?? AppColors.transparent,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Icon(
            icon,
            color: AppColors.black,
            size: iconSize,
          ),
        ),
      ),
    );
  }
}
