import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class WidgetRowTextbutton extends StatelessWidget {
  final String? leadingText;
  final String? trailingText;
  final String? buttonText;
  final VoidCallback? onPressed;
  const WidgetRowTextbutton(
      {super.key,
      this.leadingText,
      this.trailingText,
      this.onPressed,
      this.buttonText});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              WidgetText(
                text: leadingText ?? '',
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
              WidgetText(
                text: trailingText ?? '',
                fontSize: 14,
                fontWeight: FontWeight.w400,
              ),
            ],
          ),
        ),
        const Gap(12),
        TextButton(
          style: ButtonStyle(
            backgroundColor: WidgetStatePropertyAll(
              AppColors.green.withOpacity(0.2),
            ),
          ),
          onPressed: onPressed,
          child: WidgetText(
            text: buttonText ?? 'Edit',
            color: AppColors.green,
            fontSize: 12,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}
