import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/screens/view/view_room_lists.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/widgets/widget_explore_search.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/widgets/widget_floating_button.dart';
import 'package:flutter/material.dart';

class ExplorePage extends StatefulWidget {
  const ExplorePage({super.key});

  @override
  State<ExplorePage> createState() => _ExplorePageState();
}

class _ExplorePageState extends State<ExplorePage> {
  int _selectedIndex = 0;

  Widget _tabBar(String imageAsset, String tabTitle, int index) {
    return Column(
      children: [
        _buildNavItem(imageAsset, index),
        Tab(text: tabTitle),
      ],
    );
  }

  Widget _buildNavItem(String imagePath, int index) {
    return ColorFiltered(
      colorFilter: ColorFilter.mode(
        _selectedIndex == index ? AppColors.green : AppColors.gray,
        BlendMode.srcATop,
      ),
      child: Image.asset(
        imagePath,
        height: 24,
        width: 24,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 5,
      child: Scaffold(
        floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
        floatingActionButton: WidgetFloatingButton(
          onPressed: () {},
          text: 'Map',
          icon: Icons.map_outlined,
        ),
        appBar: AppBar(
          bottom: const PreferredSize(
            preferredSize: Size.fromHeight(50),
            child: Padding(
              padding: EdgeInsets.all(8.0),
              child: WidgetExploreSearch(),
            ),
          ),
        ),
        body: Column(
          children: [
            TabBar(
              isScrollable: true,
              tabs: [
                _tabBar('assets/icons/tab_home.png', 'All', 0),
                _tabBar('assets/icons/tab_town_house.png', 'Townhouse', 1),
                _tabBar(
                    'assets/icons/tab_cape_cod_style.png', 'Cape Cod Style', 2),
                _tabBar('assets/icons/tab_bungalow.png', 'Bungalow', 3),
                _tabBar('assets/icons/tab_cottage.png', 'Cottage', 4),
              ],
              onTap: (index) {
                setState(() {
                  _selectedIndex = index;
                });
              },
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: TabBarView(
                  children: [
                    ViewRoomLists(),
                    ViewRoomLists(),
                    ViewRoomLists(),
                    ViewRoomLists(),
                    ViewRoomLists(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
