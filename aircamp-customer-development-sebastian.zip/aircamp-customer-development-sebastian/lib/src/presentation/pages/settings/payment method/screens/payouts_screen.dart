import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class PayoutsScreen extends StatelessWidget {
  const PayoutsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 20.0,
          vertical: 10,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            WidgetText(
              text: 'Payouts',
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: AppColors.green,
            ),
            const Gap(15),
            WidgetText(
              text:
                  'Set up a payout method to receive your payments. Add at least one payment method, such as a bank account or digital wallet, so we can transfer your funds to you securely and efficiently.',
            ),
          ],
        ),
      ),
    );
  }
}
