import 'package:airbnb_stayfinder_mobile/src/presentation/pages/settings/payment%20method/screens/payment_screen.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/settings/payment%20method/screens/payouts_screen.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/settings/payment%20method/screens/preffered_currency_screen.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/settings/payment%20method/screens/transaction_screen.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

class PaymentMethodsList extends StatelessWidget {
  const PaymentMethodsList({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      spacing: 10,
      children: [
        _paymentMedthods(
          'assets/icons/payment_method_icon.svg',
          20,
          20,
          'Payment methods',
          () => Get.to(() => const PaymentScreen()),
        ),
        const Divider(),
        _paymentMedthods(
          'assets/icons/transactions_icon.svg',
          26,
          26,
          'Transactions',
          () => Get.to(() => const TransactionScreen()),
        ),
        const Divider(),
        _paymentMedthods(
          'assets/icons/payouts_icon.svg',
          20,
          20,
          'Payouts',
          () => Get.to(() => const PayoutsScreen()),
        ),
        const Divider(),
        _paymentMedthods(
          'assets/icons/preffered_currecy_icon.svg',
          20,
          20,
          'Preferred Currency',
          () => Get.to(() => const PrefferedCurrencyScreen()),
        ),
        const Divider(),
      ],
    );
  }

  GestureDetector _paymentMedthods(
    String svgAsset,
    double? svgHeight, //Dynamic Height
    double? svgWidth, //Dynamic Width
    String title,
    VoidCallback onTap,
  ) {
    return GestureDetector(
      onTap: onTap,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            spacing: 17,
            children: [
              SvgPicture.asset(
                svgAsset,
                width: svgWidth ?? 24,
                height: svgHeight ?? 24,
              ),
              WidgetText(
                text: title,
              ),
            ],
          ),
          Icon(Icons.arrow_forward_ios),
        ],
      ),
    );
  }
}
