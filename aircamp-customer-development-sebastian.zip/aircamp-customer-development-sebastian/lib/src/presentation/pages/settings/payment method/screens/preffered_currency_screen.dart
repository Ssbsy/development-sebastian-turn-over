import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_button.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class PrefferedCurrencyScreen extends StatelessWidget {
  const PrefferedCurrencyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 20.0,
          vertical: 10,
        ),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              WidgetText(
                text: 'Preffered Currency',
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: AppColors.green,
              ),
              const Gap(15),
              WidgetText(
                text:
                    'Your preferred currency will be used to display prices throughout the site, making it easier for you to navigate and make bookings.',
              ),
              const Gap(15),
              DropdownButtonFormField(
                value: 'Philippine Peso',
                items: [
                  'Philippine Peso',
                ]
                    .map((method) => DropdownMenuItem(
                          child: Text(method),
                          value: method,
                        ))
                    .toList(),
                onChanged: (value) {},
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(22),
                  ),
                ),
              ),
              const Gap(55),
              _buttons(
                'Save',
              ),
              const Gap(15),
              _buttons(
                'Cancel',
                AppColors.black,
                AppColors.white,
                AppColors.black,
                () => Navigator.pop(context),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Padding _buttons(
    String text, [
    Color borderColor = AppColors.green,
    Color backgroundColor = AppColors.green,
    Color textColor = AppColors.white,
    VoidCallback? onPressed,
  ]) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20.0),
      child: WidgetButton(
        onPressed: onPressed ?? () {},
        text: text,
        textColor: textColor,
        borderRadius: 22,
        borderColor: borderColor,
        backgroundColor: backgroundColor,
      ),
    );
  }
}
