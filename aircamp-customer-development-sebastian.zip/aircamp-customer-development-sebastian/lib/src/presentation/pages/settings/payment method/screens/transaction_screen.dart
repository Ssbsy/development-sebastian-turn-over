import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:gap/gap.dart';

class TransactionScreen extends StatelessWidget {
  const TransactionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 20.0,
          vertical: 10,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            WidgetText(
              text: 'Transaction',
              color: AppColors.green,
              fontSize: 16,
              fontWeight: FontWeight.w700,
            ),
            const Gap(15),
            WidgetText(
              text:
                  'This transaction summary provides a concise overview of the exchange, allowing you to quickly understand the details of the transaction.',
            ),
            const Gap(35),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    border: Border.all(),
                    borderRadius: BorderRadius.circular(22),
                  ),
                  child: Row(
                    spacing: 5,
                    children: [
                      SvgPicture.asset('assets/icons/filter_icon.svg'),
                      WidgetText(
                        text: 'Filter',
                        fontWeight: FontWeight.w500,
                        fontSize: 12,
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(
              height: MediaQuery.of(context).size.height * 0.4,
              child: Center(
                child: WidgetText(
                  text:
                      'After booking, visit this page to monitor the status of your payments and refunds, and stay up-to-date on any transactions related to your reservation.',
                  color: Colors.grey.shade500,
                  textAlign: TextAlign.center,
                  fontSize: 12.5,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
