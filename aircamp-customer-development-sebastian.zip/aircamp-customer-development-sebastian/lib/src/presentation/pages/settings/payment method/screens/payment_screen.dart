import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_button.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_textfield.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:gap/gap.dart';

class PaymentScreen extends StatefulWidget {
  const PaymentScreen({super.key});

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  final cardController = TextEditingController();
  final expirationController = TextEditingController();
  final cvvController = TextEditingController();
  String selectedMethod = 'Card Number';
  String hintText = 'Card Number';
  bool showCardDetails = true;

  void dynamicHintText(String method) {
    setState(() {
      selectedMethod = method;
      switch (method) {
        case "Paypal":
          hintText = 'Paypal Email';
          showCardDetails = false;
          break;
        case "Debit/Credit Card":
          hintText = 'Card Number';
          showCardDetails = true;
          break;
        case "Gcash":
          hintText = 'Gcash Number';
          showCardDetails = false;
          break;
        default:
          hintText = 'Payment Details';
          showCardDetails = false;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: Icon(Icons.arrow_back_ios),
            onPressed: () => Navigator.pop(context),
          ),
        ),
        body: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: 20.0,
            vertical: 10,
          ),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                WidgetText(
                  text: 'Payment Method',
                  color: AppColors.green,
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                ),
                const Gap(10),
                WidgetText(
                  text:
                      'This transaction summary provides a concise overview of the exchange, allowing you to quickly understand the details of the transaction.',
                ),
                const Gap(35),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    SvgPicture.asset('assets/icons/payment_options_icon.svg'),
                  ],
                ),
                const Gap(10),
                DropdownButtonFormField(
                  value: 'Debit/Credit Card',
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(22),
                    ),
                  ),
                  isExpanded: true,
                  items: [
                    'Paypal',
                    'Debit/Credit Card',
                    'Gcash',
                    'Google Pay (GPay)',
                  ]
                      .map((method) => DropdownMenuItem(
                            value: method,
                            child: Text(method),
                          ))
                      .toList(),
                  onChanged: (value) {
                    if (value != null) {
                      dynamicHintText(value);
                    }
                  },
                ),
                const Gap(25),
                WidgetTextField(
                  controller: cardController,
                  hintText: hintText,
                  borderRadius: 22,
                  borderColor: AppColors.black,
                  fillColor: AppColors.white,
                ),
                const Gap(25),
                if (showCardDetails)
                  SizedBox(
                    width: double.infinity,
                    child: Row(
                      children: [
                        Expanded(
                          flex: 2,
                          child: WidgetTextField(
                            hintText: 'Expiration',
                            controller: expirationController,
                            fillColor: AppColors.white,
                            borderColor: AppColors.black,
                            borderRadius: 22,
                          ),
                        ),
                        const Gap(15),
                        Expanded(
                          flex: 1,
                          child: WidgetTextField(
                            hintText: 'CVV',
                            controller: cvvController,
                            fillColor: AppColors.white,
                            borderColor: AppColors.black,
                            borderRadius: 22,
                          ),
                        ),
                      ],
                    ),
                  ),
                const Gap(40),
                WidgetButton(
                  text: 'Save',
                  onPressed: () {},
                  borderRadius: 22,
                ),
                const Gap(20),
                WidgetButton(
                  text: 'Cancel',
                  onPressed: () => Navigator.pop(context),
                  borderRadius: 22,
                  textColor: AppColors.black,
                  backgroundColor: AppColors.white,
                  borderColor: AppColors.black,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
