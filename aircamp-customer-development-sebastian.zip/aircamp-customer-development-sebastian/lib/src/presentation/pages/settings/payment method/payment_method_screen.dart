import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/settings/payment%20method/widgets/payment_methods_list.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class PaymentMethodScreen extends StatelessWidget {
  const PaymentMethodScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 20.0,
          vertical: 10,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            WidgetText(
              text: 'Payment Method',
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: AppColors.green,
            ),
            const Gap(20),
            WidgetText(
              text:
                  'Manage your payment options here. Add, edit, or remove payment methods to make booking easier and faster.',
              fontWeight: FontWeight.w300,
            ),
            const Gap(50),
            const PaymentMethodsList(),
          ],
        ),
      ),
    );
  }
}
