import 'package:airbnb_stayfinder_mobile/src/presentation/pages/settings/hosting%20tools/hosting_tools_screen.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/settings/view%20profile/view_profile_screen.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/settings/widgets/account_settings.dart';
import 'package:airbnb_stayfinder_mobile/src/services/base_api_services.dart';
import 'package:airbnb_stayfinder_mobile/src/services/get_my_profile_services.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({Key? key}) : super(key: key);

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final apiServices = BaseApiServices();
  late GetMyProfileServices profileService;
  Map<String, dynamic>? profileData;

  @override
  void initState() {
    super.initState();
    profileService = GetMyProfileServices(apiServices);
    fetchProfile();
  }

  Future<void> fetchProfile() async {
    final response = await profileService.getProfile();

    if (!mounted) return;

    if (response["success"] == true) {
      setState(() {
        profileData = response["data"];
      });
      print("Full Name: ${profileData?["fullname"]}");
    } else {
      print("Error: ${response["message"]}");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Profile Picture
              const Center(
                child: CircleAvatar(
                  radius: 40,
                  backgroundImage: AssetImage('assets/icons/ai_profile.jpg'),
                ),
              ),

              const Gap(15),

              // Full Name
              WidgetText(
                text: profileData?["fullname"] ?? "Loading...",
                fontSize: 15,
              ),

              const Gap(15),

              // View Profile
              GestureDetector(
                onTap: () => Get.to(() => ViewProfileScreen()),
                child: WidgetText(
                  text: 'View Profile',
                  color: Colors.green,
                  fontWeight: FontWeight.w700,
                  underline: true,
                ),
              ),

              //Account Settings
              AccountSettings(),

              const Gap(5),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20.0),
                child: Row(
                  children: [
                    WidgetText(
                      text: 'Hosting',
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                    ),
                  ],
                ),
              ),

              const Gap(12),

              GestureDetector(
                onTap: () => Get.to(() => const HostingToolsScreen()),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        spacing: 10,
                        children: [
                          Icon(
                            Icons.settings,
                            size: 20,
                          ),
                          WidgetText(
                            text: 'Hosting tools',
                            fontSize: 14,
                          ),
                        ],
                      ),
                      Icon(
                        Icons.arrow_forward_ios,
                        size: 15,
                      ),
                    ],
                  ),
                ),
              ),
              const Gap(5),
              const Divider(
                indent: 20,
                endIndent: 20,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
