import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/settings/security%20and%20privacy%20page/forgot_password_screen.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/settings/security%20and%20privacy%20page/security_and_privacy_screen.dart';
import 'package:airbnb_stayfinder_mobile/src/services/base_api_services.dart';
import 'package:airbnb_stayfinder_mobile/src/services/change_password_services.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_textfield.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

class UpdatePasswordScreen extends StatefulWidget {
  const UpdatePasswordScreen({super.key});

  @override
  State<UpdatePasswordScreen> createState() => _UpdatePasswordScreenState();
}

class _UpdatePasswordScreenState extends State<UpdatePasswordScreen> {
  final _passwordController = TextEditingController();
  final _newPasswordController = TextEditingController();
  final _retypePasswordController = TextEditingController();

  final FocusNode _passwordFocusNode = FocusNode();
  final FocusNode _newPasswordFocusNode = FocusNode();
  final FocusNode _retypePasswordFocusNode = FocusNode();

  final ChangePasswordServices changePass =
      ChangePasswordServices(BaseApiServices());

  bool isLoading = false;

  void updatePassword() async {
    print("Login process started..."); // for debugging purposes
    setState(() => isLoading = true);
    FocusScope.of(context).unfocus();

    String password = _passwordController.text.trim();
    String newPassword = _newPasswordController.text.trim();
    String retypePassword = _retypePasswordController.text.trim();

    try {
      print(
          "Sending update password request..."); // same for debugging purposes
      final response = await changePass.patchChangePassword(
        password: password,
        newPassword: newPassword,
        confirmPassword: retypePassword,
      );

      print("Response received: $response"); // another debugging purpses

      if (response is Map<String, dynamic> &&
          response.containsKey("success") &&
          response["success"] == true) {
        print("password updated");

        Get.to(() => SecurityAndPrivacyScreen());
      } else {
        print("Login failed: ${response['message']}"); // debugging purposes
      }
    } catch (e) {
      print("Exception caught: $e"); // for debugging
    } finally {
      print("Resetting loading state..."); // debugging
      setState(() => isLoading = false);
    }
  }

  @override
  void dispose() {
    _passwordController.dispose();
    _newPasswordController.dispose();
    _retypePasswordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            onPressed: () => Navigator.pop(context),
            icon: Icon(Icons.arrow_back_ios),
          ),
        ),
        body: Padding(
          padding: const EdgeInsets.only(
            left: 30.0,
            right: 30,
            top: 10,
            bottom: 10,
          ),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                WidgetText(
                  text: 'Password',
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                  color: Colors.green.shade700,
                ),
                const Gap(15),
                WidgetText(
                  text:
                      'Manage your account security by updating your password, password recovery options, and other related settings.',
                  fontSize: 11,
                ),
                const Gap(40),
                //Password
                WidgetTextField(
                  controller: _passwordController,
                  focusNode: _passwordFocusNode,
                  obscureText: true,
                  keyboardType: TextInputType.visiblePassword,
                  borderColor: AppColors.black,
                  fillColor: AppColors.white,
                  borderRadius: 25,
                  hintText: '*********',
                ),
                const Gap(15),
                WidgetTextField(
                  controller: _newPasswordController,
                  focusNode: _newPasswordFocusNode,
                  obscureText: true,
                  keyboardType: TextInputType.visiblePassword,
                  borderColor: AppColors.black,
                  fillColor: AppColors.white,
                  borderRadius: 25,
                  hintText: 'New Password',
                ),
                const Gap(30),
                WidgetTextField(
                  controller: _retypePasswordController,
                  focusNode: _retypePasswordFocusNode,
                  obscureText: true,
                  keyboardType: TextInputType.visiblePassword,
                  borderColor: AppColors.black,
                  fillColor: AppColors.white,
                  borderRadius: 25,
                  hintText: 'Re-type Passowrd',
                ),
                const Gap(25),
                GestureDetector(
                  onTap: () => updatePassword(),
                  child: Container(
                    padding: const EdgeInsets.all(15),
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: Colors.green.shade800,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Center(
                      child: WidgetText(
                        text: 'Update Password',
                        color: AppColors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),
                const Gap(10),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    padding: const EdgeInsets.all(15),
                    width: double.infinity,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: AppColors.black,
                        width: 1,
                      ),
                    ),
                    child: Center(
                      child: WidgetText(
                        text: 'Cancel',
                        color: AppColors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),
                const Gap(30),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    GestureDetector(
                      onTap: () => Get.to(() => ForgotPasswordScreen()),
                      child: WidgetText(
                        text: 'Forgot Password',
                        color: Colors.red,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
