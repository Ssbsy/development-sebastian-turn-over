import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/settings/security%20and%20privacy%20page/security_and_privacy_screen.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_button.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

class PasswordResetSuccessfulScreen extends StatelessWidget {
  const PasswordResetSuccessfulScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Center(
        child: Column(
          children: [
            Icon(
              Icons.lock,
              size: 75,
              color: AppColors.green,
            ),
            const Gap(15),
            WidgetText(
              text: 'Password Reset Successful!',
              fontSize: 17,
              color: AppColors.green,
              fontWeight: FontWeight.bold,
            ),
            const Gap(20),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 35.0),
              child: WidgetText(
                text:
                    "Your password has been successfully reset. You can now log in to your account using your new password. For your security, please make sure to keep your new password confidential and avoid sharing it with anyone. \n \n Thank you for resetting your password! If you need any further assistance, don't hesitate to contact our support team.",
                fontSize: 12,
                textAlign: TextAlign.justify,
              ),
            ),
            const Gap(45),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 35.0),
              child: WidgetButton(
                onPressed: () => Get.to(() => SecurityAndPrivacyScreen()),
                text: 'Done',
                borderRadius: 20,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
