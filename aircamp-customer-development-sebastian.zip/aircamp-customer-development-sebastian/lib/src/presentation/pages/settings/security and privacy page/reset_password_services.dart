import 'dart:convert';
import 'package:airbnb_stayfinder_mobile/src/services/base_api_services.dart';
import 'package:http/http.dart' as http;

class ResetPasswordServices {
  final BaseApiServices apiServices;

  ResetPasswordServices(this.apiServices);

  //Login Method with Endpoint
  Future<Map<String, dynamic>> patchResetPassword({
    required String newPass,
    required String confirmPass,
  }) async {
    const endpoint =
        'api/v1/users/accounts/password-reset/?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJmODdkYzc3My04OWZkLTRlNTMtYmUxNy05OGMxM2JhMmJiMWYiLCJpYXQiOjE3MzkxNDgwMDgsImV4cCI6MTczOTE0ODkwOH0.PhHWOWJAmpQiVLHQdWT4rLZcZE8k0p2vgt9OWK_JpHg';
    final body = {
      'newPass': newPass,
      'confirmPass': confirmPass,
    };

    try {
      final headers = await apiServices.getHeaders();

      print("Headers: $headers");
      print("Request Body: ${jsonEncode(body)}");

      final response = await http.patch(
        Uri.parse('${apiServices.baseUrl}$endpoint'),
        headers: headers,
        body: jsonEncode(body),
      );

      print("Raw API response: ${response.body}");

      if (response.statusCode < 600) {
        final Map<String, dynamic> responseData = jsonDecode(response.body);
        return responseData;
      } else {
        print("Server error: ${response.statusCode} - ${response.body}");
        return {
          "success": false,
          "message": "Server error: ${response.statusCode}"
        };
      }
    } catch (e) {
      print(e);
      return {"success": false, "message": "An error occurred: $e"};
    }
  }
}
