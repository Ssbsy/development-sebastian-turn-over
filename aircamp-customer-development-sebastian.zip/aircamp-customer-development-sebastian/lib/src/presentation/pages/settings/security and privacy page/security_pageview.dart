import 'package:airbnb_stayfinder_mobile/src/presentation/pages/settings/security%20and%20privacy%20page/update_password_screen.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

class SecurityPageview extends StatelessWidget {
  const SecurityPageview({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(
        left: 5,
        right: 5,
        top: 25,
        bottom: 25,
      ),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                WidgetText(
                  text: 'Password',
                  color: Colors.grey.shade500,
                  fontWeight: FontWeight.bold,
                ),
                GestureDetector(
                  onTap: () => Get.to(() => const UpdatePasswordScreen()),
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: WidgetText(
                      text: 'Update',
                      color: Colors.green.shade800,
                    ),
                  ),
                ),
              ],
            ),
            const Gap(10),
            WidgetText(
              text:
                  'Manage your account security by updating your password, password recovery options, and other related settings.',
              fontSize: 11,
            ),
            const Gap(10),
            const Divider(),
            const Gap(30),
            WidgetText(
              text: 'Social Media Accounts',
              color: Colors.grey.shade500,
              fontWeight: FontWeight.bold,
            ),
            const Gap(10),
            WidgetText(
              text:
                  'Manage the social media accounts linked to your profile, including options to add, remove, or update connections to platforms like Facebook, Twitter, and more.',
              fontSize: 11,
            ),
            const Gap(15),
            //Social Media Accounts
            Column(
              spacing: 20,
              children: [
                _socialMediaAccountsRows(
                  'Google',
                  isLinked: false,
                ),
                _socialMediaAccountsRows(
                  'Facebook',
                ),
                _socialMediaAccountsRows(
                  'Apple',
                ),
              ],
            ),
            const Gap(15),
            const Divider(),
            const Gap(25),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                WidgetText(
                  text: 'Logged In Devices',
                  fontWeight: FontWeight.bold,
                  color: Colors.grey.shade500,
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade100,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: WidgetText(
                    text: 'Online',
                    color: Colors.green.shade800,
                  ),
                ),
              ],
            ),
            const Gap(10),
            WidgetText(
              text:
                  'View and manage the devices that have accessed your account, and receive notifications when a new device logs in.',
              color: Colors.grey.shade500,
            ),
          ],
        ),
      ),
    );
  }

  Row _socialMediaAccountsRows(String title, {bool isLinked = true}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            //Icon(),
            WidgetText(
              text: title,
              fontWeight: isLinked ? FontWeight.normal : FontWeight.bold,
            ),
          ],
        ),
        isLinked
            ? Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                decoration: BoxDecoration(
                  color: Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: WidgetText(
                  text: 'Linked',
                  color: Colors.green.shade800,
                ),
              )
            : Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                decoration: BoxDecoration(
                  color: Colors.red.shade100,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: WidgetText(
                  text: 'Unlinked',
                  color: Colors.red,
                ),
              ),
      ],
    );
  }
}
