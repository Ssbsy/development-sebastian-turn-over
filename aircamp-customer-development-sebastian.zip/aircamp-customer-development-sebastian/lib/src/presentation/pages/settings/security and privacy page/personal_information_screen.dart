import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/settings/widgets/custom_notification.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/settings/widgets/custom_textfield_pop_up.dart';
import 'package:airbnb_stayfinder_mobile/src/services/base_api_services.dart';
import 'package:airbnb_stayfinder_mobile/src/services/get_my_basic_profile_services.dart';
import 'package:airbnb_stayfinder_mobile/src/services/get_my_profile_services.dart';
import 'package:airbnb_stayfinder_mobile/src/services/get_my_profile_update_services.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class PersonalInformationScreen extends StatefulWidget {
  const PersonalInformationScreen({super.key});

  @override
  State<PersonalInformationScreen> createState() =>
      _PersonalInformationScreenState();
}

class _PersonalInformationScreenState extends State<PersonalInformationScreen> {
  final apiServices = BaseApiServices();
  late GetMyBasicProfileServices profileService;
  Map<String, dynamic>? profileData;

  final GetMyProfileUpdateServices updateProfileService =
      GetMyProfileUpdateServices(BaseApiServices());

  @override
  void initState() {
    super.initState();
    profileService = GetMyBasicProfileServices(apiServices);
    fetchProfile();
  }

  Future<void> fetchProfile() async {
    final response = await profileService.getBasicProfile();

    if (!mounted) return;

    if (response["success"] == true &&
        response["profile"] is Map<String, dynamic>) {
      setState(() {
        profileData = response["profile"];
      });
      print("First Name: ${profileData?['firstName'] ?? 'N/A'}");
    } else {
      print("Error: ${response["message"]}");
    }
  }

  Future<void> editProfile() async {
    final response = await updateProfileService.getMyProfileUpdate();

    if (!mounted) return;

    if (response["success"] == true &&
        response["profile"] is Map<String, dynamic>) {
      final profile = response["profile"];
      setState(() {
        profileData = profile;
      });
    } else {
      print("Error: ${response["message"]}");
    }
  }

  //For PhoneNumber
  String maskPhoneNumber(String? phone) {
    if (phone == null || phone.length < 7) return 'Invalid Number';

    return '${phone.substring(0, 3)} **** ${phone.substring(phone.length - 4)}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: Icon(Icons.arrow_back_ios),
        ),
        title: WidgetText(
          text: 'Personal Information',
          fontSize: 14,
          fontWeight: FontWeight.bold,
        ),
      ),
      body: Center(
        child: Column(
          children: [
            //Default Profile
            CircleAvatar(
              radius: 40,
              backgroundImage: AssetImage('assets/icons/ai_profile.jpg'),
            ),

            const Gap(10),

            //Edit Profile Picture
            WidgetText(
              text: 'Edit Profile Picture',
              color: AppColors.green,
              underline: true,
              fontSize: 12,
            ),

            const Gap(20),

            //Rows
            _rows('First Name', 'firstName'),
            _divider(),
            _rows('Last Name', 'lastName'),
            _divider(),
            _rows('Mobile Number', 'phoneNo'),
            _divider(),
            _rows('Email', 'email'),
            _divider(),
            _rows('Address', 'addressStreet'),
            _divider(),
            _staticRow(),
          ],
        ),
      ),
    );
  }

  Padding _staticRow() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          WidgetText(
            text: 'Government ID',
          ),
          Row(
            spacing: 5,
            children: [
              WidgetText(
                text: 'PRC License',
                fontSize: 12,
              ),
              Icon(
                Icons.arrow_forward_ios,
                size: 15,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Padding _divider() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20.0),
      child: const Divider(),
    );
  }

  Padding _rows(String title, String key) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 8.0),
      child: GestureDetector(
        onTap: () {
          TextEditingController controller = TextEditingController(
            text: profileData?[key] ?? '',
          );
          CustomTextFieldPopup.show(
            context,
            title: title,
            controller: controller,
            hintText: "Enter $title...",
            onUpdate: () {
              editProfile();
              CustomNotification.show(context, "Changes Saved");
              Navigator.pop(context);
            },
          );
        },
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          spacing: 5,
          children: [
            WidgetText(
              text: title,
              fontWeight: FontWeight.w300,
            ),
            const Spacer(),
            WidgetText(
              text: key == 'phoneNo'
                  ? maskPhoneNumber(profileData?[key])
                  : profileData?[key] ?? 'Loading...',
              fontSize: 12,
            ),
            const Icon(
              Icons.arrow_forward_ios,
              size: 15,
            ),
          ],
        ),
      ),
    );
  }
}
