import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class PrivacyPageview extends StatefulWidget {
  const PrivacyPageview({super.key});

  @override
  State<PrivacyPageview> createState() => _PrivacyPageviewState();
}

class _PrivacyPageviewState extends State<PrivacyPageview> {
  bool isReadReceipt = true;
  bool isViewMyOwnListing = true;
  bool isDisplayMyLocation = false;
  bool isDisplayTripDetails = false;
  bool isDisplayDurationOfVisit = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            _privacyRow(
              'Read Receipts',
              isReadReceipt,
              (newValue) {
                setState(
                  () {
                    isReadReceipt = newValue;
                  },
                );
              },
            ),
            const Gap(5),
            WidgetText(
              text:
                  "Enable this feature to let others know that you've seen their messages, providing a clear indication that you're aware of their communication.",
              fontSize: 11,
              textAlign: TextAlign.justify,
            ),
            const Gap(10),
            _privacyRow(
              'View my own listings',
              isViewMyOwnListing,
              (newValue) {
                setState(
                  () {
                    isViewMyOwnListing = newValue;
                  },
                );
              },
            ),
            const Gap(5),
            WidgetText(
              text:
                  "Make my listings visible on external search engines, allowing potential customers to discover and access them through popular search platforms.",
              fontSize: 11,
              textAlign: TextAlign.justify,
            ),
            const Gap(10),
            _privacyRow(
              'Display my location',
              isDisplayMyLocation,
              (newValue) {
                setState(
                  () {
                    isDisplayMyLocation = newValue;
                  },
                );
              },
            ),
            const Gap(5),
            WidgetText(
              text:
                  'You have control over who can see your location and when. You can choose to share your location with everyone, friends, or keep it private.',
              fontSize: 11,
              textAlign: TextAlign.justify,
            ),
            const Gap(10),
            _privacyRow(
              'Display trip details',
              isDisplayTripDetails,
              (newValue) {
                setState(
                  () {
                    isDisplayTripDetails = newValue;
                  },
                );
              },
            ),
            const Gap(5),
            WidgetText(
              text:
                  "Your trip type will be visible to others, so please choose the option that best reflects your travel intentions.",
              fontSize: 11,
              textAlign: TextAlign.justify,
            ),
            const Gap(10),
            _privacyRow(
              'Display Duration of Visit',
              isDisplayDurationOfVisit,
              (newValue) {
                setState(
                  () {
                    isDisplayDurationOfVisit = newValue;
                  },
                );
              },
            ),
            const Gap(5),
            WidgetText(
              text:
                  "Your duration of visit will be visible to others, so please ensure to update this information accurately to reflect your travel plans.",
              fontSize: 11,
              textAlign: TextAlign.justify,
            ),
            const Gap(5),
          ],
        ),
      ),
    );
  }

  Row _privacyRow(String title, bool value, ValueChanged<bool> onChanged) {
    return Row(
      children: [
        WidgetText(
          text: title,
          fontSize: 15,
          color: Colors.blueGrey.shade500,
          fontWeight: FontWeight.bold,
        ),
        const Gap(10),
        Transform.scale(
          scale: 0.7,
          child: Switch.adaptive(
            onChanged: onChanged,
            value: value,
            activeColor: AppColors.green,
          ),
        ),
      ],
    );
  }
}
