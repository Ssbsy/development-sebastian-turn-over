import 'package:airbnb_stayfinder_mobile/src/presentation/pages/settings/security%20and%20privacy%20page/privacy_pageview.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/settings/security%20and%20privacy%20page/security_pageview.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/settings/settings_page.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

class SecurityAndPrivacyScreen extends StatefulWidget {
  const SecurityAndPrivacyScreen({super.key});

  @override
  State<SecurityAndPrivacyScreen> createState() =>
      _SecurityAndPrivacyScreenState();
}

class _SecurityAndPrivacyScreenState extends State<SecurityAndPrivacyScreen> {
  final PageController _pageController = PageController();
  int _selectedIndex = 0;

  void _onChoiceTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    _pageController.animateToPage(
      index,
      duration: Duration(milliseconds: 300),
      curve: Curves.easeInOut,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () => Get.to(() => SettingsPage()),
          icon: Icon(Icons.arrow_back_ios),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.only(
          left: 25,
          right: 25,
          top: 10,
          bottom: 10,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            WidgetText(
              text: 'Security & Privacy',
              fontWeight: FontWeight.bold,
              fontSize: 20,
              color: Colors.green,
            ),
            const Gap(10),
            WidgetText(
              text: 'Manage your account settings to protect your privacy',
              fontSize: 12,
            ),
            const Gap(25),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                GestureDetector(
                  onTap: () => _onChoiceTapped(0),
                  child: Column(
                    children: [
                      WidgetText(
                        text: 'Security',
                        fontSize: 16,
                        color: _selectedIndex == 0 ? Colors.green : Colors.grey,
                      ),
                      const Gap(10),
                      Container(
                        width: 60,
                        height: 3,
                        color: _selectedIndex == 0
                            ? Colors.green
                            : Colors.transparent,
                      ),
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: () => _onChoiceTapped(1),
                  child: Column(
                    children: [
                      WidgetText(
                        text: 'Privacy',
                        fontSize: 16,
                        color: _selectedIndex == 1 ? Colors.green : Colors.grey,
                      ),
                      const Gap(10),
                      Container(
                        width: 60,
                        height: 3,
                        color: _selectedIndex == 1
                            ? Colors.green
                            : Colors.transparent,
                      ),
                    ],
                  ),
                ),
              ],
            ),

            //Pageview
            Expanded(
              child: PageView(
                controller: _pageController,
                onPageChanged: (index) {
                  setState(() {
                    _selectedIndex = index;
                  });
                },
                children: [
                  SecurityPageview(),
                  PrivacyPageview(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
