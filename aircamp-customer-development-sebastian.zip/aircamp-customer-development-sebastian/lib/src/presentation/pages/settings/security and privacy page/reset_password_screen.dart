import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/settings/security%20and%20privacy%20page/password_reset_successful_screen.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/settings/security%20and%20privacy%20page/reset_password_services.dart';
import 'package:airbnb_stayfinder_mobile/src/services/base_api_services.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_button.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_textfield.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

class ResetPasswordScreen extends StatefulWidget {
  const ResetPasswordScreen({super.key});

  @override
  State<ResetPasswordScreen> createState() => _ResetPasswordScreenState();
}

class _ResetPasswordScreenState extends State<ResetPasswordScreen> {
  final _newPassController = TextEditingController();
  final _confirmPassController = TextEditingController();
  final resetPassword = ResetPasswordServices(BaseApiServices());
  bool isLoading = false;

  void resetPass() async {
    final newPass = _newPassController.text.trim();
    final confirmPass = _confirmPassController.text.trim();
    setState(() => isLoading = true);
    try {
      final response = await resetPassword.patchResetPassword(
        newPass: newPass,
        confirmPass: confirmPass,
      );
      print('success! $response');
      Get.to(() => PasswordResetSuccessfulScreen());
    } catch (e) {
      print('error: $e');
      setState(() => isLoading = false);
    }
  }

  @override
  void dispose() {
    _newPassController.dispose();
    _confirmPassController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: Icon(Icons.arrow_back_ios),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.only(
          left: 30,
          right: 30,
          top: 10,
          bottom: 10,
        ),
        child: Column(
          children: [
            WidgetText(
              text: 'Reset Password',
              color: AppColors.green,
              fontSize: 20,
            ),
            const Gap(15),
            WidgetText(
              text:
                  "You're one step away from regaining access to your account! Please enter a new password and confirm it to complete the password reset process.",
              color: AppColors.gray,
              fontSize: 12,
            ),
            const Gap(15),
            WidgetTextField(
              controller: _newPassController,
              fillColor: AppColors.white,
              borderColor: AppColors.black,
              borderRadius: 25,
              labelText: 'New Password',
              obscureText: true,
              keyboardType: TextInputType.visiblePassword,
              enableSuggestions: true,
            ),
            const Gap(10),
            WidgetTextField(
              controller: _confirmPassController,
              fillColor: AppColors.white,
              borderColor: AppColors.black,
              borderRadius: 25,
              labelText: 'Confirm Password',
              enableSuggestions: true,
              obscureText: true,
              keyboardType: TextInputType.visiblePassword,
            ),
            const Gap(20),
            WidgetButton(
              text: 'Send',
              onPressed: () => resetPass(),
              borderRadius: 25,
            ),
            const Gap(10),
            WidgetButton(
              text: 'Cancel',
              onPressed: () => Navigator.pop(context),
              backgroundColor: AppColors.white,
              borderColor: AppColors.black,
              borderRadius: 25,
              textColor: AppColors.black,
            )
          ],
        ),
      ),
    );
  }
}
