import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/settings/security%20and%20privacy%20page/reset_password_screen.dart';
import 'package:airbnb_stayfinder_mobile/src/services/base_api_services.dart';
import 'package:airbnb_stayfinder_mobile/src/services/forgot_password_services.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_button.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_textfield.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final _emailController = TextEditingController();
  final forgotPass = ForgotPasswordServices(BaseApiServices()); // Objectt
  bool isLoading = false;

  void forgotPassword() async {
    String email = _emailController.text.trim();
    setState(() => isLoading = true);
    FocusScope.of(context).unfocus();

    try {
      final response = await forgotPass.postRequestPasswordReset(
        email: email,
      );
      if (response is Map<String, dynamic> &&
          response.containsKey("success") &&
          response["success"] == true) {
        print("Sending email success, navigating...");

        Get.to(() => ResetPasswordScreen());
      } else {
        print(
            "Sending email failed: ${response['message']}"); // debugging purposes
      }
    } catch (e) {
      print("Exception caught: $e");
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            onPressed: () => Navigator.pop(context),
            icon: Icon(Icons.arrow_back_ios),
          ),
        ),
        body: Padding(
          padding: const EdgeInsets.only(
            left: 30.0,
            top: 10,
            bottom: 10,
            right: 30,
          ),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                WidgetText(
                  text: 'Forgot Password',
                  color: AppColors.green,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
                const Gap(10),
                WidgetText(
                  text:
                      "Enter your email address associated with your account, and we'll send you a password recovery link to help you reset your password and regain access to your account.",
                  fontSize: 12,
                  color: AppColors.gray,
                ),
                const Gap(35),
                WidgetTextField(
                  controller: _emailController,
                  keyboardType: TextInputType.emailAddress,
                  borderRadius: 25,
                  hintText: 'Email Address',
                  fillColor: AppColors.white,
                  borderColor: AppColors.black,
                ),
                const Gap(35),
                WidgetButton(
                  text: 'Send',
                  onPressed: () => forgotPassword(),
                  borderRadius: 25,
                ),
                const Gap(10),
                WidgetButton(
                  text: 'Back',
                  textColor: AppColors.black,
                  onPressed: () => Navigator.pop(context),
                  backgroundColor: AppColors.white,
                  borderColor: AppColors.black,
                  borderRadius: 25,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
