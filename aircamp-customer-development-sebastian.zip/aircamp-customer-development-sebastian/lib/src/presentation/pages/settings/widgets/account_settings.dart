import 'package:airbnb_stayfinder_mobile/src/presentation/pages/settings/language/language_screen.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/settings/payment%20method/payment_method_screen.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/settings/security%20and%20privacy%20page/personal_information_screen.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/settings/security%20and%20privacy%20page/security_and_privacy_screen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

class AccountSettings extends StatelessWidget {
  const AccountSettings({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: Column(
        spacing: 10,
        children: [
          _rows(
            Icons.person_2_outlined,
            'Personal Information',
            Icons.arrow_forward_ios,
            () => Get.to(() => PersonalInformationScreen()),
          ),
          const Divider(),
          _rows(
            Icons.security_rounded,
            'Security and Privacy',
            Icons.arrow_forward_ios,
            () {
              Get.to(() => const SecurityAndPrivacyScreen());
            },
          ),
          const Divider(),
          _rows(
            Icons.payment_outlined,
            'Payment Method',
            Icons.arrow_forward_ios,
            () => Get.to(() => const PaymentMethodScreen()),
          ),
          const Divider(),
          _rows(
            Icons.notifications_outlined,
            'Notifications',
            Icons.arrow_forward_ios,
            () {},
          ),
          const Divider(),
          _rows(
            Icons.discount_outlined,
            'Discount and Coupons',
            Icons.arrow_forward_ios,
            () {},
          ),
          const Divider(),
          _rows(
            Icons.language,
            'Language',
            Icons.arrow_forward_ios,
            () => Get.to(() => const LanguageScreen()),
          ),
          const Divider(),
        ],
      ),
    );
  }

  GestureDetector _rows(
      IconData icon, String title, IconData icon2, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            spacing: 15,
            children: [
              Icon(icon),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
          Icon(
            icon2,
            size: 20,
          ),
        ],
      ),
    );
  }
}
