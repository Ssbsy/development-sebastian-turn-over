import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';

class CustomNotification {
  static void show(BuildContext context, String message) {
    final overlay = Overlay.of(context);
    final double appBarHeight = kToolbarHeight;
    final double topPadding = MediaQuery.of(context).padding.top + appBarHeight;
    final overlayEntry = OverlayEntry(
      builder: (context) => Positioned(
        top: topPadding,
        left: 0,
        right: 0,
        child: Material(
          color: AppColors.green,
          child: AnimatedContainer(
            duration: Duration(milliseconds: 300),
            padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
            child: Center(
              child: Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                spacing: 15,
                children: [
                  Icon(
                    Icons.check,
                    color: AppColors.white,
                  ),
                  Flexible(
                    child: WidgetText(
                      text: message,
                      fontSize: 14,
                      color: AppColors.white,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
    overlay.insert(overlayEntry);

    Future.delayed(Duration(seconds: 3), () {
      overlayEntry.remove();
    });
  }
}
