import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_button.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_textfield.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class CustomTextFieldPopup {
  static void show(
    BuildContext context, {
    required TextEditingController controller,
    required String title,
    String hintText = "Enter text...",
    required VoidCallback onUpdate,
  }) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) {
        bool isPhoneField = title.toLowerCase().contains("mobile");
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
            left: 20,
            right: 20,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                spacing: 15,
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Icon(
                      Icons.arrow_back,
                      weight: 1,
                      size: 15,
                    ),
                  ),
                  WidgetText(
                    text: title,
                    fontWeight: FontWeight.bold,
                  ),
                ],
              ),
              const Gap(15),
              WidgetTextField(
                controller: controller,
                keyboardType:
                    isPhoneField ? TextInputType.phone : TextInputType.text,
                hintText: hintText,
                suffixIcon: IconButton(
                  icon: Icon(Icons.cancel, color: AppColors.green),
                  onPressed: () {
                    controller.clear();
                  },
                ),
              ),
              if (isPhoneField) ...[
                const Gap(5),
                Row(
                  spacing: 10,
                  children: [
                    Icon(
                      Icons.info_outline,
                      weight: 0.5,
                    ),
                    Expanded(
                      child: WidgetText(
                        text:
                            "You will receive an SMS or call for verification.",
                        color: Colors.grey,
                        fontSize: 10,
                      ),
                    ),
                  ],
                ),
              ],
              const Gap(10),
              WidgetButton(
                text: 'Update',
                onPressed: onUpdate,
              ),
            ],
          ),
        );
      },
    );
  }
}
