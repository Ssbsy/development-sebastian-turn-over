import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_textfield.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class CustomProfileLink extends StatelessWidget {
  const CustomProfileLink({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        WidgetText(
          text: 'Create a Custom Profile URL',
          fontWeight: FontWeight.w600,
          fontSize: 14,
        ),
        const Gap(5),
        WidgetText(
          text:
              'Elevate your online presence and make it easy for others to find you on Stayfinder by creating a custom profile URL.\n\nThis unique link will take visitors directly to your profile, where they can view your listings, read reviews, and get in touch with you.',
          fontWeight: FontWeight.w200,
        ),
        const Gap(20),
        Container(
          width: double.infinity,
          decoration: BoxDecoration(
            border: Border.all(
              color: AppColors.gray,
              width: 0.2,
            ),
            borderRadius: BorderRadius.circular(22),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: const EdgeInsets.all(12.0),
                child: WidgetText(
                  text: 'Stayfinder.ph/',
                ),
              ),
              Container(
                padding: const EdgeInsets.all(14),
                width: MediaQuery.of(context).size.width * 0.3,
                decoration: BoxDecoration(
                  color: AppColors.green,
                  borderRadius: BorderRadius.circular(22),
                ),
                child: Center(
                  child: WidgetText(
                    text: 'Copy',
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: AppColors.white,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
