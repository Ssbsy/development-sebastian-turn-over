import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/settings/hosting%20tools/widgets/custom_profile_link.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class HostingToolsScreen extends StatelessWidget {
  const HostingToolsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 20.0,
          vertical: 10,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            WidgetText(
              text: 'Hosting Tools',
              fontWeight: FontWeight.w700,
              fontSize: 20,
              color: AppColors.green,
            ),
            const Gap(10),
            WidgetText(
              text:
                  'Manage your hosting experience with our tools. Access features to help you manage your bookings, guests, and listings.',
              fontSize: 12,
            ),
            const Gap(60),
            CustomProfileLink(),
          ],
        ),
      ),
    );
  }
}
