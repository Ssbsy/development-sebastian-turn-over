import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class SelectedReservationStatus extends StatefulWidget {
  const SelectedReservationStatus({super.key});

  @override
  State<SelectedReservationStatus> createState() =>
      _SelectedReservationStatusState();
}

class _SelectedReservationStatusState extends State<SelectedReservationStatus> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const WidgetText(
          text: 'Upcoming Reservation',
         
          fontSize: 16,
          fontWeight: FontWeight.w400,
        ),
        const Gap(24),
        Stack(
          children: [
            ClipRRect(
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(16),
                topRight: Radius.circular(16),
              ),
              child: Image.asset(
                'assets/images/hotel_room_1.jpg',
                height: 165,
                width: MediaQuery.sizeOf(context).width,
                fit: BoxFit.cover,
              ),
            ),
            // Status
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                decoration: BoxDecoration(
                  color: AppColors.yellow,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Padding(
                  padding: EdgeInsets.all(8.0),
                  child: WidgetText(
                    text: 'Pending',
                    color: AppColors.gray,
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
            ),
          ],
        ),
        Container(
          decoration: BoxDecoration(
            color: AppColors.white,
            borderRadius: const BorderRadius.only(
              bottomLeft: Radius.circular(16),
              bottomRight: Radius.circular(16),
            ),
            boxShadow: [
              BoxShadow(
                color: AppColors.black.withOpacity(0.2),
                blurRadius: 12,
                spreadRadius: 0,
              ),
            ],
          ),
          child: const Padding(
            padding: EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                WidgetText(
                  text: 'Manila\nPrivate room in home hosted by David',
               
                  fontSize: 16,
                  fontWeight: FontWeight.w400,
                ),
                Divider(),
                SizedBox(
                  height: 115,
                  child: Row(
                    children: [
                      WidgetText(
                        text: 'Feb\n13 - 14\n2025',
                       
                        fontSize: 16,
                        fontWeight: FontWeight.w400,
                      ),
                      Gap(8),
                      VerticalDivider(),
                      Gap(8),
                      WidgetText(
                        text: 'MNL, Metro Manila\nPhilippines',
                        color: AppColors.black,
                        fontSize: 16,
                        fontWeight: FontWeight.w400,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
