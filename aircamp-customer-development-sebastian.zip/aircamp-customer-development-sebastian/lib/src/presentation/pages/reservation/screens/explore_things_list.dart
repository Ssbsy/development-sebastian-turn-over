import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class ExploreThingsList extends StatefulWidget {
  const ExploreThingsList({super.key});

  @override
  State<ExploreThingsList> createState() => _ExploreThingsListState();
}

class _ExploreThingsListState extends State<ExploreThingsList> {
  // List of experiences
  final List<Map<String, String>> experiences = [
    {
      'image': 'assets/images/hotel_room_1.jpg',
      'title': 'Just for you',
      'count': '19 experiences'
    },
    {
      'image': 'assets/images/hotel_room_1.jpg',
      'title': 'Adventure awaits',
      'count': '12 experiences'
    },
    {
      'image': 'assets/images/hotel_room_1.jpg',
      'title': 'Relax and unwind',
      'count': '7 experiences'
    },
   
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const WidgetText(
          text: 'Explore things to do near Metro Manila',
          
          fontSize: 16,
          fontWeight: FontWeight.w400,
        ),
        const Gap(12),
        SizedBox(
          height: 60,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: experiences.length,
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.asset(
                        experiences[index]['image']!,
                        height: 55,
                        width: 55,
                        fit: BoxFit.cover,
                      ),
                    ),
                    const Gap(12),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        WidgetText(
                          text: experiences[index]['title']!,
                          
                          fontSize: 16,
                          fontWeight: FontWeight.w400,
                        ),
                        WidgetText(
                          text: experiences[index]['count']!,
                          
                          fontSize: 12,
                          fontWeight: FontWeight.w300,
                        ),
                      ],
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
