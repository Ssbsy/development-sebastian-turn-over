import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/reservation/screens/explore_things_list.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/reservation/screens/selected_reservation_status.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';

class ReservationPage extends StatefulWidget {
  const ReservationPage({super.key});

  @override
  State<ReservationPage> createState() => _ReservationPageState();
}

class _ReservationPageState extends State<ReservationPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        title: const WidgetText(
          text: 'Reservation',
          color: AppColors.green,
          fontSize: 20,
          fontWeight: FontWeight.w700,
        ),
      ),
      body: Padding(
        padding: EdgeInsets.all(24),
        child: ListView(
          children: [
            SelectedReservationStatus(),
            Spacer(),
            ExploreThingsList(),
          ],
        ),
      ),
    );
  }
}
