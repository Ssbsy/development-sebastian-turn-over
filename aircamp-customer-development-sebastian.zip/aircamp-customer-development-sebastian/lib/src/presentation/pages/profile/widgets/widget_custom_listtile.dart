import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class WidgetCustomListtile extends StatelessWidget {
  final String? leadingText;
  final String? subText;
  final VoidCallback onPressed;
  const WidgetCustomListtile(
      {super.key, this.leadingText, this.subText, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.all(0),
        elevation: 0,
        backgroundColor: AppColors.transparent,
        shadowColor: AppColors.transparent,
      ),
      onPressed: onPressed,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                WidgetText(
                  text: leadingText,
                  color: AppColors.gray,
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                ),
                const Spacer(),
                WidgetText(
                  text: subText,
                  
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
                const Gap(12),
                const Icon(
                  Icons.arrow_forward_ios,
                  size: 12,
                ),
              ],
            ),
            const Divider(),
          ],
        ),
      ),
    );
  }
}
