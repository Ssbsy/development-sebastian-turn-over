import 'package:airbnb_stayfinder_mobile/src/presentation/onboarding/agreement.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import '../../core/constants/colors.dart';
import '../../shared/widgets/widget_button.dart';
import '../../shared/widgets/widget_text.dart';

class TurnNotifications extends StatefulWidget {
  const TurnNotifications({super.key});

  @override
  State<TurnNotifications> createState() => _TurnNotificationsState();
}

class _TurnNotificationsState extends State<TurnNotifications> {
  Widget _buildButton(String text, Color backgroundColor, Color textColor,
      FontWeight fontWeight) {
    return Expanded(
      child: WidgetButton(
        text: text,
        textColor: textColor,
        backgroundColor: backgroundColor,
        fontSize: 15,
        fontWeight: fontWeight,
        borderRadius: 8,
        onPressed: () {
          Get.to(() => const Agreement());
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: const SizedBox.shrink(),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(Icons.notifications, color: AppColors.green, size: 50),
            const WidgetText(
              text: 'Turn on notifications?',
              fontSize: 36,
              fontWeight: FontWeight.w400,
            ),
            const Gap(12),
            WidgetText(
              text:
                  'Don’t miss important messages like check in details and account activity\n\nGet travel details, personalized recommendations, and more',
              color: AppColors.black.withOpacity(0.75),
              fontSize: 20,
              fontWeight: FontWeight.w400,
            ),
            const Spacer(),
            Row(
              children: [
                _buildButton('Yes Notify me!', AppColors.green, AppColors.white,
                    FontWeight.w700),
                _buildButton('Skip', AppColors.transparent, AppColors.gray,
                    FontWeight.w400),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
