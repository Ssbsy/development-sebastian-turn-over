import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';

import '../../core/constants/colors.dart';
import '../../shared/widgets/widget_button.dart';
import '../../shared/widgets/widget_text.dart';
import '../../shared/widgets/bottom_nav_bar.dart';

class Agreement extends StatefulWidget {
  const Agreement({super.key});

  @override
  State<Agreement> createState() => _AgreementState();
}

class _AgreementState extends State<Agreement> {
  Widget _buildText(String text,
      {double fontSize = 16,
      FontWeight fontWeight = FontWeight.w400,
      Color color = AppColors.black}) {
    return WidgetText(
        text: text, color: color, fontSize: fontSize, fontWeight: fontWeight);
  }

  Widget _buildButton(String text,
      {Color textColor = AppColors.white,
      Color backgroundColor = AppColors.green,
      VoidCallback? onPressed,
      Color? borderColor}) {
    return WidgetButton(
      text: text,
      textColor: textColor,
      backgroundColor: backgroundColor,
      fontSize: 20,
      borderColor: borderColor,
      fontWeight: FontWeight.w700,
      borderRadius: 25,
      onPressed: onPressed!,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(
      //   leading: const SizedBox.shrink(),
      //   backgroundColor: AppColors.white,
      // ),
      body: Padding(
        padding: EdgeInsets.all(20.0),
        child: SingleChildScrollView(
          child: SizedBox(
            height: MediaQuery.of(context).size.height * 1.03,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Image.asset('assets/icons/app_logo.png', height: 90),
                _buildText('Our Stayfinder agreement',
                    fontSize: 14, fontWeight: FontWeight.w600),
                const Gap(8),
                _buildText(
                    'The Stayfinder, place where anyone is always welcome',
                    fontSize: 20,
                    fontWeight: FontWeight.w700),
                const Gap(14),
                _buildText(
                  'By using the StayFinder application, you agree to abide by our terms of service and privacy policy. '
                  'You consent to the collection, use, and sharing of your personal data as outlined in our privacy policy. '
                  'StayFinder reserves the right to update or modify these terms at any time. Your continued use of the app constitutes acceptance of any changes.',
                  fontSize: 16,
                ),
                const Spacer(),
                _buildButton('Agree an Proceed',
                    backgroundColor: AppColors.green,
                    onPressed: () => Get.offAll(() => const BottomNavBar())),
                const Gap(8),
                _buildButton('Decline',
                    backgroundColor: AppColors.white,
                    textColor: AppColors.black,
                    borderColor: AppColors.black,
                    onPressed: () {}),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
