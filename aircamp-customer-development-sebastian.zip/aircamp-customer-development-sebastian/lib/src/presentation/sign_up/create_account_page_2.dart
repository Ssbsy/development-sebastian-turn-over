import 'dart:convert';

import 'package:airbnb_stayfinder_mobile/src/presentation/auth/login_page.dart';
import 'package:airbnb_stayfinder_mobile/src/services/base_api_services.dart';
import 'package:airbnb_stayfinder_mobile/src/services/register_services.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_textfield.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';

import '../../core/constants/colors.dart';
import '../../shared/widgets/widget_button.dart';
import '../../shared/widgets/widget_text.dart';

class CreateAccountPage2 extends StatefulWidget {
  final TextEditingController firstName;
  final TextEditingController lastName;
  final TextEditingController dateOfBirth;
  final TextEditingController emailAddress;
  const CreateAccountPage2({
    super.key,
    required this.firstName,
    required this.lastName,
    required this.emailAddress,
    required this.dateOfBirth,
  });

  @override
  State<CreateAccountPage2> createState() => _CreateAccountPage2State();
}

class _CreateAccountPage2State extends State<CreateAccountPage2> {
  late final TextEditingController fullName;

  final firstName = TextEditingController();
  final lastName = TextEditingController();
  final dateOfBirth = TextEditingController();
  final phoneNumber = TextEditingController();
  final password = TextEditingController();
  final confirmPassword = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  final RegisterServices _register = RegisterServices(BaseApiServices());

  bool isLoading = false;

  @override
  void initState() {
    super.initState();

    fullName = TextEditingController(
      text: "${widget.firstName.text} ${widget.lastName.text}",
    );
  }

  void registerUser() async {
    print("Login process started...");
    setState(() => isLoading = true);
    FocusScope.of(context).unfocus();

    String firstName = widget.firstName.text.trim();
    String lastName = widget.lastName.text.trim();
    String email = widget.emailAddress.text.trim();
    String dateOfBirth = widget.dateOfBirth.text.trim();
    String phoneNumber = this.phoneNumber.text.trim();
    String password = this.password.text.trim();
    String confirmPassword = this.confirmPassword.text.trim();

    // Prevent sending empty phone number and password
    if (phoneNumber.isEmpty || password.isEmpty) {
      print("Phone number and password are required.");
      setState(() => isLoading = false);
      return;
    }

    // Validate if passwords match
    if (password != confirmPassword) {
      print("Passwords do not match.");
      setState(() => isLoading = false);
      return;
    }

    // Ensure phone number is numeric
    if (!RegExp(r'^[0-9]+$').hasMatch(phoneNumber)) {
      print("Invalid phone number format.");
      setState(() => isLoading = false);
      return;
    }

    try {
      print("Sending Register request...");
      print("Request Body: ${jsonEncode({
            'email': email,
            'password': password,
            'firstName': firstName,
            'lastName': lastName,
            'phoneNo': phoneNumber,
            'birthdate': dateOfBirth,
          })}");

      final response = await _register.postRegister(
        email: email,
        password: password,
        firstName: firstName,
        lastName: lastName,
        phoneNo: phoneNumber,
        birthdate: dateOfBirth,
      );

      print("Response received: $response");

      if (response is Map<String, dynamic> &&
          response.containsKey("success") &&
          response["success"] == true) {
        print("Register complete, navigating...");

        if (_formKey.currentState!.validate()) {
          Get.to(() => LoginPage());
        }
      } else {
        print("Login failed: ${response['message']}");
      }
    } catch (e) {
      print("Exception caught: $e");
    } finally {
      print("Resetting loading state...");
      setState(() => isLoading = false);
    }
  }

  Widget _formTextField(
    String? titleText,
    TextEditingController? controller,
    TextInputType? keyboardType,
    String? hintText,
    TextInputFormatter? inputFormatters,
    bool? obscureText,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        WidgetText(
          text: titleText,
          color: AppColors.gray,
          fontSize: 14,
          fontWeight: FontWeight.w400,
        ),
        const Gap(8),
        WidgetTextField(
          enabled: true,
          controller: controller,
          keyboardType: keyboardType,
          obscureText: obscureText!,
          hintText: hintText,
          fillColor: AppColors.white,
          borderColor: AppColors.black.withOpacity(0.2),
          borderRadius: 8,
          inputFormatters: inputFormatters != null ? [inputFormatters] : null,
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'This field is required';
            }
            return null;
          },
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () {
            Get.to(() => LoginPage());
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Center(
                  child: WidgetText(
                    text: 'Create your account',
                    fontSize: 24,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const Gap(30),
                _formTextField('Name', fullName, TextInputType.text,
                    'ex: Juan Dela Cruz', null, false),
                const Gap(20),
                _formTextField('Phone Number', phoneNumber, TextInputType.phone,
                    'ex: 09555111222', null, false),
                const Gap(20),
                _formTextField('Password', password,
                    TextInputType.visiblePassword, '*********', null, true),
                const Gap(20),
                _formTextField('Confirm Password', confirmPassword,
                    TextInputType.visiblePassword, '*********', null, true),
                const Gap(15),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Checkbox.adaptive(
                      value: false,
                      onChanged: null,
                    ),
                    WidgetText(
                      text: 'I understood the ',
                      fontSize: 12,
                      fontWeight: FontWeight.w400,
                    ),
                    WidgetText(
                      text: 'terms & policy',
                      color: AppColors.green,
                      fontSize: 12,
                      fontWeight: FontWeight.w400,
                    ),
                  ],
                ),
                const Gap(15),
                WidgetButton(
                  text: 'SIGN UP',
                  textColor: AppColors.white,
                  backgroundColor: AppColors.green,
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  borderRadius: 8,
                  onPressed: () {
                    registerUser();
                  },
                ),
                const Gap(24),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const WidgetText(
                      text: 'Have an account? ',
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                    ),
                    GestureDetector(
                      onTap: () {
                        Get.to(() => LoginPage());
                      },
                      child: const WidgetText(
                        text: 'SIGN IN',
                        color: AppColors.green,
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
