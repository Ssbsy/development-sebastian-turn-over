import 'package:airbnb_stayfinder_mobile/src/presentation/sign_up/create_account_page_2.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_textfield.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';

import '../../core/constants/colors.dart';
import '../../shared/widgets/widget_button.dart';
import '../../shared/widgets/widget_text.dart';

class CreateAccountPage extends StatefulWidget {
  const CreateAccountPage({super.key});

  @override
  State<CreateAccountPage> createState() => _CreateAccountPageState();
}

class _CreateAccountPageState extends State<CreateAccountPage> {
  final firstName = TextEditingController();
  final lastName = TextEditingController();
  final dateOfBirth = TextEditingController();
  final emailAddress = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  Future<void> _selectDate() async {
    DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.light(
              primary: Colors.green,
              onPrimary: Colors.white,
              onSurface: Colors.black,
            ),
            dialogTheme: DialogThemeData(backgroundColor: Colors.white),
          ),
          child: Center(
            child: Material(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              child: Container(
                constraints: const BoxConstraints(maxWidth: 400),
                child: child,
              ),
            ),
          ),
        );
      },
    );

    if (pickedDate != null) {
      setState(() {
        dateOfBirth.text =
            "${pickedDate.year}-${pickedDate.month.toString().padLeft(2, '0')}-${pickedDate.day.toString().padLeft(2, '0')}";
      });
    }
  }

  Widget _formTextField(
    String? titleText,
    TextEditingController? controller,
    TextInputType? keyboardType,
    String? hintText,
    TextInputFormatter? inputFormatters,
    bool? obscureText,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (titleText != null && titleText.isNotEmpty)
          WidgetText(
            text: titleText,
            color: AppColors.green,
            fontSize: 14,
            fontWeight: FontWeight.w400,
          ),
        const Gap(8),
        controller == dateOfBirth
            ? GestureDetector(
                onTap: _selectDate,
                child: AbsorbPointer(
                  child: WidgetTextField(
                    enabled: true,
                    controller: controller,
                    keyboardType: keyboardType,
                    obscureText: obscureText ?? false,
                    hintText: hintText,
                    fillColor: AppColors.white,
                    borderColor: AppColors.black.withOpacity(0.2),
                    borderRadius: 16,
                    inputFormatters:
                        inputFormatters != null ? [inputFormatters] : null,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'This field is required';
                      }
                      return null;
                    },
                  ),
                ),
              )
            : WidgetTextField(
                enabled: true,
                controller: controller,
                keyboardType: keyboardType,
                obscureText: obscureText ?? false,
                hintText: hintText,
                fillColor: AppColors.white,
                borderColor: AppColors.black.withOpacity(0.2),
                borderRadius: 16,
                inputFormatters:
                    inputFormatters != null ? [inputFormatters] : null,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'This field is required';
                  }
                  return null;
                },
              ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        body: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Form(
            key: _formKey,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Center(
                    child: Padding(
                      padding: EdgeInsets.only(top: 15.0),
                      child: WidgetText(
                        text: 'Fill up to sign in',
                        fontSize: 20,
                        fontWeight: FontWeight.w600,
                        color: AppColors.green,
                      ),
                    ),
                  ),
                  const Gap(12),
                  _formTextField('Full Name', firstName, TextInputType.text,
                      'First Name', null, false),
                  // const Gap(12),
                  _formTextField(null, lastName, TextInputType.text,
                      'Last Name', null, false),
                  const Gap(12),
                  WidgetText(
                    text:
                        'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
                    fontSize: 8,
                    color: AppColors.black,
                  ),
                  const Gap(12),
                  _formTextField('Date of Birth', dateOfBirth,
                      TextInputType.none, 'Month/Date/Year', null, false),
                  const Gap(12),
                  _formTextField('Contact Information', emailAddress,
                      TextInputType.emailAddress, 'Email Address', null, false),
                  const Gap(12),
                  WidgetText(
                    text:
                        'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
                    fontSize: 8,
                    color: AppColors.black,
                  ),
                  const Gap(24),
                  WidgetButton(
                    text: 'Proceed',
                    textColor: AppColors.white,
                    backgroundColor: AppColors.green,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    borderRadius: 8,
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        Get.to(
                          () => CreateAccountPage2(
                            firstName: firstName,
                            lastName: lastName,
                            dateOfBirth: dateOfBirth,
                            emailAddress: emailAddress,
                          ),
                        );
                      }
                    },
                  ),
                  const Gap(24),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
