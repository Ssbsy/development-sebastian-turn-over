import 'package:airbnb_stayfinder_mobile/src/presentation/onboarding/turn_notifications.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/sign_up/create_account_page.dart';
import 'package:airbnb_stayfinder_mobile/src/services/base_api_services.dart';
import 'package:airbnb_stayfinder_mobile/src/services/login_services.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_button.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_textfield.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/constants/colors.dart';
import '../../shared/widgets/widget_text.dart';

/* account 
  "emailOrPhone": "bastyparohinog@gmail.com",
  "password": "pass123"
*/

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _emailOrPhone = TextEditingController();
  final _password = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  final LoginServices login = LoginServices(BaseApiServices());

  bool isLoading = false;

  void loginUser() async {
    print("Login process started..."); // for debugging purposes
    setState(() => isLoading = true);
    FocusScope.of(context).unfocus();

    var emailOrPhone = _emailOrPhone.text.trim();
    String password = _password.text.trim();

    try {
      print("Sending login request..."); // same for debugging purposes
      final response = await login.postLogin(
        emailOrPhone: emailOrPhone,
        password: password,
      );

      print("Response received: $response"); // another debugging purpses

      if (response is Map<String, dynamic> &&
          response.containsKey("success") &&
          response["success"] == true) {
        print("Login successful, navigating...");

        final prefs = await SharedPreferences.getInstance();
        prefs.setString("auth_token", response["token"]);

        Get.to(() => TurnNotifications());
      } else {
        print("Login failed: ${response['message']}"); // debugging purposes
      }
    } catch (e) {
      print("Exception caught: $e"); // for debugging
    } finally {
      print("Resetting loading state..."); // debugging
      setState(() => isLoading = false);
    }
  }

  @override
  void dispose() {
    _emailOrPhone.dispose();
    _password.dispose();
    super.dispose();
  }

  Widget _loginFirebaseButton(
    String? imageAsset,
    String? text,
    VoidCallback onPressed,
  ) {
    return WidgetButton(
      imageAsset: imageAsset,
      text: text!,
      textColor: AppColors.black,
      backgroundColor: AppColors.white,
      shadowColor: AppColors.black,
      elevation: 2,
      fontSize: 12,
      fontWeight: FontWeight.w700,
      borderRadius: 8,
      onPressed: onPressed,
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
        ),
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15.0),
          child: Form(
            key: _formKey,
            child: SingleChildScrollView(
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  minHeight: MediaQuery.of(context).size.height,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Row(
                      children: [
                        WidgetText(
                          text: 'Welcome to Stay',
                          color: AppColors.green,
                          fontSize: 22,
                          fontWeight: FontWeight.w600,
                        ),
                        WidgetText(
                          text: 'finder',
                          fontSize: 22,
                          fontWeight: FontWeight.w600,
                        ),
                      ],
                    ),
                    const Gap(20),
                    const WidgetText(
                      text: 'Log in or Sign Up',
                      color: AppColors.green,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                    const Gap(12),
                    WidgetTextField(
                      enableSuggestions: true,
                      controller: _emailOrPhone,
                      keyboardType: TextInputType.emailAddress,
                      hintText: '@gmail.com',
                      fillColor: AppColors.white,
                      borderColor: AppColors.black,
                      borderRadius: 25,
                    ),
                    const Gap(8),
                    WidgetTextField(
                      enableSuggestions: true,
                      controller: _password,
                      keyboardType: TextInputType.visiblePassword,
                      maxLength: 10,
                      labelText: 'password',
                      obscureText: true,
                      fillColor: AppColors.white,
                      borderColor: AppColors.black,
                      borderRadius: 25,
                    ),
                    const Gap(8),
                    const WidgetText(
                      text: 'We will call or text the number you have provided',
                      fontSize: 12,
                      fontWeight: FontWeight.w400,
                    ),
                    const Gap(15),
                    const WidgetText(
                      text:
                          'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
                      fontSize: 12,
                      fontWeight: FontWeight.w400,
                    ),
                    const Gap(15),
                    WidgetButton(
                      text: 'Log in',
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                      borderRadius: 25,
                      onPressed: () {
                        loginUser();
                        //Get.to(() => TurnNotifications());
                      },
                    ),
                    // const Spacer(),
                    Gap(30),
                    const Center(
                      child: WidgetText(
                        text: 'or sign in with',
                        fontSize: 12,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                    const Gap(8),
                    _loginFirebaseButton(
                      'assets/icons/facebook.png',
                      'Continue with Facebook',
                      () {},
                    ),
                    const Gap(8),
                    _loginFirebaseButton(
                      'assets/icons/google.png',
                      'Continue with Gmail',
                      () {},
                    ),
                    const Gap(8),
                    _loginFirebaseButton(
                      'assets/icons/apple.png',
                      'Continue with Apple',
                      () {},
                    ),
                    const Gap(12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const WidgetText(
                          text: "Don't have an account? ",
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                        ),
                        TextButton(
                          onPressed: () {
                            Get.to(() => const CreateAccountPage());
                          },
                          child: const WidgetText(
                            text: 'SIGN UP',
                            color: AppColors.green,
                            fontSize: 14,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
