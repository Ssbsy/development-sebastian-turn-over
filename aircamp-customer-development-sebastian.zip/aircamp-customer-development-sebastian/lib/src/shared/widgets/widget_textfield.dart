import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

class WidgetTextField extends StatefulWidget {
  final String? hintText;
  final TextEditingController? controller;
  final TextInputType? keyboardType;
  final bool obscureText;
  final bool enabled;
  final Color? fillColor;
  final Color? borderColor;
  final Widget? prefixIcon;
  final IconButton? suffixIcon;
  final String? labelText;
  final String? prefixText;
  final String? Function(String?)? validator;
  final int? maxLength;
  final int? maxLines;
  final FocusNode? focusNode;
  final void Function(String)? onFieldSubmitted;
  final void Function(String)? onChanged;
  final List<TextInputFormatter>? inputFormatters;
  final bool enableSuggestions;
  final double? borderRadius;
  final FocusNode? nextFocusNode;

  const WidgetTextField({
    this.hintText,
    this.controller,
    this.keyboardType,
    this.obscureText = false,
    this.enabled = true,
    this.prefixIcon,
    this.suffixIcon,
    this.labelText,
    this.prefixText,
    this.validator,
    this.focusNode,
    this.onFieldSubmitted,
    this.onChanged,
    this.maxLength,
    this.maxLines,
    this.fillColor,
    this.inputFormatters,
    this.enableSuggestions = true,
    super.key,
    this.borderColor,
    this.borderRadius,
    this.nextFocusNode,
  });

  @override
  // ignore: library_private_types_in_public_api
  _WidgetTextFieldState createState() => _WidgetTextFieldState();
}

class _WidgetTextFieldState extends State<WidgetTextField> {
  bool _isPasswordVisible = false;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      cursorColor: AppColors.green,
      controller: widget.controller,
      keyboardType: widget.keyboardType,
      obscureText: widget.obscureText ? !_isPasswordVisible : false,
      maxLength: widget.maxLength,
      maxLines: widget.maxLines ?? 1,
      enabled: widget.enabled,
      style: GoogleFonts.inter(
        color: AppColors.black,
        fontSize: 14,
      ),
      focusNode: widget.focusNode,
      onFieldSubmitted: widget.onFieldSubmitted,
      onChanged: widget.onChanged,
      inputFormatters: widget.inputFormatters,
      enableSuggestions: widget.enableSuggestions,
      decoration: InputDecoration(
        prefixIcon: widget.prefixIcon,
        hoverColor: AppColors.green,
        floatingLabelBehavior: FloatingLabelBehavior.never,
        counterText: '',
        prefixText: widget.prefixText,
        prefixStyle: GoogleFonts.inter(
          color: AppColors.black,
          fontSize: 14,
        ),
        hintText: widget.hintText,
        hintStyle: GoogleFonts.inter(
          color: AppColors.black,
          fontSize: 14,
        ),
        filled: true,
        fillColor: widget.fillColor,
        suffixIcon: widget.keyboardType == TextInputType.visiblePassword
            ? IconButton(
                icon: Icon(
                  _isPasswordVisible ? Icons.visibility_off : Icons.visibility,
                ),
                onPressed: () {
                  setState(() {
                    _isPasswordVisible = !_isPasswordVisible;
                  });
                },
              )
            : widget.suffixIcon,
        labelText: widget.labelText,
        labelStyle: GoogleFonts.inter(
          color: AppColors.black,
          fontSize: 14,
        ),
        border: OutlineInputBorder(
          borderSide: BorderSide(
            color: widget.borderColor ?? AppColors.transparent,
          ),
          borderRadius: BorderRadius.circular(widget.borderRadius ?? 8),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: widget.borderColor ?? AppColors.transparent,
          ),
          borderRadius: BorderRadius.circular(widget.borderRadius ?? 8),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: const BorderSide(
            color: AppColors.green,
          ),
          borderRadius: BorderRadius.circular(widget.borderRadius ?? 8),
        ),
      ),
      validator: widget.validator,
    );
  }
}
