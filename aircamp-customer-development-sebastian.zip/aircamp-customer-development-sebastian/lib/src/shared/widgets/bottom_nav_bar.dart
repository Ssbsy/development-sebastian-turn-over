import 'package:airbnb_stayfinder_mobile/src/presentation/pages/settings/settings_page.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_dialog.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/explore/explore_page.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/inbox/inbox_page.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/profile/profile_page.dart';
import 'package:airbnb_stayfinder_mobile/src/presentation/pages/reservation/reservation_page.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../app.dart';
import '../../presentation/auth/login_page.dart';
import '../../core/constants/colors.dart';

class BottomNavBar extends StatefulWidget {
  const BottomNavBar({super.key});

  @override
  State<BottomNavBar> createState() => _BottomNavBarState();
}

class _BottomNavBarState extends State<BottomNavBar> {
  int _selectedIndex = 0;
  late PageController _pageController;

  @override
  void initState() {
    super.initState();
    _pageController = PageController(initialPage: _selectedIndex);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  final List<Widget> _pages = [
    const ExplorePage(),
    const ReservationPage(),
    const InboxPage(),
    const SettingsPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return AppLifeCycleListener(
      // ignore: deprecated_member_use
      child: WillPopScope(
        onWillPop: () async {
          _showLogoutDialog();
          return false;
        },
        child: Scaffold(
          body: PageView(
            physics: const NeverScrollableScrollPhysics(),
            controller: _pageController,
            children: _pages,
            onPageChanged: (index) {
              setState(() {
                _selectedIndex = index;
              });
            },
          ),
          bottomNavigationBar: BottomNavigationBar(
            backgroundColor: AppColors.white,
            type: BottomNavigationBarType.fixed,
            unselectedLabelStyle: GoogleFonts.inter(
              fontSize: 10,
              fontWeight: FontWeight.normal,
            ),
            selectedLabelStyle: GoogleFonts.inter(
              fontSize: 10,
              fontWeight: FontWeight.w500,
            ),
            selectedItemColor: AppColors.green,
            unselectedItemColor: const Color(0xFF1C1B1F),
            currentIndex: _selectedIndex,
            onTap: _onItemTapped,
            items: [
              BottomNavigationBarItem(
                icon: _buildNavItem('assets/icons/nav_explore.png', 0),
                label: 'Explore',
              ),
              BottomNavigationBarItem(
                icon: _buildNavItem('assets/icons/nav_reservation.png', 1),
                label: 'Reservation',
              ),
              BottomNavigationBarItem(
                icon: _buildNavItem('assets/icons/nav_inbox.png', 2),
                label: 'Inbox',
              ),
              BottomNavigationBarItem(
                icon: _buildNavItem('assets/icons/nav_profile.png', 3),
                label: 'Profile',
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem(String imagePath, int index) {
    return ColorFiltered(
      colorFilter: ColorFilter.mode(
        _selectedIndex == index ? AppColors.green : AppColors.transparent,
        BlendMode.srcATop,
      ),
      child: Image.asset(
        imagePath,
        height: 24,
        width: 24,
      ),
    );
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
      _pageController.jumpToPage(index);
    });
  }

  void _showLogoutDialog() {
    showAdaptiveDialog(
      barrierDismissible: true,
      context: context,
      builder: (BuildContext context) {
        return WidgetDialog(
          titleText: 'Logout',
          messageText: 'Are you sure do you want to logout?',
          cancelText: 'Back',
          continueText: 'Continue',
          continueOnpressed: () {
            Get.offAll(() => const LoginPage());
          },
        );
      },
    );
  }
}
