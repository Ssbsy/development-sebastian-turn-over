import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';

class WidgetButton extends StatefulWidget {
  final String text;
  final VoidCallback onPressed;
  final Color? borderColor;
  final Color? backgroundColor;
  final IconData? icon;
  final Color? iconColor;
  final Color? textColor;
  final double? fontSize;
  final double? borderRadius;
  final String? imageAsset;
  final FontWeight? fontWeight;
  final double? iconSize;
  final MainAxisAlignment? mainAxisAlignment;
  final double? elevation;
  final Color? shadowColor;

  const WidgetButton({
    super.key,
    required this.text,
    required this.onPressed,
    this.backgroundColor,
    this.textColor,
    this.fontSize,
    this.borderRadius,
    this.fontWeight,
    this.borderColor,
    this.imageAsset,
    this.icon,
    this.iconColor,
    this.iconSize,
    this.mainAxisAlignment,
    this.elevation,
    this.shadowColor,
  });

  @override
  State<WidgetButton> createState() => _WidgetButtonState();
}

class _WidgetButtonState extends State<WidgetButton> {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 50,
      child: ElevatedButton(
        onPressed: widget.onPressed,
        style: ElevatedButton.styleFrom(
          shape: RoundedRectangleBorder(
            side: BorderSide(
              color: widget.borderColor ?? AppColors.transparent,
            ),
            borderRadius: BorderRadius.circular(widget.borderRadius ?? 8),
          ),
          elevation: widget.elevation,
          shadowColor: widget.shadowColor ?? AppColors.transparent,
          backgroundColor: widget.backgroundColor ?? AppColors.green,
        ),
        child: Row(
          mainAxisAlignment:
              widget.mainAxisAlignment ?? MainAxisAlignment.center,
          children: [
            if (widget.imageAsset != null && widget.imageAsset!.isNotEmpty)
              Row(
                children: [
                  Image.asset(
                    widget.imageAsset!,
                    height: 24,
                  ),
                  const Gap(8),
                ],
              ),
            if (widget.icon != null)
              Row(
                children: [
                  Icon(
                    widget.icon,
                    color: widget.iconColor,
                    size: widget.iconSize,
                  ),
                  const Gap(8),
                ],
              ),
            Text(
              widget.text,
              style: GoogleFonts.roboto(
                color: widget.textColor ?? AppColors.white,
                fontSize: widget.fontSize ?? 14,
                fontWeight: widget.fontWeight ?? FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
