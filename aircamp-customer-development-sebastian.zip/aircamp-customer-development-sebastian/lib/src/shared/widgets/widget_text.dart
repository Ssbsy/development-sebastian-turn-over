import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class WidgetText extends StatefulWidget {
  final String? text;
  final double? fontSize;
  final FontWeight? fontWeight;
  final Color? color;
  final TextAlign? textAlign;
  final bool? underline;
  final bool? strikethrough;

  const WidgetText({
    super.key,
    this.text,
    this.fontSize,
    this.fontWeight,
    this.color,
    this.textAlign,
    this.underline = false,
    this.strikethrough = false,
  });

  @override
  State<WidgetText> createState() => _WidgetTextState();
}

class _WidgetTextState extends State<WidgetText> {
  @override
  Widget build(BuildContext context) {
    return Text(
      widget.text ?? '',
      style: GoogleFonts.poppins(
        fontSize: widget.fontSize,
        fontWeight: widget.fontWeight,
        color: widget.color ?? AppColors.black,
        decoration: _getTextDecoration(),
      ),
      textAlign: widget.textAlign,
    );
  }

  TextDecoration _getTextDecoration() {
    if (widget.underline == true && widget.strikethrough == true) {
      return TextDecoration.combine(
          [TextDecoration.underline, TextDecoration.lineThrough]);
    } else if (widget.underline == true) {
      return TextDecoration.underline; // Only underline
    } else if (widget.strikethrough == true) {
      return TextDecoration.lineThrough; // Only strikethrough
    } else {
      return TextDecoration.none; // No decoration
    }
  }
}
