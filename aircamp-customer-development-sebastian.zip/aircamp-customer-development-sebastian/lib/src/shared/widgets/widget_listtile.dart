import 'package:airbnb_stayfinder_mobile/src/core/constants/colors.dart';
import 'package:airbnb_stayfinder_mobile/src/shared/widgets/widget_text.dart';
import 'package:flutter/material.dart';

class WidgetListTile extends StatefulWidget {
  final String? imageAsset;
  final String? text;
  final FontWeight? headerTextFontWeight;
  final FontWeight? subTextFontWeight;
  final Color? headerTextColor;
  final Color? subTextColor;
  final String? subText;
  final bool useCircleAvatar;
  final bool showTrailingIcon;
  final IconData? trailingIcon;
  final String? trailingText;
  final Color? trailingIconColor;

  final void Function()? onPressed;
  const WidgetListTile({
    super.key,
    this.imageAsset,
    this.text,
    this.onPressed,
    this.subText,
    this.headerTextFontWeight,
    this.subTextFontWeight,
    this.headerTextColor,
    this.subTextColor,
    this.useCircleAvatar = false,
    this.showTrailingIcon = true,
    this.trailingIcon,
    this.trailingText,
    this.trailingIconColor,
  });

  @override
  State<WidgetListTile> createState() => _WidgetListTileState();
}

class _WidgetListTileState extends State<WidgetListTile> {
  @override
  Widget build(BuildContext context) {
    return ListTile(
      tileColor: AppColors.transparent,
      leading: widget.useCircleAvatar
          ? (widget.imageAsset != null && widget.imageAsset!.isNotEmpty
              ? CircleAvatar(
                  backgroundImage: AssetImage(widget.imageAsset!),
                  radius: 20,
                )
              : const CircleAvatar(
                  radius: 20,
                  child: Icon(Icons.person),
                ))
          : (widget.imageAsset != null && widget.imageAsset!.isNotEmpty
              ? Image.asset(
                  widget.imageAsset!,
                  height: 24,
                )
              : null),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          WidgetText(
            text: widget.text,
            fontSize: 14,
            color: widget.headerTextColor,
            fontWeight: widget.headerTextFontWeight,
          ),
          if (widget.subText != null && widget.subText!.isNotEmpty)
            WidgetText(
              text: widget.subText,
              color: widget.subTextColor,
              fontSize: 14,
              fontWeight: widget.subTextFontWeight,
            ),
        ],
      ),
      trailing: widget.showTrailingIcon
          ? (widget.trailingIcon != null
              ? Icon(widget.trailingIcon,
                  size: 16, color: widget.trailingIconColor)
              : (widget.trailingText != null
                  ? WidgetText(
                      text: widget.trailingText!,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: AppColors.green,
                    )
                  : null))
          : null,
      onTap: widget.onPressed,
    );
  }
}
