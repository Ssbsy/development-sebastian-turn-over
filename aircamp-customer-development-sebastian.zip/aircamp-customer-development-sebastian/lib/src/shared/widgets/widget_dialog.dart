import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'widget_button.dart';
import 'widget_text.dart';
import '../../core/constants/colors.dart';

class WidgetDialog extends StatefulWidget {
  final String? titleText;
  final String? messageText;
  final String? cancelText;
  final String? continueText;
  final VoidCallback? continueOnpressed;

  const WidgetDialog(
      {super.key,
      this.titleText,
      this.messageText,
      this.cancelText,
      this.continueText,
      this.continueOnpressed});

  @override
  State<WidgetDialog> createState() => _WidgetDialogState();
}

class _WidgetDialogState extends State<WidgetDialog> {
  Widget _widgetText(
      String? text, Color? color, double? fontSize, FontWeight? fontWeight) {
    return WidgetText(
      text: text,
      color: color,
      fontSize: fontSize,
      fontWeight: fontWeight,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            _widgetText(widget.titleText, AppColors.black, 14, FontWeight.bold),
            const Gap(12),
            _widgetText(
                widget.messageText, AppColors.black, 12, FontWeight.normal),
            const Gap(12),
            Row(
              children: [
                Expanded(
                  child: WidgetButton(
                    text: widget.cancelText ?? '',
                    textColor: AppColors.black,
                    backgroundColor: AppColors.white,
                    borderColor: AppColors.green,
                    onPressed: () {
                      Get.back();
                    },
                  ),
                ),
                const Gap(8),
                Expanded(
                  child: WidgetButton(
                    borderRadius: 8,
                    text: widget.continueText ?? '',
                    textColor: AppColors.white,
                    backgroundColor: AppColors.green,
                    onPressed: widget.continueOnpressed!,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
