import 'package:flutter/material.dart';

class AppLifeCycleListener extends StatefulWidget {
  final Widget child;
  const AppLifeCycleListener({super.key, required this.child});

  @override
  State<AppLifeCycleListener> createState() => _AppLifeCycleListenerState();
}

class _AppLifeCycleListenerState extends State<AppLifeCycleListener>
    with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    if (state == AppLifecycleState.resumed) {
      print('App has resumed');
    } else if (state == AppLifecycleState.paused) {
      print('App is paused');
    } else if (state == AppLifecycleState.inactive) {
    } else if (state == AppLifecycleState.detached) {}
  }

  @override
  Widget build(BuildContext context) {
    return widget.child;
  }
}
