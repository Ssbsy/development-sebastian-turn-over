import 'dart:convert';
import 'package:airbnb_stayfinder_mobile/src/services/base_api_services.dart';
import 'package:http/http.dart' as http;

class LoginServices {
  final BaseApiServices apiServices;

  LoginServices(this.apiServices);

  //Login Method with Endpoint
  Future<Map<String, dynamic>> postLogin({
    required var emailOrPhone,
    required String password,
  }) async {
    const endpoint = 'api/v1/users/accounts/login';
    final body = {
      'emailOrPhone': emailOrPhone,
      'password': password,
    };

    try {
      final headers = await apiServices.getHeaders();

      print("Headers: $headers");
      print("Request Body: ${jsonEncode(body)}");

      final response = await http.post(
        Uri.parse('${apiServices.baseUrl}$endpoint'),
        headers: headers,
        body: jsonEncode(body),
      );

      print("Raw API response: ${response.body}");

      if (response.statusCode < 600) {
        final Map<String, dynamic> responseData = jsonDecode(response.body);
        return responseData;
      } else {
        print("Server error: ${response.statusCode} - ${response.body}");
        return {
          "success": false,
          "message": "Server error: ${response.statusCode}"
        };
      }
    } catch (e) {
      print(e);
      return {"success": false, "message": "An error occurred: $e"};
    }
  }
}
