import 'dart:convert';
import 'package:airbnb_stayfinder_mobile/src/services/base_api_services.dart';
import 'package:http/http.dart' as http;

class CancelBookingServices {
  final BaseApiServices apiServices;

  CancelBookingServices(this.apiServices);

  //Cancel Booking Method with Endpoint
  Future<Map<dynamic, dynamic>> patchCancelBooking() async {
    const endpoint = 'api/v1/customers/bookings/:bookingNumber';

    try {
      final headers = await apiServices.getHeaders();

      print("Headers: $headers");

      final response = await http.patch(
        Uri.parse('${apiServices.baseUrl}$endpoint'),
        headers: headers,
      );

      print("Raw API response: ${response.body}");

      if (response.statusCode < 600) {
        final Map<String, dynamic> responseData = jsonDecode(response.body);
        return responseData;
      } else {
        print("Server error: ${response.statusCode} - ${response.body}");
        return {
          "success": false,
          "message": "Server error: ${response.statusCode}"
        };
      }
    } catch (e) {
      print(e);
      return {"success": false, "message": "An error occurred: $e"};
    }
  }
}
