import 'dart:convert';

import 'package:airbnb_stayfinder_mobile/src/services/base_api_services.dart';
import 'package:http/http.dart' as http;

class RegisterServices {
  final BaseApiServices apiServices;

  RegisterServices(this.apiServices);

  //Register Method with Endpoint
  Future<Map<String, dynamic>> postRegister({
    required String firstName,
    required String lastName,
    required String phoneNo,
    required String email,
    required String password,
    required var birthdate,
  }) async {
    const endpoint = 'api/v1/users/accounts/register';
    final body = {
      'emailAddress': email,
      'password': password,
      'firstname': firstName,
      'lastname': lastName,
      'phoneNo': phoneNo,
      'birthdate': birthdate,
    };

    try {
      final headers = await apiServices.getHeaders();
      final response = await http.post(
        Uri.parse('${apiServices.baseUrl}$endpoint'),
        headers: headers,
        body: jsonEncode(body),
      );

      print("Raw API response: ${response.body}");

      if (response.statusCode < 600) {
        final Map<String, dynamic> responseData = jsonDecode(response.body);
        return responseData;
      } else {
        print("Server error: ${response.statusCode} - ${response.body}");
        return {
          "success": false,
          "message": "Server error: ${response.statusCode}"
        };
      }
    } catch (e) {
      print(e);
      return {"success": false, "message": "An error occurred: $e"};
    }
  }
}
