import 'dart:convert';
import 'package:airbnb_stayfinder_mobile/src/services/base_api_services.dart';
import 'package:http/http.dart' as http;

class BookingServices {
  final BaseApiServices apiServices;

  BookingServices(this.apiServices);

  //Booking Method with Endpoint
  Future<Map<dynamic, dynamic>> postBook({
    required var listingId,
    required var checkIn,
    required var checkOut,
    required int pax,
    required String paymentOption,
    required int phoneNo,
    required String paymentMethod,
    required double amountPaid,
    required Map<dynamic, dynamic> addOns,
  }) async {
    const endpoint = 'api/v1/customers/bookings';
    final body = {
      'listingId': listingId,
      'checkIn': checkIn,
      'checkOut': checkOut,
      'pax': pax,
      'paymentOption': paymentOption,
      'phoneNo': phoneNo,
      'paymentMethod': paymentMethod,
      'amountPaid': amountPaid,
      'addOns': addOns,
    };

    try {
      final headers = await apiServices.getHeaders();

      print("Headers: $headers");
      print("Request Body: ${jsonEncode(body)}");

      final response = await http.post(
        Uri.parse('${apiServices.baseUrl}$endpoint'),
        headers: headers,
        body: jsonEncode(body),
      );

      print("Raw API response: ${response.body}");

      if (response.statusCode < 600) {
        final Map<String, dynamic> responseData = jsonDecode(response.body);
        return responseData;
      } else {
        print("Server error: ${response.statusCode} - ${response.body}");
        return {
          "success": false,
          "message": "Server error: ${response.statusCode}"
        };
      }
    } catch (e) {
      print(e);
      return {"success": false, "message": "An error occurred: $e"};
    }
  }
}
