import 'dart:convert';
import 'package:airbnb_stayfinder_mobile/src/services/base_api_services.dart';
import 'package:http/http.dart' as http;

class GetListingByIdServices {
  final BaseApiServices apiServices;

  GetListingByIdServices(this.apiServices);

  //Get listing by id Method with Endpoint
  Future<Map<dynamic, dynamic>> getListingId(String listingId) async {
    final endpoint = 'api/v1/customers/listings/$listingId';

    try {
      final headers = await apiServices.getHeaders();

      print("Headers: $headers");

      final response = await http.get(
        Uri.parse('${apiServices.baseUrl}$endpoint'),
        headers: headers,
      );

      print("Raw API response: ${response.body}");

      if (response.statusCode < 600) {
        final Map<String, dynamic> responseData = jsonDecode(response.body);
        return responseData;
      } else {
        print("Server error: ${response.statusCode} - ${response.body}");
        return {
          "success": false,
          "message": "Server error: ${response.statusCode}"
        };
      }
    } catch (e) {
      print(e);
      return {"success": false, "message": "An error occurred: $e"};
    }
  }
}
