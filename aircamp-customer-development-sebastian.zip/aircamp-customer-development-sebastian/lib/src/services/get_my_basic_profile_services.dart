import 'dart:convert';
import 'package:airbnb_stayfinder_mobile/src/services/base_api_services.dart';
import 'package:http/http.dart' as http;

class GetMyBasicProfileServices {
  final BaseApiServices apiServices;

  GetMyBasicProfileServices(this.apiServices);

  //Get My Basic Profile Method with Endpoint
  Future<Map<String, dynamic>> getBasicProfile() async {
    const endpoint = 'api/v1/users/accounts/me';

    try {
      final headers = await apiServices.getHeaders();

      print("Headers: $headers");

      final response = await http.get(
        Uri.parse('${apiServices.baseUrl}$endpoint'),
        headers: headers,
      );

      print("Raw API response: ${response.body}");

      if (response.statusCode < 600) {
        final Map<String, dynamic> responseData = jsonDecode(response.body);
        return responseData;
      } else {
        print("Server error: ${response.statusCode} - ${response.body}");
        return {
          "success": false,
          "message": "Server error: ${response.statusCode}"
        };
      }
    } catch (e) {
      print(e);
      return {"success": false, "message": "An error occurred: $e"};
    }
  }
}
