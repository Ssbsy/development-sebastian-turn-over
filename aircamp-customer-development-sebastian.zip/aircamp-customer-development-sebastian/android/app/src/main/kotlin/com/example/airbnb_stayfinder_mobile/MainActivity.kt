package com.example.airbnb_stayfinder_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
