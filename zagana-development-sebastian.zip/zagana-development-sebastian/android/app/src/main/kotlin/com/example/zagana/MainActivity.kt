package com.example.zagana

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
