# zagana

*Zagana is a comprehensive shopping and grocery application designed to simplify your daily needs*