import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:zagana/src/core/themes/app_theme.dart';
import 'package:zagana/src/features/onboarding/onboarding_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Zagana',
      theme: AppTheme.lightTheme(),
      themeMode: ThemeMode.light,
      debugShowCheckedModeBanner: false,
      defaultTransition: Transition.rightToLeft,
      home: OnboardingPage(),
    );
  }
}
