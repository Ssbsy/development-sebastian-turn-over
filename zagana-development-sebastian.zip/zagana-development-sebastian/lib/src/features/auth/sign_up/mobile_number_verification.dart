import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:pinput/pinput.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_button.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';
import 'package:zagana/src/features/auth/sign_up/account_verified.dart';

class MobileNumberVerification extends StatefulWidget {
  const MobileNumberVerification({super.key});

  @override
  State<MobileNumberVerification> createState() =>
      _MobileNumberVerificationState();
}

class _MobileNumberVerificationState extends State<MobileNumberVerification> {
  final FocusNode _focusNode = FocusNode();
  final pinPut = TextEditingController();
  @override
  void dispose() {
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: WidgetText(
          text: 'Verify your Mobile Number',
          size: 16,
          weight: FontWeight.w600,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Center(
              child: Pinput(
                controller: pinPut,
                focusNode: _focusNode,
                length: 4,
              ),
            ),
            Gap(12),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                WidgetText(
                  text: 'Enter the verification PIN sent to',
                  size: 12,
                ),
                WidgetText(
                  text: '(+63) ',
                  size: 12,
                  weight: FontWeight.w600,
                ),
              ],
            ),
            Spacer(),
            WidgetText(
              text: 'Resend code?',
              color: Palette.primary,
              size: 14,
            ),
            Gap(12),
            WidgetButton(
              text: 'Verify ',
              onPressed: () {
                Get.to(() => AccountVerified());
              },
            ),
          ],
        ),
      ),
    );
  }
}
