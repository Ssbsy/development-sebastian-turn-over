import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_button.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';
import 'package:zagana/src/core/widgets/widget_text_field.dart';
import 'package:zagana/src/features/auth/sign_up/mobile_number_verification.dart';

class MobileNumberRegistry extends StatefulWidget {
  const MobileNumberRegistry({super.key});

  @override
  State<MobileNumberRegistry> createState() => _MobileNumberRegistryState();
}

class _MobileNumberRegistryState extends State<MobileNumberRegistry> {
  final GlobalKey _formKey = GlobalKey();
  final phoneNumber = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: WidgetText(
          text: 'Enter your Mobile Number',
          size: 16,
          weight: FontWeight.w600,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _titleText('Mobile Number'),
              Gap(8),
              // Phone Number TextField
              WidgetTextField(
                controller: phoneNumber,
                labelText: '+63 | ',
                prefixText: '+63 | ',
                maxLength: 10,
                keyboardType: TextInputType.numberWithOptions(
                  decimal: false,
                ),
                enableSuggestions: true,
              ),
              Spacer(),
              Center(
                child: WidgetText(
                  text:
                      "We're sending you a verification PIN to your\nmobile number. We use your number to allow\nbikers and customer service to contact your bookings.",
                  align: TextAlign.center,
                  color: Palette.gray,
                  size: 12,
                ),
              ),
              Gap(24),
              WidgetButton(
                text: 'Next',
                onPressed: () {
                  Get.to(() => MobileNumberVerification());
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  WidgetText _titleText(String? text) {
    return WidgetText(
      text: text,
      color: Palette.gray,
      size: 14,
    );
  }
}
