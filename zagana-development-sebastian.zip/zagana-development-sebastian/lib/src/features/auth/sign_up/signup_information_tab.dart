import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_button.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';
import 'package:zagana/src/core/widgets/widget_text_field.dart';
import 'package:zagana/src/features/auth/sign_up/mobile_number_registry.dart';

class SignupInformationTab extends StatefulWidget {
  const SignupInformationTab({super.key});

  @override
  State<SignupInformationTab> createState() => _SignupInformationTabState();
}

class _SignupInformationTabState extends State<SignupInformationTab> {
  final GlobalKey _formKey = GlobalKey();
  final firstName = TextEditingController(),
      lastName = TextEditingController(),
      emailAddress = TextEditingController(),
      birthday = TextEditingController(),
      password = TextEditingController(),
      confirmPassword = TextEditingController();

  Future<void> _selectBirthday(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      helpText: '',
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      final formattedDate = '${picked.month}/${picked.day}/${picked.year}';
      birthday.text = formattedDate;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: WidgetText(
          text: 'Sign-up Information',
          size: 16,
          weight: FontWeight.w600,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _titleText('First Name'),
                      // First Name TextField
                      WidgetTextField(
                        controller: firstName,
                        hintText: 'e.g: Juan',
                      ),
                      Gap(12),
                      _titleText('Last Name'),
                      // Last Name TextField
                      WidgetTextField(
                        controller: lastName,
                        hintText: 'e.g: Dela Cruz',
                      ),
                      Gap(12),
                      _titleText('Email'),
                      // Email Address TextField
                      WidgetTextField(
                        controller: emailAddress,
                        hintText: 'e.g: juandelacruz@gmail.com',
                      ),
                      Gap(12),
                      _titleText('Birthday'),
                      // Birthday TextField with the calendar picker
                      GestureDetector(
                        onTap: () => _selectBirthday(context),
                        child: WidgetTextField(
                          controller: birthday,
                          hintText: 'MM/DD/YYYY',
                          enabled:
                              false, // Make the TextField non-editable, only tap to pick a date
                        ),
                      ),
                      Gap(12),
                      _titleText('Password'),
                      // Password TextField
                      WidgetTextField(
                        controller: password,
                        obscureText: true,
                        keyboardType: TextInputType.visiblePassword,
                      ),
                      Gap(12),
                      _titleText('Confirm Password'),
                      // Password TextField
                      WidgetTextField(
                        controller: confirmPassword,
                        obscureText: true,
                        keyboardType: TextInputType.visiblePassword,
                      ),
                      Gap(24),
                      Row(
                        children: [
                          Checkbox.adaptive(
                            value: false,
                            onChanged: (value) {},
                          ),
                          Expanded(
                            child: RichText(
                              textAlign: TextAlign.center,
                              text: TextSpan(
                                children: [
                                  TextSpan(
                                    text:
                                        'By continuing, you agree to Zagana’s ',
                                    style: TextStyle(
                                      color: Palette.gray,
                                      fontSize: 14,
                                      fontWeight: FontWeight.normal,
                                    ),
                                  ),
                                  TextSpan(
                                    text: 'Terms of Service, Privacy Policy.',
                                    style: TextStyle(
                                      color: Palette.black,
                                      fontSize: 14,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              WidgetButton(
                text: 'Next',
                onPressed: () {
                  Get.to(() => MobileNumberRegistry());
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  WidgetText _titleText(String? text) {
    return WidgetText(
      text: text,
      color: Palette.gray,
      size: 14,
    );
  }
}
