import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:zagana/src/core/widgets/widget_button.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';
import 'package:zagana/src/features/auth/login/login_page.dart';

class AccountVerified extends StatefulWidget {
  const AccountVerified({super.key});

  @override
  State<AccountVerified> createState() => _AccountVerifiedState();
}

class _AccountVerifiedState extends State<AccountVerified> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: SizedBox.shrink(),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Center(
              child: Image.asset(
                'assets/icons/verified_thumb_icon.png',
                scale: 2,
              ),
            ),
            Gap(48),
            WidgetText(
              text: 'All Set!',
              size: 28,
              weight: FontWeight.w600,
            ),
            Gap(24),
            WidgetText(
              text:
                  'You may now login your credentials, and\nenjoy ordering fresh products right at your\ndoorstep!',
              size: 14,
              align: TextAlign.center,
            ),
            Spacer(),
            WidgetButton(
              text: 'Continue ',
              onPressed: () {
                Get.offAll(() => LoginPage());
              },
            ),
          ],
        ),
      ),
    );
  }
}
