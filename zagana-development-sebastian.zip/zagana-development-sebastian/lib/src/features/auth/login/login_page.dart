import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_container_box_shadow.dart';
import 'package:zagana/src/core/widgets/widget_exit_dialog.dart';
import 'package:zagana/src/features/auth/login/login_form_tab.dart';
import 'package:zagana/src/features/auth/sign_up/signup_information_tab.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: WillPopScope(
        onWillPop: () async {
          showAdaptiveDialog(
            context: context,
            builder: (context) {
              return WidgetExitDialog(
                title: 'Exit Application',
                content: 'Are you sure you want to exit?',
                continuePressed: () {
                  SystemNavigator.pop();
                },
              );
            },
          );
          return false;
        },
        child: Scaffold(
          backgroundColor: Palette.white,
          body: Column(
            children: [
              WidgetContainerBoxShadow(
                offSet: Offset(0, 4),
                blurRadius: 30,
                alpha: 0.1,
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(16),
                  bottomRight: Radius.circular(16),
                ),
                children: Column(
                  children: [
                    Image.asset(
                      'assets/images/zagana_logo_image.png',
                      height: 180,
                      width: 180,
                    ),
                    TabBar(
                      isScrollable: false,
                      tabs: [
                        Tab(text: 'Login'),
                        GestureDetector(
                          onTap: () {
                            Get.to(() => SignupInformationTab());
                          },
                          child: Tab(text: 'Sign-up'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Gap(12),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: TabBarView(
                    physics: NeverScrollableScrollPhysics(),
                    children: [
                      LoginFormTab(),
                      Container(),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
