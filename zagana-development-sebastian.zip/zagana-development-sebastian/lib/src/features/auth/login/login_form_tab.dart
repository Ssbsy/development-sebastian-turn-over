import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_button.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';
import 'package:zagana/src/core/widgets/widget_text_field.dart';
import 'package:zagana/src/features/home/dashboard/pages/dashboard_page.dart';

class LoginFormTab extends StatefulWidget {
  const LoginFormTab({super.key});

  @override
  State<LoginFormTab> createState() => _LoginFormTabState();
}

class _LoginFormTabState extends State<LoginFormTab> {
  final GlobalKey _formKey = GlobalKey();
  final phoneNumber = TextEditingController(),
      password = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _titleText('Phone Number'),
            Gap(8),
            // Phone Number TextField
            WidgetTextField(
              controller: phoneNumber,
              labelText: '+63 | ',
              prefixText: '+63 | ',
              maxLength: 10,
              keyboardType: TextInputType.numberWithOptions(
                decimal: false,
              ),
              enableSuggestions: true,
              
            ),
            Gap(12),
            _titleText('Password'),
            Gap(8),
            // Password TextField
            WidgetTextField(
              controller: password,
              obscureText: true,
              keyboardType: TextInputType.visiblePassword,
            ),
            Gap(24),
            GestureDetector(
              onTap: () {},
              child: WidgetText(
                text: 'Forgot password?',
                color: Palette.secondary,
                size: 14,
                weight: FontWeight.bold,
              ),
            ),
            Gap(24),
            WidgetButton(
              text: 'Login',
              onPressed: () {
                Get.off(() => DashboardPage());
              },
            ),
            Gap(12),
            WidgetButton(
              text: 'Use Fingerprint',
              onPressed: () {},
              imageAssetTwo: 'assets/icons/fingerprint_icon.png',
              backgroundColor: Palette.white,
              textColor: Palette.primary,
              borderColor: Palette.primary,
            ),
          ],
        ),
      ),
    );
  }

  WidgetText _titleText(String? text) {
    return WidgetText(
      text: text,
      color: Palette.gray,
      size: 14,
      weight: FontWeight.normal,
    );
  }
}
