import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:ionicons/ionicons.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_button.dart';
import 'package:zagana/src/core/widgets/widget_container_circle.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';
import 'package:zagana/src/core/widgets/widget_text_button.dart';
import 'package:zagana/src/features/home/checkout/components/delivery_details.dart';
import 'package:zagana/src/features/home/checkout/components/recommended_items.dart';

class CheckoutPage extends StatefulWidget {
  const CheckoutPage({super.key});

  @override
  State<CheckoutPage> createState() => _CheckoutPageState();
}

class _CheckoutPageState extends State<CheckoutPage>
    with SingleTickerProviderStateMixin {
  late final slideController = SlidableController(this);

  // List of items in the cart (example data)
  List<Map<String, dynamic>> items = [
    {
      'name': 'Zagana Dalandan',
      'weight': '500g',
      'price': 75.0,
      'originalPrice': 90.0,
      'quantity': 30,
    },
    {
      'name': 'Zagana Strawberry',
      'weight': '120g',
      'price': 45.0,
      'originalPrice': 120.0,
      'quantity': 25,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Palette.secondary,
        centerTitle: false,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            WidgetText(
              text: 'Zagana - Novaliches, Quezon City',
              size: 14,
              weight: FontWeight.w600,
            ),
            WidgetText(
              text: 'Distance from you: 1.5 km',
              size: 12,
            ),
          ],
        ),
      ),
      body: Stack(
        children: [
          SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                // Delivery Details
                DeliveryDetails(),
                // Dismissible Container
                itemList(context),
                // Recommended for you
                RecommendedItems(),
                // Sub total
                subTotalDetails(context),
                paymentMethodDetails(context),
              ],
            ),
          ),
        ],
      ),
    );
  }

  paymentMethodDetails(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              WidgetText(
                text: 'Payment Method',
                size: 14,
                weight: FontWeight.w600,
              ),
              WidgetTextButton(
                text: 'View all methods',
                onPressed: () {},
              ),
            ],
          ),
        ),
        Container(
          width: MediaQuery.sizeOf(context).width,
          decoration: BoxDecoration(
            color: Palette.white,
          ),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // This Payment Method must be dynamic it can change to Gcash, Paypal, Maya
                    Row(
                      children: [
                        Image.asset(
                          'assets/icons/peso_cash_icon.png',
                          height: 16,
                        ),
                        Gap(8),
                        WidgetText(
                          text: 'Cash on Delivery',
                          size: 14,
                        ),
                      ],
                    ),
                    WidgetTextButton(
                      text: 'Voucher',
                      onPressed: () {},
                    ),
                  ],
                ),
                Divider(),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        WidgetText(
                          text: '₱199.00',
                          size: 14,
                          weight: FontWeight.w600,
                        ),
                        WidgetText(
                          text: 'See breakdown',
                          color: Palette.primary,
                          size: 12,
                        ),
                      ],
                    ),
                    WidgetButton(
                      text: 'Place Order',
                      onPressed: () {},
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  subTotalDetails(BuildContext context) {
    return Container(
      width: MediaQuery.sizeOf(context).width,
      decoration: BoxDecoration(
        color: Palette.white,
      ),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                WidgetText(
                  text: 'Subtotal',
                  size: 14,
                  weight: FontWeight.w600,
                ),
                WidgetText(
                  text: '₱150.00',
                  size: 14,
                  weight: FontWeight.w600,
                ),
              ],
            ),
            Gap(8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                WidgetText(
                  text: 'Delivery fee',
                  size: 14,
                  weight: FontWeight.w600,
                ),
                WidgetText(
                  text: '₱150.00',
                  size: 14,
                  weight: FontWeight.w600,
                ),
              ],
            ),
            Gap(8),
            WidgetText(
              text: 'Add ₱849.10 more, to get ₱50.00 off delivery fee ',
              color: Palette.primary,
              size: 10,
            ),
          ],
        ),
      ),
    );
  }

  itemList(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              WidgetText(
                text: 'Order Summary',
                size: 14,
                weight: FontWeight.w600,
              ),
              WidgetTextButton(
                text: 'Add more items',
                onPressed: () {},
              ),
            ],
          ),
        ),
        ListView.builder(
          shrinkWrap: true,
          itemCount: items.length,
          physics: NeverScrollableScrollPhysics(),
          itemBuilder: (context, index) {
            return Padding(
              padding: EdgeInsets.only(bottom: 4),
              child: Slidable(
                key: ValueKey(index),
                endActionPane: ActionPane(
                  motion: ScrollMotion(),
                  dismissible: DismissiblePane(
                    onDismissed: () {},
                  ),
                  children: [
                    SlidableAction(
                      onPressed: (value) {},
                      backgroundColor: Palette.primary,
                      icon: Ionicons.heart,
                    ),
                    SlidableAction(
                      onPressed: (value) {
                        setState(() {
                          items.removeAt(index);
                          print(items.length);
                        });
                      },
                      backgroundColor: Palette.red,
                      icon: Ionicons.trash,
                    ),
                  ],
                ),
                child: _buildContainerItems(context, index),
              ),
            );
          },
        ),
      ],
    );
  }

  Container _buildContainerItems(BuildContext context, int index) {
    final item = items[index];
    return Container(
      width: MediaQuery.sizeOf(context).width,
      decoration: BoxDecoration(color: Palette.white),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            WidgetContainerCircle(countText: item['quantity'].toString()),
            const Gap(8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  WidgetText(text: item['name'], size: 16),
                  WidgetText(text: item['weight'], size: 14),
                  const Gap(8),
                  GestureDetector(
                    onTap: () {},
                    child: WidgetText(
                      text: 'Change',
                      color: Palette.primary,
                    ),
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                WidgetText(
                  text: '₱${item['price']}',
                  color: Palette.primary,
                  size: 12,
                ),
                WidgetText(
                  text: '₱${item['originalPrice']}',
                  color: Palette.gray,
                  size: 10,
                  textDecoration: TextDecoration.lineThrough,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
