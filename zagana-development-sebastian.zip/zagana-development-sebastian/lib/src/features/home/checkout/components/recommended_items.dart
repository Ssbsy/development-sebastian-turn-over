import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_container_box_shadow.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';

class RecommendedItems extends StatefulWidget {
  const RecommendedItems({super.key});

  @override
  State<RecommendedItems> createState() => _RecommendedItemsState();
}

class _RecommendedItemsState extends State<RecommendedItems> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          WidgetText(
            text: 'Recommended for you',
            size: 14,
            weight: FontWeight.w600,
          ),
          Gap(12),
          recommendedList()
        ],
      ),
    );
  }

  SizedBox recommendedList() {
    return SizedBox(
      height: 100,
      child: ListView.builder(
        shrinkWrap: true,
        scrollDirection: Axis.horizontal,
        itemCount: 10,
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.only(left: 8),
            child: WidgetContainerBoxShadow(
              offSet: Offset(0, 10),
              blurRadius: 20,
              alpha: 0.02,
              borderRadius: BorderRadius.circular(20),
              children: Padding(
                padding: const EdgeInsets.all(20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    WidgetContainerBoxShadow(
                      blurRadius: 10,
                      offSet: Offset(0, 5),
                      alpha: 0.05,
                      boxShape: BoxShape.circle,
                      children: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: ClipOval(
                          child: Image.asset(
                            'assets/images/langka_image.png',
                            height: 60,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                    Gap(8),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        WidgetText(
                          text: 'P. Fiesta Lumpiang Shanghai (Pork)',
                          size: 12,
                          weight: FontWeight.w600,
                        ),
                        WidgetText(
                          text: '199 pcs',
                          color: Palette.gray,
                          size: 10,
                        ),
                        Gap(12),
                        WidgetText(
                          text: '₱ 32.00',
                          size: 12,
                          weight: FontWeight.w600,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
