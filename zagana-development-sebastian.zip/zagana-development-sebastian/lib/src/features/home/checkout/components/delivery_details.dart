import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';
import 'package:zagana/src/core/widgets/widget_text_button.dart';

class DeliveryDetails extends StatefulWidget {
  const DeliveryDetails({super.key});

  @override
  State<DeliveryDetails> createState() => _DeliveryDetailsState();
}

class _DeliveryDetailsState extends State<DeliveryDetails> {
  final List<String> courierList = [
    'assets/images/couriers/zagana_express.png',
    'assets/images/couriers/lalamove.png',
    'assets/images/couriers/transportify.png',
    'assets/images/couriers/transportify.png',
    'assets/images/couriers/transportify.png',
    'assets/images/couriers/transportify.png',
  ];
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: WidgetText(
            text: 'Deliver to',
            size: 14,
            weight: FontWeight.w600,
          ),
        ),
        Container(
          width: MediaQuery.sizeOf(context).width,
          decoration: BoxDecoration(color: Palette.white),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              customerDetails(),
              const Divider(),
              deliveryTime(),
              const Divider(),
              deliveryCourier(),
            ],
          ),
        ),
      ],
    );
  }

  customerDetails() {
    return GestureDetector(
      onTap: () {},
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Icon(
                  Icons.location_on,
                  color: Palette.red,
                ),
                const Gap(8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      WidgetText(
                        text: 'Juan Dela Cruz',
                        size: 14,
                        weight: FontWeight.w600,
                      ),
                      WidgetText(
                        text: 'Novaliches, Quezon City',
                        color: Palette.gray,
                        size: 12,
                      ),
                    ],
                  ),
                ),
                const Icon(
                  Icons.arrow_forward_ios,
                ),
              ],
            ),
          ),
          const Gap(12),
          Padding(
            padding: const EdgeInsets.only(left: 30, bottom: 8),
            child: Container(
              decoration: BoxDecoration(
                color: Palette.gray.withValues(alpha: 0.1),
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(8),
                  bottomLeft: Radius.circular(8),
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: [
                    WidgetText(
                      text: 'Brown gate, in front of orange house',
                      color: Palette.gray,
                      size: 10,
                    ),
                    Spacer(),
                    WidgetTextButton(
                      text: 'Change',
                      onPressed: () {},
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  deliveryTime() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                WidgetText(
                  text: 'Deliver now!',
                  color: Palette.gray,
                  size: 12,
                  weight: FontWeight.w600,
                ),
                const Gap(8),
                WidgetText(
                  text: 'Today, 10:00 - 11:00 AM',
                  size: 14,
                  weight: FontWeight.w600,
                ),
              ],
            ),
          ),
          WidgetTextButton(
            text: 'Change delivery time',
            onPressed: () {},
          ),
        ],
      ),
    );
  }

  deliveryCourier() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          WidgetText(
            text: 'Delivery Courier',
            color: Palette.gray,
            size: 12,
            weight: FontWeight.w600,
          ),
          const Gap(8),
          // Select Courier
          SizedBox(
            height: 50,
            child: ListView.builder(
              shrinkWrap: true,
              scrollDirection: Axis.horizontal,
              itemCount: courierList.length,
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Image.asset(
                    courierList[index],
                    width: 85,
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
