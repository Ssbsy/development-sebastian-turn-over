import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';
import 'package:zagana/src/features/home/branches/components/branch_container.dart';
import 'package:zagana/src/features/home/branches/components/sorting_branches.dart';
import 'package:zagana/src/features/home/branches/components/user_location_container.dart';

class BranchesPage extends StatefulWidget {
  const BranchesPage({super.key});

  @override
  State<BranchesPage> createState() => _BranchesPageState();
}

class _BranchesPageState extends State<BranchesPage> {
  List<Map<String, String>> branchesList = [
    {
      'branchName': 'Zagana - Novaliches',
      'location': 'Novaliches, Quezon City',
      'distance': '5 km',
    },
    {
      'branchName': 'Zagana - Makati',
      'location': 'Makati, Metro Manila',
      'distance': '10 km',
    },
    {
      'branchName': 'Zagana - Quezon Avenue',
      'location': 'Quezon City, Metro Manila',
      'distance': '3 km',
    },
    {
      'branchName': 'Zagana - Pasig',
      'location': 'Pasig City, Metro Manila',
      'distance': '8 km',
    },
    {
      'branchName': 'Zagana - Manila',
      'location': 'Manila, Metro Manila',
      'distance': '15 km',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Palette.secondary,
        title: WidgetText(
          text: 'Branches of Zagana',
          size: 14,
          weight: FontWeight.w600,
        ),
        actions: [
          IconButton(onPressed: () {}, icon: Icon(Icons.map_outlined)),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Gap(12),
            currentLocation(context),
            sorting(),
            branchesListView(),
          ],
        ),
      ),
    );
  }

  Widget branchesListView() {
    return ListView.separated(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemCount: branchesList.length,
      itemBuilder: (context, index) {
        return BranchContainer(
          onPressed: () {},
          branchName: branchesList[index]['branchName'].toString(),
          location: branchesList[index]['location'].toString(),
          distance: branchesList[index]['distance'].toString(),
        );
      },
      separatorBuilder: (context, index) {
        return Gap(8);
      },
    );
  }

  Widget sorting() {
    return SortingBranches(
      onPressed: () {},
    );
  }

  Widget currentLocation(BuildContext context) {
    return UserLocationContainer(
      onPressed: () {},
      location: 'Novaliches, Quezon City',
    );
  }
}
