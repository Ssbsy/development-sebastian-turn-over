import 'package:flutter/material.dart';

class SavedBranchesPage extends StatefulWidget {
  const SavedBranchesPage({super.key});

  @override
  State<SavedBranchesPage> createState() => _SavedBranchesPageState();
}

class _SavedBranchesPageState extends State<SavedBranchesPage> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}