import 'package:flutter/material.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';

class BranchContainer extends StatefulWidget {
  final VoidCallback onPressed;
  final String branchName;
  final String location;
  final String distance;
  const BranchContainer(
      {super.key,
      required this.onPressed,
      required this.branchName,
      required this.location,
      required this.distance});

  @override
  State<BranchContainer> createState() => _BranchContainerState();
}

class _BranchContainerState extends State<BranchContainer> {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(color: Palette.white),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Image.asset(
              'assets/icons/zagana_icon.png',
              height: 48,
            ),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  WidgetText(
                    text: widget.branchName,
                    size: 12,
                    weight: FontWeight.w600,
                  ),
                  WidgetText(
                    text: '${widget.location}\n${widget.distance}',
                    size: 10,
                  ),
                ],
              ),
            ),
            IconButton(
              onPressed: widget.onPressed,
              icon: Icon(
                Icons.bookmark_outline,
                size: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
