import 'package:flutter/material.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';

class SortingBranches extends StatefulWidget {
  final VoidCallback onPressed;
  const SortingBranches({super.key, required this.onPressed});

  @override
  State<SortingBranches> createState() => _SortingBranchesState();
}

class _SortingBranchesState extends State<SortingBranches> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          WidgetText(
            text: 'Sort by',
            size: 12,
          ),
          TextButton(
            onPressed: widget.onPressed,
            child: Row(
              children: [
                Icon(
                  Icons.bookmark,
                  color: Palette.primary,
                ),
                WidgetText(
                  text: 'Saved Branches',
                  color: Palette.primary,
                  size: 12,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
