import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';

class UserLocationContainer extends StatefulWidget {
  final VoidCallback onPressed;
  final String location;
  const UserLocationContainer({super.key, required this.onPressed, required this.location});

  @override
  State<UserLocationContainer> createState() => _UserLocationContainerState();
}

class _UserLocationContainerState extends State<UserLocationContainer> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onPressed,
      child: Container(
        width: MediaQuery.sizeOf(context).width,
        decoration: BoxDecoration(
          color: Palette.white,
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Icon(Icons.location_searching_outlined),
              Gap(8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  WidgetText(
                    text: 'Use my current location',
                    size: 14,
                  ),
                  WidgetText(
                    text: widget.location,
                    color: Palette.gray,
                    size: 12,
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
