import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';

class RecipeList extends StatefulWidget {
  const RecipeList({super.key});

  @override
  State<RecipeList> createState() => _RecipeListState();
}

class _RecipeListState extends State<RecipeList> {
  List<Map<String, String>> recipeList = [
    {
      'imageUrl': 'assets/images/asparagus_recipe_image.png',
      'title': 'Asparagus Steak Recipe',
      'description':
          'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.',
    },
    {
      'imageUrl': 'assets/images/yogurt_image.png',
      'title': 'Strawberry Yogurt Recipe',
      'description':
          'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.',
    },
  ];
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              WidgetText(
                text: 'Recipes',
                size: 18,
                weight: FontWeight.w600,
              ),
              GestureDetector(
                onTap: () {},
                child: WidgetText(
                  text: 'View more',
                  color: Palette.primary,
                  size: 12,
                  weight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
        Gap(12),
        SizedBox(
          height: 200,
          child: ListView.builder(
            shrinkWrap: true,
            scrollDirection: Axis.horizontal,
            itemCount: recipeList.length,
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.all(8.0),
                child: GestureDetector(
                  onTap: () {},
                  child: Column(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10),
                          topRight: Radius.circular(10),
                        ),
                        child: Image.asset(
                          recipeList[index]['imageUrl'].toString(),
                          height: 120,
                          width: 250,
                          fit: BoxFit.cover,
                        ),
                      ),
                      Container(
                        width: 250,
                        decoration: BoxDecoration(
                          color: Palette.white,
                          borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(10),
                            bottomRight: Radius.circular(10),
                          ),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              WidgetText(
                                text: recipeList[index]['title'],
                                size: 12,
                                weight: FontWeight.w600,
                              ),
                              WidgetText(
                                text: recipeList[index]['description'],
                                size: 10,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
