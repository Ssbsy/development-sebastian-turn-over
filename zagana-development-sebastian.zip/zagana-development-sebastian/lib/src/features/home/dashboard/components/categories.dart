import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:ionicons/ionicons.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/features/home/dashboard/pages/product_details_page.dart';
import 'package:zagana/src/features/home/dashboard/widgets/widget_container_counter.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';
import 'package:zagana/src/features/home/dashboard/widgets/widget_container_item.dart';

class Categories extends StatefulWidget {
  final Function(bool) toggleFab;
  const Categories({super.key, required this.toggleFab});

  @override
  State<Categories> createState() => _CategoriesState();
}

class _CategoriesState extends State<Categories> {
  void incrementPressed() {
    widget.toggleFab(true);
  }

  List<Map<String, String>> categoriesList = [
    {'imageUrl': 'assets/images/vegetables_image.jpg', 'title': 'Vegetables'},
    {'imageUrl': 'assets/images/fruits_image.jpg', 'title': 'Fruits'},
    {'imageUrl': 'assets/images/meat_image.jpg', 'title': 'Meat'},
    {'imageUrl': 'assets/images/poultry_image.jpg', 'title': 'Poultry'},
    {'imageUrl': 'assets/images/seafood_image.jpg', 'title': 'Seafood'},
    {'imageUrl': 'assets/images/vegetables_image.jpg', 'title': 'Vegetables'},
    {'imageUrl': 'assets/images/fruits_image.jpg', 'title': 'Fruits'},
    {'imageUrl': 'assets/images/meat_image.jpg', 'title': 'Meat'},
    {'imageUrl': 'assets/images/poultry_image.jpg', 'title': 'Poultry'},
    {'imageUrl': 'assets/images/seafood_image.jpg', 'title': 'Seafood'},
  ];
  bool showStack = false;
  bool isGridView = false;
  String? selectedValue;
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: WidgetText(
            text: 'Categories',
            size: 18,
            weight: FontWeight.w600,
          ),
        ),
        // Category List of Items
        categoryItemList(context),

        sortingViewActions(),
        // List of Grocery Items
        isGridView
            ? GridView.builder(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 4,
                  mainAxisSpacing: 4,
                  childAspectRatio: 0.7,
                ),
                itemCount: 10,
                itemBuilder: (context, index) {
                  return stackContainerDetails(context);
                },
              )
            : ListView.builder(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemCount: 10,
                itemBuilder: (context, index) {
                  return stackContainerDetails(context);
                },
              ),
      ],
    );
  }

  Container categoryItemList(BuildContext context) {
    return Container(
      height: 120,
      width: MediaQuery.sizeOf(context).width,
      decoration: BoxDecoration(color: Palette.primary),
      child: ListView.builder(
        shrinkWrap: true,
        scrollDirection: Axis.horizontal,
        itemCount: categoriesList.length,
        itemBuilder: (context, index) {
          return GestureDetector(
            onTap: () {},
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundImage: AssetImage(
                      categoriesList[index]['imageUrl'].toString(),
                    ),
                  ),
                  Gap(8),
                  WidgetText(
                    text: categoriesList[index]['title'],
                    color: Palette.white,
                    size: 14,
                    weight: FontWeight.w600,
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  sortingViewActions() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              WidgetText(
                text: 'Sort by:',
                size: 14,
              ),
              // Dropdown Button
              dropDownList(),
              WidgetText(
                text: 'View:',
                size: 14,
              ),
              IconButton(
                onPressed: () {
                  setState(() {
                    isGridView = false;
                  });
                },
                icon: Icon(Ionicons.list),
              ),
              IconButton(
                onPressed: () {
                  setState(() {
                    isGridView = true;
                  });
                },
                icon: Icon(Ionicons.grid),
              ),
            ],
          ),
        ],
      ),
    );
  }

  stackContainerDetails(BuildContext context) {
    return isGridView
        // GridView
        ? Stack(
            children: [
              GestureDetector(
                onTap: () {
                  Get.to(() => ProductDetailsPage());
                },
                child: Container(
                  height: double.infinity,
                  decoration: BoxDecoration(
                    color: Palette.white,
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        itemContainerImage(),
                        itemDetails(),
                        itemActions(),
                      ],
                    ),
                  ),
                ),
              ),
              if (showStack)
                WidgetContainerCounter(
                  decrementPressed: () {
                    setState(() {
                      widget.toggleFab(false);
                      showStack = !showStack;
                    });
                  },
                  incrementPressed: incrementPressed,
                  countValue: '20',
                ),
            ],
          )
        // ListView
        : Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                GestureDetector(
                  onTap: () {
                    Get.to(() => ProductDetailsPage());
                  },
                  child: Container(
                    height: 130,
                    width: MediaQuery.sizeOf(context).width,
                    decoration: BoxDecoration(
                      color: Palette.white,
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        children: [
                          itemContainerImage(),
                          Gap(12),
                          itemDetails(),
                          itemActions(),
                        ],
                      ),
                    ),
                  ),
                ),
                if (showStack)
                  WidgetContainerCounter(
                    decrementPressed: () {
                      setState(() {
                        widget.toggleFab(false);
                        showStack = !showStack;
                      });
                    },
                    incrementPressed: incrementPressed,
                    countValue: '20',
                  ),
              ],
            ),
          );
  }

  dropDownList() {
    return DropdownButton<String>(
      elevation: 0,
      borderRadius: BorderRadius.circular(8),
      icon: Icon(Icons.keyboard_arrow_down),
      hint: Text('Select sort'),
      items: [
        DropdownMenuItem<String>(
          value: 'Newest',
          child: Text('Newest'),
        ),
        DropdownMenuItem<String>(
          value: 'Oldest',
          child: Text('Oldest'),
        ),
        DropdownMenuItem<String>(
          value: 'Lowest Price',
          child: Text('Lowest Price'),
        ),
        DropdownMenuItem<String>(
          value: 'Highest Price',
          child: Text('Highest Price'),
        ),
      ],
      onChanged: (value) {
        setState(() {
          selectedValue = value;
        });
        print('Selected option: $value');
      },
    );
  }

  itemContainerImage() {
    return isGridView
        ? WidgetContainerItem(
            width: MediaQuery.sizeOf(context).width,
          )
        : WidgetContainerItem();
  }

  itemDetails() {
    return isGridView
        ? Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              WidgetText(
                text: 'Zagana Frozen Jackfruit',
                size: 12,
                weight: FontWeight.w600,
              ),
              WidgetText(
                text: '500g | Bulacan, Philippines',
                color: Palette.gray,
                size: 12,
              ),
              WidgetText(
                text: 'Buy 2, get 25% off',
                color: Palette.primary,
                size: 10,
              ),
              Gap(8),
              WidgetText(
                text: '₱300.00',
                size: 14,
                weight: FontWeight.w600,
              ),
            ],
          )
        : Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                WidgetText(
                  text: 'Zagana Frozen Jackfruit',
                  size: 12,
                  weight: FontWeight.w600,
                ),
                WidgetText(
                  text: '500g | Bulacan, Philippines',
                  color: Palette.gray,
                  size: 12,
                ),
                WidgetText(
                  text: 'Buy 2, get 25% off',
                  color: Palette.primary,
                  size: 10,
                ),
                Gap(8),
                WidgetText(
                  text: '₱300.00',
                  size: 14,
                  weight: FontWeight.w600,
                ),
              ],
            ),
          );
  }

  itemActions() {
    return isGridView
        ? Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                onPressed: () {},
                icon: Icon(Ionicons.heart_outline),
              ),
              IconButton(
                onPressed: () {
                  setState(() {
                    showStack = !showStack;
                  });
                },
                icon: Icon(
                  Ionicons.add_circle,
                  color: Palette.primary,
                ),
              ),
            ],
          )
        : Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                onPressed: () {},
                icon: Icon(Ionicons.heart_outline),
              ),
              IconButton(
                onPressed: () {
                  setState(() {
                    showStack = !showStack;
                  });
                },
                icon: Icon(
                  Ionicons.add_circle,
                  color: Palette.primary,
                ),
              ),
            ],
          );
  }
}
