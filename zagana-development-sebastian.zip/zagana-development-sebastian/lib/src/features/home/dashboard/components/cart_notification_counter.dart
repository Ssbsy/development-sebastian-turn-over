import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:ionicons/ionicons.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';
import 'package:zagana/src/features/home/checkout/checkout_page.dart';

class CartNotificationCounter extends StatefulWidget {
  const CartNotificationCounter({super.key});

  @override
  State<CartNotificationCounter> createState() =>
      _CartNotificationCounterState();
}

class _CartNotificationCounterState extends State<CartNotificationCounter> {
  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        IconButton(
          onPressed: () {
            Get.to(() => CheckoutPage());
          },
          icon: Icon(Ionicons.cart_outline),
        ),
        Positioned(
          right: 10,
          top: 10,
          child: CircleAvatar(
            radius: 8,
            backgroundColor: Palette.red,
            child: WidgetText(
              text: '3',
              color: Palette.white,
              size: 8,
              weight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }
}
