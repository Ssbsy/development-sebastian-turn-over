import 'dart:async';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'package:zagana/src/core/constants/colors.dart';

class AdvertisementIndicator extends StatefulWidget {
  const AdvertisementIndicator({super.key});

  @override
  State<AdvertisementIndicator> createState() => _AdvertisementIndicatorState();
}

class _AdvertisementIndicatorState extends State<AdvertisementIndicator> {
  final pageViewController = PageController();
  late Timer _timer;

  // List of advertisements as a map (example with images and titles)
  final List<Map<String, String>> advertisements = [
    {
      'image': 'assets/images/advertisement.png',
    },
    {
      'image': 'assets/images/advertisement.png',
    },
    {
      'image': 'assets/images/advertisement.png',
    },
    // You can add more ads as needed.
  ];

  @override
  void initState() {
    super.initState();
    _startAutoScroll();
  }

  void _startAutoScroll() {
    _timer = Timer.periodic(const Duration(seconds: 2), (timer) {
      if (pageViewController.page == advertisements.length - 1) {
        pageViewController.jumpToPage(0);
      } else {
        pageViewController.nextPage(
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeInOut,
        );
      }
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 200,
          child: PageView(
            controller: pageViewController,
            children: advertisements.map((ad) {
              return Image.asset(ad['image']!);
            }).toList(),
          ),
        ),
        Gap(8),
        SmoothPageIndicator(
          controller: pageViewController,
          count: advertisements.length,
          effect: WormEffect(
            dotHeight: 10,
            dotWidth: 10,
            activeDotColor: Palette.primary,
            dotColor: Palette.gray,
          ),
        ),
      ],
    );
  }
}
