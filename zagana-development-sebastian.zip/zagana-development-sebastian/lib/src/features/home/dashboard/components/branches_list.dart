import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';
import 'package:zagana/src/core/widgets/widget_text_button.dart';
import 'package:zagana/src/features/home/branches/pages/branches_page.dart';

class BranchesList extends StatefulWidget {
  const BranchesList({super.key});

  @override
  State<BranchesList> createState() => _BranchesListState();
}

class _BranchesListState extends State<BranchesList> {
  List<Map<String, String>> branchesList = [
    {'cities': 'Novaliches', 'distance': '10'},
    {'cities': 'Malabon', 'distance': '15'},
    {'cities': 'Cubao', 'distance': '5'},
    {'cities': 'Quezon City', 'distance': '8'},
    {'cities': 'Makati', 'distance': '12'},
    {'cities': 'Taguig', 'distance': '14'},
    {'cities': 'Pasig', 'distance': '6'},
    {'cities': 'Manila', 'distance': '7'},
    {'cities': 'Mandaluyong', 'distance': '11'},
    {'cities': 'Caloocan', 'distance': '13'},
    {'cities': 'San Juan', 'distance': '9'},
    {'cities': 'Pasay', 'distance': '16'},
  ];
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              WidgetText(
                text: 'Branches',
                size: 18,
                weight: FontWeight.w600,
              ),
              WidgetTextButton(
                text: 'View More',
                onPressed: () {
                  Get.to(() => BranchesPage());
                },
              ),
            ],
          ),
        ),
        Container(
          height: 120,
          width: MediaQuery.sizeOf(context).width,
          decoration: BoxDecoration(color: Palette.secondary),
          child: ListView.builder(
            shrinkWrap: true,
            scrollDirection: Axis.horizontal,
            itemCount: branchesList.length,
            itemBuilder: (context, index) {
              return GestureDetector(
                onTap: () {},
                child: Column(
                  children: [
                    Image.asset(
                      'assets/icons/zagana_icon.png',
                      width: 80,
                    ),
                    WidgetText(
                      text: branchesList[index]['cities'],
                      size: 10,
                      weight: FontWeight.w600,
                    ),
                    WidgetText(
                      text: '${branchesList[index]['distance']} KM Away',
                      size: 10,
                      weight: FontWeight.w600,
                    ),
                    Gap(8),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
