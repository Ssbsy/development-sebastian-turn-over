import 'package:flutter/material.dart';
import 'package:zagana/src/core/constants/colors.dart';

class StackCircleAvatar extends StatelessWidget {
  final double radius;
  final String? assetImage;
  final bool showContainer;
  final VoidCallback onPressed;
  final Widget? iconAsset; 

  const StackCircleAvatar({
    super.key,
    this.assetImage,
    this.showContainer = false,
    this.radius = 30.0,
    required this.onPressed,
    this.iconAsset,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        GestureDetector(
          onTap: onPressed,
          child: CircleAvatar(
            radius: radius,
            backgroundImage: assetImage != null ? AssetImage(assetImage!) : null,
          ),
        ),
        if (showContainer && iconAsset != null)
          Positioned(
            bottom: 0,
            right: 0,
            child: Container(
              height: 30,
              decoration: BoxDecoration(
                color: Palette.primary,
                shape: BoxShape.circle,
                border: Border.all(
                  color: Palette.secondary,
                ),
              ),
              child: iconAsset,
            ),
          ),
      ],
    );
  }
}
