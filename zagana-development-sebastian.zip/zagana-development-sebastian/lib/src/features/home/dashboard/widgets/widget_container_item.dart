import 'package:flutter/material.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';

class WidgetContainerItem extends StatefulWidget {
  final double? height;
  final double? width;

  const WidgetContainerItem({
    super.key,
    this.width,
    this.height,
  });

  @override
  State<WidgetContainerItem> createState() => _WidgetContainerItemState();
}

class _WidgetContainerItemState extends State<WidgetContainerItem> {
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          height: widget.height,
          width: widget.width,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            boxShadow: [
              BoxShadow(
                spreadRadius: 0.1,
                color: Palette.black.withValues(alpha: 0.05),
                offset: Offset(2, 4),
                blurRadius: 10,
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.asset(
              'assets/images/langka_image.png',
              height: 100,
              fit: BoxFit.cover,
            ),
          ),
        ),
        // Padding(
        //   padding: const EdgeInsets.all(8.0),
        //   child: Container(
        //     decoration: BoxDecoration(
        //       color: Palette.primary,
        //       borderRadius: BorderRadius.circular(25),
        //     ),
        //     child: Padding(
        //       padding: const EdgeInsets.all(8.0),
        //       child: WidgetText(
        //         text: 'Most Ordered',
        //         color: Palette.white,
        //         size: 10,
        //         weight: FontWeight.w600,
        //       ),
        //     ),
        //   ),
        // ),
      ],
    );
  }
}
