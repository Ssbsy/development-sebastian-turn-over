import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';
import 'package:zagana/src/features/home/checkout/checkout_page.dart';

class WidgetViewCartContainer extends StatefulWidget {
  final dynamic children;
  const WidgetViewCartContainer({super.key, this.children});

  @override
  State<WidgetViewCartContainer> createState() =>
      _WidgetViewCartContainerState();
}

class _WidgetViewCartContainerState extends State<WidgetViewCartContainer> {
  @override
  Widget build(BuildContext context) {
    return Positioned(
      bottom: 0,
      left: 0,
      right: 0,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: GestureDetector(
          onTap: () {
            Get.to(() => CheckoutPage());
          },
          child: Container(
            padding: EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Palette.secondary,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                WidgetText(
                  text: 'View Cart • ',
                  size: 14,
                  weight: FontWeight.w600,
                ),
                Expanded(
                  child: WidgetText(
                    text: '20 items',
                    size: 12,
                  ),
                ),
                WidgetText(
                  text: '₱150.00',
                  size: 14,
                  weight: FontWeight.w600,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
