import 'package:flutter/material.dart';
import 'package:ionicons/ionicons.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';

class WidgetContainerCounter extends StatefulWidget {
  final VoidCallback decrementPressed;
  final VoidCallback incrementPressed;
  final String countValue;
  const WidgetContainerCounter(
      {super.key,
      required this.decrementPressed,
      required this.incrementPressed,
      required this.countValue});

  @override
  State<WidgetContainerCounter> createState() => _WidgetContainerCounterState();
}

class _WidgetContainerCounterState extends State<WidgetContainerCounter> {
  final int = 0;
  @override
  Widget build(BuildContext context) {
    return Positioned(
      right: 0,
      bottom: 0,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          decoration: BoxDecoration(
            border: Border.all(color: Palette.primary),
            borderRadius: BorderRadius.circular(25),
            color: Palette.white,
            boxShadow: [
              BoxShadow(
                color: Palette.black.withValues(alpha: 0.1),
                blurRadius: 10,
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            mainAxisSize: MainAxisSize.min,
            children: [
              // Decrement Items Value
              IconButton(
                onPressed: widget.decrementPressed,
                icon: Icon(
                  Ionicons.remove_circle_outline,
                  color: Palette.primary,
                ),
              ),
              WidgetText(
                text: widget.countValue,
                size: 12,
                weight: FontWeight.w600,
              ),
              // Increment Items Value
              IconButton(
                onPressed: widget.incrementPressed,
                icon: Icon(
                  Ionicons.add_circle,
                  color: Palette.primary,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
