import 'dart:async';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:ionicons/ionicons.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_button.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';
import 'package:zagana/src/core/widgets/widget_text_field.dart';

class ProductDetailsPage extends StatefulWidget {
  const ProductDetailsPage({super.key});

  @override
  State<ProductDetailsPage> createState() => _ProductDetailsPageState();
}

class _ProductDetailsPageState extends State<ProductDetailsPage> {
  late Timer _timer;
  late int _remainingTimeInSeconds;

  @override
  void initState() {
    super.initState();
    // Set initial countdown time (e.g., 2 hours, 30 minutes, and 15 seconds)
    _remainingTimeInSeconds = 2 * 60 * 60 + 30 * 60 + 15;
    // Start the countdown
    _startCountdown();
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  void _startCountdown() {
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (_remainingTimeInSeconds > 0) {
        setState(() {
          _remainingTimeInSeconds--;
        });
      } else {
        _timer.cancel();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Palette.white,
        iconTheme: IconThemeData(color: Palette.secondary),
        actions: [
          IconButton(
            onPressed: () {},
            icon: Icon(Icons.share),
          ),
        ],
      ),
      bottomSheet: addToCart(context),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Image.asset(
              'assets/images/langka_image.png',
              height: 200,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Flash Sale Section
                flashSaleSection(),
                // Item Details Section
                itemDetailsSection(),
                // Special Instructions
                Gap(12),
                specialInstructions(context),
                Gap(12),
                // Recommended for you
                recommendItemList(),
                Gap(96),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget recommendItemList() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          WidgetText(
            text: 'Recommended for you',
            size: 12,
            weight: FontWeight.w600,
          ),
          Gap(12),
          SizedBox(
            height: 250,
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: 10,
              scrollDirection: Axis.horizontal,
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    height: 170,
                    width: 150,
                    decoration: BoxDecoration(
                      color: Palette.white.withValues(alpha: 0.5),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          CircleAvatar(
                            radius: 45,
                            backgroundColor: Palette.white,
                            backgroundImage:
                                AssetImage('assets/icons/zagana_icon.png'),
                          ),
                          WidgetText(
                            text: 'Zagana Dalandan 500g',
                            size: 12,
                            weight: FontWeight.w600,
                          ),
                          Gap(12),
                          WidgetButton(
                            text: '₱ 90.00',
                            onPressed: () {},
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget addToCart(BuildContext context) {
    return Container(
      width: MediaQuery.sizeOf(context).width,
      decoration: BoxDecoration(
        color: Palette.white,
      ),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            IconButton(
              onPressed: () {},
              icon: Icon(
                Ionicons.remove_circle_outline,
                color: Palette.primary,
                size: 36,
              ),
            ),
            WidgetText(
              text: '12',
              size: 12,
              weight: FontWeight.w600,
            ),
            // Increment Items Value
            IconButton(
              onPressed: () {},
              icon: Icon(
                Ionicons.add_circle,
                color: Palette.primary,
                size: 36,
              ),
            ),
            WidgetButton(
              text: 'Add to Cart',
              onPressed: () {},
            ),
          ],
        ),
      ),
    );
  }

  Widget specialInstructions(BuildContext context) {
    return Container(
      width: MediaQuery.sizeOf(context).width,
      decoration: BoxDecoration(
        color: Palette.white,
      ),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            WidgetText(
              text: 'Special Instructions (Optional)',
              size: 14,
            ),
            Divider(),
            WidgetTextField(
              hintText: 'e.g: No damage fruits pls.',
              hintColor: Palette.gray,
            ),
          ],
        ),
      ),
    );
  }

  Widget itemDetailsSection() {
    return Container(
      decoration: BoxDecoration(
        color: Palette.white,
      ),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      WidgetText(
                        text: 'Zagana Alugbati 500g',
                        size: 14,
                      ),
                      WidgetText(
                        text: 'Buy 2, get 25% off',
                        color: Palette.primary,
                        size: 12,
                      ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: () {},
                  icon: Icon(
                    Ionicons.heart_outline,
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    WidgetText(
                      text: '₱18.00',
                      color: Palette.primary,
                      size: 14,
                      weight: FontWeight.w600,
                    ),
                    WidgetText(
                      text: '₱35.00',
                      color: Palette.gray,
                      size: 12,
                      textDecoration: TextDecoration.lineThrough,
                    ),
                  ],
                ),
              ],
            ),
            Gap(8),
            WidgetText(
              text:
                  'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut.',
              size: 12,
            ),
            Divider(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                WidgetText(
                  text: '500g',
                  size: 12,
                ),
                WidgetText(
                  text: '30 Available',
                  size: 12,
                ),
                WidgetText(
                  text: '65578 Sold',
                  size: 12,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget flashSaleSection() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Palette.primary,
            Palette.secondary,
          ],
        ),
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(16),
          topRight: Radius.circular(16),
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Image.asset(
                'assets/icons/flashsale_text_icon.png',
                height: 24,
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                // Timer Row (Ends in)
                timerRow(),
                // Slider for Availability
                availabilitySlider(),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget timerRow() {
    int hours = _remainingTimeInSeconds ~/ 3600;
    int minutes = (_remainingTimeInSeconds % 3600) ~/ 60;
    int seconds = _remainingTimeInSeconds % 60;

    return Row(
      children: [
        WidgetText(
          text: 'Ends in',
          color: Palette.white,
          size: 14,
        ),
        // Hours
        _timeCard(hours.toString().padLeft(2, '0')),
        // Minutes
        _timeCard(minutes.toString().padLeft(2, '0')),
        // Seconds
        _timeCard(seconds.toString().padLeft(2, '0')),
      ],
    );
  }

  Widget _timeCard(String time) {
    return Card(
      color: Palette.white,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: WidgetText(
          text: time,
          color: Palette.primary,
          size: 12,
        ),
      ),
    );
  }

  Widget availabilitySlider() {
    return Row(
      children: [
        SliderTheme(
          data: SliderTheme.of(context).copyWith(
            trackHeight: 8,
            thumbColor: Colors.transparent,
            thumbShape: RoundSliderThumbShape(
              enabledThumbRadius: 0.0,
            ),
          ),
          child: Slider.adaptive(
            value: 20,
            max: 45,
            min: 0,
            activeColor: Palette.primary,
            inactiveColor: Palette.semiWhite,
            onChanged: (double value) {},
          ),
        ),
        WidgetText(
          text: 'Available',
          color: Palette.white,
          size: 12,
        ),
      ],
    );
  }
}
