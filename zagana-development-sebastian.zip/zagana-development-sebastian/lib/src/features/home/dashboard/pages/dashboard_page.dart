import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:ionicons/ionicons.dart';
import 'package:zagana/src/core/widgets/widget_exit_dialog.dart';
import 'package:zagana/src/features/auth/login/login_page.dart';
import 'package:zagana/src/features/home/dashboard/components/advertisement_indicator.dart';
import 'package:zagana/src/features/home/dashboard/components/branches_list.dart';
import 'package:zagana/src/features/home/dashboard/components/categories.dart';
import 'package:zagana/src/features/home/dashboard/components/cart_notification_counter.dart';
import 'package:zagana/src/features/home/dashboard/components/recipe_list.dart';
import 'package:zagana/src/features/home/drawer/pages/profile_drawer.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';
import 'package:zagana/src/features/home/dashboard/widgets/widget_view_cart_container.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  bool showContainer = false; // Flag to control the container visibility

  void toggleContainer(bool show) {
    setState(() {
      showContainer = show;
    });
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        showAdaptiveDialog(
          context: context,
          builder: (context) {
            return WidgetExitDialog(
              title: 'Exit Application',
              content: 'Are you sure you want to exit?',
              continuePressed: () {
                Get.offAll(() => LoginPage());
              },
            );
          },
        );
        return false;
      },
      child: RefreshIndicator.adaptive(
        onRefresh: () {
          return Future.delayed(
            Duration(seconds: 2),
          );
        },
        child: Scaffold(
          appBar: AppBar(
            centerTitle: false,
            iconTheme: IconThemeData(
              color: Palette.white,
            ),
            backgroundColor: Palette.primary,
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                WidgetText(
                  text: 'Delivering to',
                  color: Palette.white,
                  size: 12,
                  weight: FontWeight.w500,
                ),
                WidgetText(
                  text: '29 Alfred St, Antipolo City',
                  color: Palette.white,
                  size: 14,
                  weight: FontWeight.w500,
                ),
              ],
            ),
            actions: [
              IconButton(
                onPressed: () {},
                icon: Icon(Ionicons.search),
              ),
              IconButton(
                onPressed: () {},
                icon: Icon(Ionicons.heart_outline),
              ),
              CartNotificationCounter(),
            ],
          ),
          drawer: ProfileDrawer(),
          body: Stack(
            children: [
              SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Delivery Time
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          WidgetText(
                            text: 'Today, 10:00 - 11:00 AM',
                            size: 12,
                            weight: FontWeight.w600,
                          ),
                          GestureDetector(
                            onTap: () {},
                            child: WidgetText(
                              text: 'Change delivery time',
                              color: Palette.primary,
                              size: 12,
                              weight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                    AdvertisementIndicator(),
                    Gap(12),
                    BranchesList(),
                    Gap(12),
                    RecipeList(),
                    Gap(12),
                    Categories(toggleFab: toggleContainer),
                  ],
                ),
              ),
              if (showContainer) WidgetViewCartContainer(),
            ],
          ),
        ),
      ),
    );
  }
}
