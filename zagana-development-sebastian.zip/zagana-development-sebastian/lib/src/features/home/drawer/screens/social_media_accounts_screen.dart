import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:gap/gap.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';

class SocialMediaAccountsScreen extends StatefulWidget {
  const SocialMediaAccountsScreen({super.key});

  @override
  State<SocialMediaAccountsScreen> createState() =>
      _SocialMediaAccountsScreenState();
}

class _SocialMediaAccountsScreenState extends State<SocialMediaAccountsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: WidgetText(
          text: 'Social Media Accounts',
          size: 14,
        ),
        backgroundColor: Palette.white,
      ),
      body: _socialMediaAccounts(),
    );
  }

  Padding _socialMediaAccounts() {
    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: Column(
        children: [
          _row(
            'assets/images/logos_facebook.svg',
            'Facebook',
          ),
          _row(
            'assets/images/skill-icons_instagram.svg',
            'Instagram',
          ),
          _row(
            'assets/images/flat-color-icons_google.svg',
            'Google',
          ),
          _row(
            'assets/images/mage_x-square.svg',
            'Twitter',
          ),
        ],
      ),
    );
  }

  Row _row(String assetName, String? title) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            SvgPicture.asset(assetName),
            Gap(12),
            WidgetText(
              text: title,
              weight: FontWeight.bold,
              size: 14,
            ),
          ],
        ),
        Transform.scale(
          scale: 0.7,
          child: Switch.adaptive(
            value: false,
            onChanged: (value) {},
          ),
        ),
      ],
    );
  }
}
