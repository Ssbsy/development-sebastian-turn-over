import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:gap/gap.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';

class AboutScreen extends StatefulWidget {
  const AboutScreen({super.key});

  @override
  State<AboutScreen> createState() => _AboutScreenState();
}

class _AboutScreenState extends State<AboutScreen> {
  @override
  Widget build(BuildContext context) {
    final currentHeight = MediaQuery.of(context).size.height;
    final currentWidth = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: WidgetText(
          text: 'About',
          size: 14,
          weight: FontWeight.w600,
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: currentHeight * 0.25,
              width: double.infinity,
              decoration: BoxDecoration(
                color: Palette.primary,
              ),
              child: Center(
                child: Image.asset(
                  'assets/images/zagana_logo_image.png',
                  width: currentWidth * 0.75,
                ),
              ),
            ),
            Gap(20),
            Padding(
              padding: const EdgeInsets.only(left: 15.0),
              child: Row(
                children: [
                  WidgetText(
                    text: 'Who',
                    weight: FontWeight.bold,
                    size: 16,
                  ),
                  Gap(5),
                  WidgetText(
                    text: 'are we?',
                    weight: FontWeight.bold,
                    color: Palette.primary,
                    size: 16,
                  ),
                ],
              ),
            ),
            Gap(15),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15.0),
              child: WidgetText(
                text:
                    'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
              ),
            ),
            Gap(10),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15.0),
              child: WidgetText(
                text:
                    'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.',
              ),
            ),
            Gap(15),
            Padding(
              padding: const EdgeInsets.only(left: 15.0),
              child: Row(
                children: [
                  WidgetText(
                    text: 'The',
                    weight: FontWeight.bold,
                    size: 16,
                  ),
                  Gap(5),
                  WidgetText(
                    text: 'Mission',
                    weight: FontWeight.bold,
                    color: Palette.primary,
                    size: 16,
                  ),
                ],
              ),
            ),
            Gap(15),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15.0),
              child: WidgetText(
                text:
                    'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
              ),
            ),
            Gap(15),
            Padding(
              padding: const EdgeInsets.only(left: 15.0),
              child: Row(
                children: [
                  WidgetText(
                    text: 'The',
                    weight: FontWeight.bold,
                    size: 16,
                  ),
                  Gap(5),
                  WidgetText(
                    text: 'Vision',
                    weight: FontWeight.bold,
                    color: Palette.primary,
                    size: 16,
                  ),
                ],
              ),
            ),
            Gap(15),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15.0),
              child: WidgetText(
                text:
                    'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 15.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  SvgPicture.asset('assets/images/team-goals.svg'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
