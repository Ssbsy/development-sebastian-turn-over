import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';
import 'package:flutter_svg/flutter_svg.dart';

class HelpCenterScreen extends StatefulWidget {
  const HelpCenterScreen({super.key});

  @override
  State<HelpCenterScreen> createState() => _HelpCenterScreenState();
}

class _HelpCenterScreenState extends State<HelpCenterScreen> {
  //For Scrollable box
  final ScrollController _scrollController = ScrollController();
  double circleOffset = 0.0;

  //Make the scrollable box function
  @override
  void initState() {
    super.initState();
    //Add listener for live
    _scrollController.addListener(() {
      setState(() {
        circleOffset = _scrollController.offset;
      });
    });
  }

  //Dispose the _scrollCotnroller
  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final currentWidth = MediaQuery.of(context).size.width;
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus,
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          title: WidgetText(
            text: 'Help Center',
            size: 14,
            weight: FontWeight.w600,
          ),
        ),
        body: Stack(
          clipBehavior: Clip.none,
          children: [
            //Green Box
            Positioned(
              top: -220 - circleOffset,
              left: -35,
              child: Container(
                height: 420,
                width: currentWidth * 1.20,
                decoration: BoxDecoration(
                    color: Palette.primary, shape: BoxShape.circle),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(24),
              child: SingleChildScrollView(
                controller: _scrollController,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    WidgetText(
                      text: 'Do you have a questions?',
                      size: 14,
                      weight: FontWeight.w600,
                    ),
                    Gap(8),
                    //Search Field
                    TextField(
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: Palette.white,
                        hintText: 'Search',
                        border: OutlineInputBorder(
                          borderSide: BorderSide.none,
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                    Gap(90),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Padding(
                              padding:
                                  const EdgeInsets.only(left: 8.0, bottom: 8),
                              child: WidgetText(
                                text: 'Frequently Asked Questions',
                                size: 14,
                                weight: FontWeight.bold,
                                family: 'Robotto',
                              ),
                            ),
                            WidgetText(
                              text: 'View All',
                              color: Palette.primary,
                              family: 'Robotto',
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 130,
                          child: ListView.builder(
                              scrollDirection: Axis.horizontal,
                              itemCount: 3,
                              itemBuilder: (context, index) {
                                List<Color> colors = [
                                  Palette.secondary,
                                  Palette.primary,
                                ];
                                List<String> texts = [
                                  'How do i cancel an existing order?',
                                  'What are the other shipping options?',
                                  'What can i do if i placed my other saved location during delivery?'
                                ];
                                return Container(
                                  width: 130,
                                  margin: EdgeInsets.symmetric(horizontal: 8),
                                  decoration: BoxDecoration(
                                    color: colors[index %
                                        colors.length], // Cylce through colors
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          texts[index],
                                          style: const TextStyle(
                                            color: Palette.black,
                                            fontSize: 12,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.end,
                                          children: [
                                            Container(
                                              padding: EdgeInsets.all(5),
                                              width: currentWidth * 0.28,
                                              decoration: BoxDecoration(
                                                color: Palette.white,
                                                borderRadius:
                                                    BorderRadius.circular(12),
                                              ),
                                              child: Center(
                                                child: WidgetText(
                                                  text: 'View Answer',
                                                  size: 10,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              }),
                        ),
                      ],
                    ),
                    Gap(30),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 8.0),
                          child: WidgetText(
                            text: 'Topics',
                            weight: FontWeight.bold,
                            size: 14,
                            family: 'Robotto',
                          ),
                        ),
                        WidgetText(
                          text: 'View All',
                          color: Palette.primary,
                          family: 'Robotto',
                        ),
                      ],
                    ),
                    Gap(20),
                    ListView.separated(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: 5,
                      itemBuilder: (context, index) {
                        List<Map<String, dynamic>> items = [
                          {
                            'image': 'assets/images/boxes.svg',
                            'title': 'Returns and Refunds',
                            'subtitle': '10 articles',
                          },
                          {
                            'image': 'assets/images/truck.svg',
                            'title': 'Shipping and Delivery',
                            'subtitle': '5 articles',
                          },
                          {
                            'image': 'assets/images/payments.svg',
                            'title': 'Payments',
                            'subtitle': '6 articles',
                          },
                          {
                            'image': 'assets/images/points_and_gifts.svg',
                            'title': 'Points and Rewards',
                            'subtitle': '7 articles',
                          },
                          {
                            'image': 'assets/images/credits.svg',
                            'title': 'Credits',
                            'subtitle': '8 articles',
                          },
                        ];
                        final item = items[index];

                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 10.0),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              SizedBox(
                                width: 70,
                                height: 70,
                                //Gumamit po ako ng SVG
                                child: SvgPicture.asset(
                                  item['image'] ??
                                      'assets/images/placeholder.svg',
                                  fit: BoxFit.contain,
                                  alignment: Alignment.center,
                                  clipBehavior: Clip.hardEdge,
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  spacing: 5,
                                  children: [
                                    WidgetText(
                                      text: item['title'],
                                      size: 14,
                                      weight: FontWeight.w600,
                                    ),
                                    WidgetText(
                                      text: item['subtitle'],
                                      color: Palette.primary,
                                      size: 12,
                                      weight: FontWeight.w600,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                      separatorBuilder: (context, index) =>
                          const SizedBox(height: 8),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        floatingActionButton: InkWell(
          onTap: () {},
          borderRadius: BorderRadius.circular(28),
          child: SvgPicture.asset(
            'assets/images/jam_messenger.svg',
            fit: BoxFit.fill,
          ),
        ),
      ),
    );
  }
}
