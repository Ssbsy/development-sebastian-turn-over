import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';

class Notifications extends StatefulWidget {
  const Notifications({super.key});

  @override
  State<Notifications> createState() => _NotificationsState();
}

class _NotificationsState extends State<Notifications> {
  var pushSwitch = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: WidgetText(
          text: 'Notifications',
          size: 14,
          weight: FontWeight.w600,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            pushNotifications(),
            Gap(36),
            zaganaUpdates(),
          ],
        ),
      ),
    );
  }

  Column zaganaUpdates() {
    return Column(
      children: [
        _rowSwitchHeader(
          'Zagana Updates',
          (value) {},
          true,
        ),
        Gap(8),
        Padding(
          padding: const EdgeInsets.only(left: 16),
          child: Column(
            children: [
              _rowSwitch(
                'Email',
                (value) {},
                false,
              ),
              _rowSwitch(
                'SMS',
                (value) {},
                true,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Column pushNotifications() {
    return Column(
      children: [
        _rowSwitchHeader(
          'Push Notifications',
          (value) {},
          true,
        ),
        Gap(8),
        Padding(
          padding: const EdgeInsets.only(left: 16),
          child: Column(
            children: [
              _rowSwitch(
                'Order Notifications',
                (value) {},
                false,
              ),
              _rowSwitch(
                'Email',
                (value) {},
                true,
              ),
              _rowSwitch(
                'SMS',
                (value) {},
                false,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Row _rowSwitchHeader(String? title, Function(bool)? onChanged, bool? value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        WidgetText(
          text: title,
          size: 14,
          weight: FontWeight.w600,
        ),
        Switch.adaptive(
          value: value!,
          onChanged: onChanged,
        ),
      ],
    );
  }

  Row _rowSwitch(String? subTitle, Function(bool)? onChanged, bool? value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        WidgetText(
          text: subTitle,
          size: 12,
        ),
        Switch.adaptive(
          value: value!,
          onChanged: onChanged,
        ),
      ],
    );
  }
}
