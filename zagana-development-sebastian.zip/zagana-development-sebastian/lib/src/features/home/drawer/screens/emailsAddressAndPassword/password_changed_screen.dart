import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';

class PasswordChangedScreen extends StatefulWidget {
  const PasswordChangedScreen({super.key});

  @override
  State<PasswordChangedScreen> createState() => _PasswordChangedScreenState();
}

class _PasswordChangedScreenState extends State<PasswordChangedScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: WidgetText(
          text: 'Password Changed',
          size: 14,
          weight: FontWeight.w600,
        ),
        backgroundColor: Palette.white,
      ),
      body: Center(
        child: Column(
          spacing: 20,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SvgPicture.asset('assets/images/password_changed_screen_image.svg'),
            WidgetText(
              text: 'Password Changed',
              weight: FontWeight.bold,
              color: Palette.primary,
            ),
            WidgetText(
              text: 'You have successfully changed your password.',
              size: 10,
            ),
          ],
        ),
      ),
    );
  }
}
