import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:gap/gap.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';

class CreditsPlaceholder extends StatefulWidget {
  const CreditsPlaceholder({super.key});

  @override
  State<CreditsPlaceholder> createState() => _CreditsPlaceholderState();
}

class _CreditsPlaceholderState extends State<CreditsPlaceholder> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          title: WidgetText(
            text: 'Credits',
            size: 14,
            weight: FontWeight.w600,
          ),
          backgroundColor: Palette.white),
      body: Padding(
        padding: const EdgeInsets.all(25.0),
        child: SingleChildScrollView(
          child: _mainColumn(
              'assets/images/credits.svg',
              'How does a credit card work?',
              'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
        ),
      ),
    );
  }

  Column _mainColumn(String imageAsset, String title, String subtitle) {
    return Column(
      children: [
        Center(
          child: SvgPicture.asset(
            imageAsset,
            width: 100,
          ),
        ),
        Gap(30),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: WidgetText(
                text: title,
                color: Palette.primary,
              ),
            ),
            Icon(
              Icons.arrow_upward,
              color: Palette.primary,
              size: 15,
            ),
          ],
        ),
        Gap(15),
        WidgetText(
          text: subtitle,
        ),
        Gap(25),
        _subColumn(),
      ],
    );
  }

  Column _subColumn() {
    return Column(
      spacing: 15,
      children: [
        _rows('What are the benefits of using a credit card?'),
        _rows('How do I apply for a credit card?'),
        _rows('How does interest work on credit cards?'),
        _rows('Can I have multiple credit cards?'),
        _rows('What is a credit card grace period?'),
        _rows('What is a secured credit card?'),
        _rows('How to pay a credit card bill from another credit card?'),
      ],
    );
  }

  Row _rows(String title) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: WidgetText(
            text: title,
            size: 10,
            weight: FontWeight.bold,
          ),
        ),
        Icon(
          Icons.arrow_downward,
          color: Palette.primary,
          size: 15,
        ),
      ],
    );
  }
}
