import 'package:flutter/material.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';

class PrivacySettingsScreen extends StatefulWidget {
  const PrivacySettingsScreen({super.key});

  @override
  State<PrivacySettingsScreen> createState() => _PrivacySettingsScreenState();
}

class _PrivacySettingsScreenState extends State<PrivacySettingsScreen> {
  var pushSwitch = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: WidgetText(
          text: 'Privacy Settings',
          size: 16,
        ),
        backgroundColor: Palette.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: privacySettings(),
      ),
    );
  }

  Column privacySettings() {
    return Column(
      children: [
        _rows(
          'Contact list',
          'Allow to access my contact list on this device',
        ),
        _rows(
          'Location',
          'Allow to access my location information',
        ),
        _rows(
          'Photos',
          'Allow to access my photo album',
        ),
        _rows(
          'Camera',
          'Allow to access my phone camera',
        ),
      ],
    );
  }

  Row _rows(String? title, String? subTitle) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        _column(
          title,
          subTitle,
        ),
        Transform.scale(
          scale: 0.7,
          child: Switch.adaptive(
            value: pushSwitch,
            onChanged: (value) {
              setState(
                () {},
              );
            },
          ),
        ),
      ],
    );
  }

  Column _column(String? title, String? subTitle) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        WidgetText(
          text: title,
        ),
        WidgetText(
          text: subTitle,
          size: 9,
        ),
      ],
    );
  }
}
