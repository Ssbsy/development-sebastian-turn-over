import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_button.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';
import 'package:zagana/src/core/widgets/widget_text_field.dart';
import 'package:zagana/src/features/home/drawer/screens/emailsAddressAndPassword/password_changed_screen.dart';

class ChangePasswordScreen extends StatefulWidget {
  const ChangePasswordScreen({super.key});

  @override
  State<ChangePasswordScreen> createState() => _ChangePasswordScreenState();
}

class _ChangePasswordScreenState extends State<ChangePasswordScreen> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus,
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () => Navigator.pop(context),
          ),
          title: WidgetText(
            text: 'Change Password',
            size: 14,
            weight: FontWeight.w600,
          ),
          backgroundColor: Palette.white,
        ),
        body: SizedBox(
          height: MediaQuery.of(context).size.height,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(30.0),
                        child: _subColumn(
                          'Current Password',
                          true,
                        ),
                      ),
                      Container(
                        height: 20,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: Palette.primary,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            top: 30.0, left: 30, right: 30),
                        child: _subColumn(
                          'New Password',
                          true,
                        ),
                      ),
                      Gap(20),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 30.0),
                        child: _subColumn(
                          'Re-enter New Password',
                          true,
                        ),
                      ),
                      Gap(20),
                      _row(
                        'Please type at least 8 Characters',
                      ),
                      Gap(10),
                      _row(
                        'Add a special characters',
                      ),
                    ],
                  ),
                ),
              ),
              WidgetButton(
                onPressed: () {
                  Get.to(() => PasswordChangedScreen());
                },
                text: 'Change Password',
              ),
            ],
          ),
        ),
      ),
    );
  }

  Padding _row(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 40.0),
      child: Row(
        spacing: 10,
        children: [
          Icon(
            Icons.check,
            color: Palette.primary,
            size: 18,
          ),
          WidgetText(
            text: title,
            color: Palette.primary,
            size: 10,
          ),
        ],
      ),
    );
  }

  Column _subColumn(String title, bool obscureText) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        WidgetText(
          text: title,
          color: Palette.gray,
        ),
        WidgetTextField(
          hintText: '********',
          obscureText: obscureText,
        ),
      ],
    );
  }
}
