import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:gap/gap.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';

class ReturnAndRefundsPlaceholder extends StatefulWidget {
  const ReturnAndRefundsPlaceholder({super.key});

  @override
  State<ReturnAndRefundsPlaceholder> createState() =>
      _ReturnAndRefundsPlaceholderState();
}

class _ReturnAndRefundsPlaceholderState
    extends State<ReturnAndRefundsPlaceholder> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          title: WidgetText(
            text: 'Returns and Refunds',
            size: 14,
            weight: FontWeight.w600,
          ),
          backgroundColor: Palette.white),
      body: Padding(
        padding: const EdgeInsets.all(25.0),
        child: SingleChildScrollView(
          child: _mainColumn(
              'assets/images/boxes.svg',
              'How long after accepting a payment do I have to issue a refund?',
              'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
        ),
      ),
    );
  }

  Column _mainColumn(String imageAsset, String title, String subtitle) {
    return Column(
      children: [
        Center(
          child: SvgPicture.asset(
            imageAsset,
            width: 100,
          ),
        ),
        Gap(30),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: WidgetText(
                text: title,
                color: Palette.primary,
              ),
            ),
            Icon(
              Icons.arrow_upward,
              color: Palette.primary,
              size: 15,
            ),
          ],
        ),
        Gap(15),
        WidgetText(
          text: subtitle,
        ),
        Gap(25),
        _subColumn(),
      ],
    );
  }

  Column _subColumn() {
    return Column(
      spacing: 15,
      children: [
        _rows('How long does it take for refunds to process?'),
        _rows('Can I refund part of the original payment amount?'),
        _rows('Can I cancel the refund that I accidentally processed?'),
        _rows('What happens to the processing fee when I issue a return?'),
        _rows(
            'Is there a limit on the number of refunds I can process with Square?'),
        _rows('Will my customer be notified when my refund is completed?'),
        _rows('How do I know when a refund is complete? '),
        _rows('What happens if a refund was sent to a cancelled payment card?'),
      ],
    );
  }

  Row _rows(String title) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: WidgetText(
            text: title,
            size: 10,
            weight: FontWeight.bold,
          ),
        ),
        Icon(
          Icons.arrow_downward,
          color: Palette.primary,
          size: 15,
        ),
      ],
    );
  }
}
