import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:gap/gap.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';

class PaymentsPlaceholder extends StatefulWidget {
  const PaymentsPlaceholder({super.key});

  @override
  State<PaymentsPlaceholder> createState() => _PaymentsPlaceholderState();
}

class _PaymentsPlaceholderState extends State<PaymentsPlaceholder> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          title: WidgetText(
            text: 'Payments',
            size: 14,
            weight: FontWeight.w600,
          ),
          backgroundColor: Palette.white),
      body: Padding(
        padding: const EdgeInsets.all(25.0),
        child: SingleChildScrollView(
          child: _mainColumn(
              'assets/images/payments.svg',
              'What payment methods do you accept?',
              'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
        ),
      ),
    );
  }

  Column _mainColumn(String imageAsset, String title, String subtitle) {
    return Column(
      children: [
        Center(
          child: SvgPicture.asset(
            imageAsset,
            width: 150,
          ),
        ),
        Gap(30),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: WidgetText(
                text: title,
                color: Palette.primary,
              ),
            ),
            Icon(
              Icons.arrow_upward,
              color: Palette.primary,
              size: 15,
            ),
          ],
        ),
        Gap(15),
        WidgetText(
          text: subtitle,
        ),
        Gap(25),
        _subColumn(),
      ],
    );
  }

  Column _subColumn() {
    return Column(
      spacing: 15,
      children: [
        _rows('How do I update my credit card information?'),
        _rows('What do I do if my credit card is not accepted?'),
        _rows('Is there an alternate form of payment available?'),
        _rows('How do I change my billing information?'),
        _rows('What payment gateway do you use?'),
      ],
    );
  }

  Row _rows(String title) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: WidgetText(
            text: title,
            size: 10,
            weight: FontWeight.bold,
          ),
        ),
        Icon(
          Icons.arrow_downward,
          color: Palette.primary,
          size: 15,
        ),
      ],
    );
  }
}
