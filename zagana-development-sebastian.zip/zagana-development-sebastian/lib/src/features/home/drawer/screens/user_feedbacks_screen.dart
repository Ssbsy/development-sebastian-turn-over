import 'package:flutter/material.dart';
import 'package:flutter_emoji_feedback/flutter_emoji_feedback.dart';
import 'package:gap/gap.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_button.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';

class UserFeedbacksScreen extends StatefulWidget {
  const UserFeedbacksScreen({super.key});

  @override
  State<UserFeedbacksScreen> createState() => _UserFeedbacksScreenState();
}

class _UserFeedbacksScreenState extends State<UserFeedbacksScreen> {
  final Set<String> _selectedCategories = {};
  int? selectedRating;

  @override
  Widget build(BuildContext context) {
    final currentHeight = MediaQuery.of(context).size.height;

    return GestureDetector(
      onTap: FocusScope.of(context).unfocus,
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => Navigator.pop(context),
          ),
          title: const WidgetText(
            text: 'User Feedback',
            weight: FontWeight.bold,
            size: 14,
          ),
          backgroundColor: Palette.white,
        ),
        body: SingleChildScrollView(
            child: _userFeedBackMainColumn(currentHeight)),
      ),
    );
  }

  Column _userFeedBackMainColumn(double currentHeight) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: double.infinity,
          height: currentHeight * 0.2,
          decoration: const BoxDecoration(
            color: Palette.primary,
          ),
          child: Center(
            child: _containerRow(),
          ),
        ),
        _userFeedBackSubColumn('Tell us what we can improve?'),
      ],
    );
  }

  Padding _userFeedBackSubColumn(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          WidgetText(
            text: title,
            weight: FontWeight.bold,
          ),
          const Gap(10),
          _userFeedBackCategory([
            'OverAll Service',
            'Delivery Service',
            'Service Efficiency',
            'Transparency',
            'Customer Support',
            'Order',
          ]),
          _suggestionColumn(),
        ],
      ),
    );
  }

  Padding _suggestionColumn() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 30.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        spacing: 15,
        children: [
          WidgetText(
            text: 'Do you have a questions?',
            weight: FontWeight.bold,
          ),
          Container(
            decoration: BoxDecoration(color: Colors.grey.shade200),
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: TextField(
                decoration: InputDecoration(
                  hintText: 'Other Suggestions...',
                  hintStyle: TextStyle(fontSize: 12),
                  border: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                ),
                maxLines: 10,
              ),
            ),
          ),
          Gap(30),
          WidgetButton(
            onPressed: () {},
            text: 'Submit',
          ),
        ],
      ),
    );
  }

  Widget _userFeedBackCategory(List<String> categories) {
    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: categories.map((text) {
        final isSelected = _selectedCategories.contains(text);
        return GestureDetector(
          onTap: () {
            setState(() {
              if (isSelected) {
                _selectedCategories.remove(text);
              } else {
                _selectedCategories.add(text);
              }
            });
          },
          child: Card(
            color: isSelected ? Palette.primary : Palette.white,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: WidgetText(
                text: text,
                size: 10,
                color: isSelected ? Palette.white : Palette.black,
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _containerRow() {
    return SingleChildScrollView(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: 280,
            height: 100,
            child: EmojiFeedback(
              initialRating: selectedRating,
              animDuration: Duration(milliseconds: 300),
              curve: Curves.easeInOut,
              inactiveElementScale: 0.5,
              onChanged: (value) {
                setState(() {
                  selectedRating = value;
                });
                print('Selected rating: $value');
              },
              onChangeWaitForAnimation: true,
            ),
          ),
        ],
      ),
    );
  }
}
