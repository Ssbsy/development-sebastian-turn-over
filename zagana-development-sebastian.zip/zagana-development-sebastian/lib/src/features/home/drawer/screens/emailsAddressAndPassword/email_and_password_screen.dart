import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_button.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';
import 'package:zagana/src/core/widgets/widget_text_field.dart';
import 'package:zagana/src/features/home/drawer/screens/emailsAddressAndPassword/change_password_screen.dart';

class EmailAndPasswordScreen extends StatefulWidget {
  const EmailAndPasswordScreen({super.key});

  @override
  State<EmailAndPasswordScreen> createState() => _EmailAndPasswordScreenState();
}

class _EmailAndPasswordScreenState extends State<EmailAndPasswordScreen> {
  final TextEditingController _emailController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: WidgetText(
          text: 'Email And Password',
          size: 14,
          weight: FontWeight.w600,
        ),
        backgroundColor: Palette.white,
      ),
      body: Padding(
        padding: EdgeInsets.all(40.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                WidgetText(
                  text: 'Email Address',
                ),
                WidgetTextField(
                  controller: _emailController,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 15.0),
                  child: Row(
                    spacing: 5,
                    children: [
                      SvgPicture.asset(
                          'assets/images/clarity_shield-solid.svg'),
                      Expanded(
                        child: WidgetText(
                          text:
                              'This account is protected and verified by the user',
                          color: Palette.gray,
                          size: 7.5,
                        ),
                      ),
                    ],
                  ),
                ),
                Gap(20),
                WidgetText(
                  text: 'Change Password',
                  color: Palette.primary,
                ),
              ],
            ),
            WidgetButton(
              onPressed: () {
                Get.to(() => ChangePasswordScreen());
              },
              text: 'Verify',
            ),
          ],
        ),
      ),
    );
  }
}
