import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_button.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';
import 'package:zagana/src/core/widgets/widget_text_field.dart';
import 'package:zagana/src/features/home/dashboard/components/stack_circle_avatar.dart';

class AccountScreen extends StatefulWidget {
  const AccountScreen({super.key});

  @override
  State<AccountScreen> createState() => _AccountScreenState();
}

class _AccountScreenState extends State<AccountScreen> {
  final firstName = TextEditingController(),
      lastName = TextEditingController(),
      birthday = TextEditingController();

  Future<void> _selectBirthday(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      helpText: '',
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      final formattedDate = '${picked.month}/${picked.day}/${picked.year}';
      birthday.text = formattedDate;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: WidgetText(
          text: 'Account',
          size: 14,
          weight: FontWeight.w600,
        ),
      ),
      body: Column(
        children: [
          Container(
            width: MediaQuery.sizeOf(context).width,
            decoration: BoxDecoration(color: Palette.primary),
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Center(
                child: StackCircleAvatar(
                  onPressed: () {},
                  radius: 60,
                  showContainer: true,
                  assetImage: 'assets/images/profile_image.jpg',
                  iconAsset: Padding(
                    padding: const EdgeInsets.all(2),
                    child: Icon(
                      Icons.camera_alt,
                      size: 24,
                    ),
                  ),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _titleText('First Name'),
                // First Name TextField
                WidgetTextField(
                  controller: firstName,
                  hintText: 'e.g: Juan',
                ),
                Gap(12),
                _titleText('Last Name'),
                // Last Name TextField
                WidgetTextField(
                  controller: lastName,
                  hintText: 'e.g: Dela Cruz',
                ),
                Gap(12),
                _titleText('Birthday'),
                // Birthday TextField with the calendar picker
                GestureDetector(
                  onTap: () => _selectBirthday(context),
                  child: WidgetTextField(
                    controller: birthday,
                    hintText: 'MM/DD/YYYY',
                    enabled:
                        false, // Make the TextField non-editable, only tap to pick a date
                  ),
                ),
                Gap(12),
                WidgetButton(
                  text: 'Save',
                  onPressed: () {},
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  WidgetText _titleText(String? text) {
    return WidgetText(
      text: text,
      color: Palette.gray,
      size: 14,
    );
  }
}
