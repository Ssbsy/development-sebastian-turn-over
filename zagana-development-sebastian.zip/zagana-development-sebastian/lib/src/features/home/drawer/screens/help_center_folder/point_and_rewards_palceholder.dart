import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:gap/gap.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';

class PointAndRewardsPalceholder extends StatefulWidget {
  const PointAndRewardsPalceholder({super.key});

  @override
  State<PointAndRewardsPalceholder> createState() =>
      _PointAndRewardsPalceholderState();
}

class _PointAndRewardsPalceholderState
    extends State<PointAndRewardsPalceholder> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          title: WidgetText(
            text: 'Points and Rewards',
            size: 14,
            weight: FontWeight.w600,
          ),
          backgroundColor: Palette.white),
      body: Padding(
        padding: const EdgeInsets.all(25.0),
        child: SingleChildScrollView(
          child: _mainColumn(
              'assets/images/points_and_gifts.svg',
              'How could I use my points earned?',
              'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
        ),
      ),
    );
  }

  Column _mainColumn(String imageAsset, String title, String subtitle) {
    return Column(
      children: [
        Center(
          child: SvgPicture.asset(
            imageAsset,
            width: 100,
          ),
        ),
        Gap(30),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: WidgetText(
                text: title,
                color: Palette.primary,
              ),
            ),
            Icon(
              Icons.arrow_upward,
              color: Palette.primary,
              size: 15,
            ),
          ],
        ),
        Gap(15),
        WidgetText(
          text: subtitle,
        ),
        Gap(25),
        _subColumn(),
      ],
    );
  }

  Column _subColumn() {
    return Column(
      spacing: 15,
      children: [
        _rows('What is the minimum number of points required for redemption?'),
        _rows(
            'Is there any requirement regarding the number of points to be used each time I want to redeem my points?'),
        _rows(
            'Can I convert the points accrued into cash and withdraw it from my account?'),
        _rows('How do I check my points accumulated in my account?'),
        _rows('Is there a validity period for the reward points accumulated?'),
        _rows(
            'If I offset my purchase with my points, will there be points credited to my account?'),
      ],
    );
  }

  Row _rows(String title) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: WidgetText(
            text: title,
            size: 10,
            weight: FontWeight.bold,
          ),
        ),
        Icon(
          Icons.arrow_downward,
          color: Palette.primary,
          size: 15,
        ),
      ],
    );
  }
}
