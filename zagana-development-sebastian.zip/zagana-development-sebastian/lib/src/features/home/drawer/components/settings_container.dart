import 'package:flutter/material.dart';
import 'package:zagana/src/core/widgets/widget_container_box_shadow.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';

class SettingsContainer extends StatelessWidget {
  final VoidCallback onPressed;
  final String settingsTitle;
  const SettingsContainer(
      {super.key, required this.onPressed, required this.settingsTitle});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onPressed,
      child: WidgetContainerBoxShadow(
        alpha: 0.01,
        blurRadius: 10,
        spreadRadius: 2,
        offSet: Offset(0, 10),
        borderRadius: BorderRadius.circular(8),
        children: Padding(
          padding: const EdgeInsets.all(24),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              WidgetText(
                text: settingsTitle,
                size: 12,
                weight: FontWeight.w600,
              ),
              Icon(
                Icons.arrow_forward_ios,
                size: 16,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
