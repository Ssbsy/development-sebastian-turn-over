import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_container_box_shadow.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';
import 'package:zagana/src/features/home/drawer/components/settings_container.dart';
import 'package:zagana/src/features/home/drawer/screens/about_screen.dart';
import 'package:zagana/src/features/home/drawer/screens/account_screen.dart';
import 'package:zagana/src/features/home/drawer/screens/emailsAddressAndPassword/email_and_password_screen.dart';
import 'package:zagana/src/features/home/drawer/screens/help_center_folder/help_center_screen.dart';
import 'package:zagana/src/features/home/drawer/screens/notifications.dart';
import 'package:zagana/src/features/home/drawer/screens/privacy_settings_screen.dart';
import 'package:zagana/src/features/home/drawer/screens/social_media_accounts_screen.dart';
import 'package:zagana/src/features/home/drawer/screens/user_feedbacks_screen.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: WidgetText(
          text: 'Settings',
          size: 14,
          weight: FontWeight.w600,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              myAccount(),
              Gap(12),
              mySettings(),
              Gap(12),
              mySupport(),
            ],
          ),
        ),
      ),
    );
  }

  myAccount() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        WidgetText(
          text: 'My Account',
          size: 14,
          weight: FontWeight.w600,
        ),
        Gap(12),
        SettingsContainer(
          onPressed: () {
            Get.to(() => AccountScreen());
          },
          settingsTitle: 'Account',
        ),
        Gap(12),
        SettingsContainer(
          onPressed: () {
            Get.to(() => (EmailAndPasswordScreen()));
          },
          settingsTitle: 'Email Address and Password',
        ),
        Gap(12),
        SettingsContainer(
          onPressed: () {
            Get.to(() => SocialMediaAccountsScreen());
          },
          settingsTitle: 'Social Media Accounts',
        ),
      ],
    );
  }

  mySettings() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        WidgetText(
          text: 'Settings',
          size: 14,
          weight: FontWeight.w600,
        ),
        Gap(12),
        SettingsContainer(
          onPressed: () {
            Get.to(() => Notifications());
          },
          settingsTitle: 'Notifications',
        ),
        Gap(12),
        SettingsContainer(
          onPressed: () {
            Get.to(() => PrivacySettingsScreen());
          },
          settingsTitle: 'Privacy',
        ),
      ],
    );
  }

  mySupport() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        WidgetText(
          text: 'Supports',
          size: 14,
          weight: FontWeight.w600,
        ),
        Gap(12),
        SettingsContainer(
          onPressed: () {
            Get.to(() => HelpCenterScreen());
          },
          settingsTitle: 'Help Center',
        ),
        Gap(12),
        SettingsContainer(
          onPressed: () {
            Get.to(() => AboutScreen());
          },
          settingsTitle: 'About',
        ),
        Gap(12),
        SettingsContainer(
          onPressed: () {
            Get.to(() => UserFeedbacksScreen());
          },
          settingsTitle: 'User Feedbacks',
        ),
      ],
    );
  }
}
