import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:zagana/src/features/home/dashboard/components/stack_circle_avatar.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_button.dart';
import 'package:zagana/src/core/widgets/widget_exit_dialog.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';
import 'package:zagana/src/features/auth/login/login_page.dart';
import 'package:zagana/src/features/home/drawer/pages/settings_page.dart';

class ProfileDrawer extends StatefulWidget {
  const ProfileDrawer({super.key});

  @override
  State<ProfileDrawer> createState() => _ProfileDrawerState();
}

class _ProfileDrawerState extends State<ProfileDrawer> {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      width: MediaQuery.sizeOf(context).width,
      child: Column(
        children: [
          Expanded(
            child: Column(
              children: [
                AppBar(
                  leading: SizedBox.shrink(),
                  backgroundColor: Palette.transparent,
                ),
                StackCircleAvatar(
                  onPressed: () {},
                  radius: 60,
                  showContainer: true,
                  iconAsset: Image.asset('assets/icons/zagana_icon.png'),
                  assetImage: 'assets/images/profile_image.jpg',
                ),
                Gap(12),
                WidgetText(
                  text: 'Juan Dela Cruz',
                  color: Palette.white,
                  size: 24,
                  weight: FontWeight.w600,
                ),
              ],
            ),
          ),
          Container(
            width: MediaQuery.sizeOf(context).width,
            decoration: BoxDecoration(
              color: Palette.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(18),
                topRight: Radius.circular(18),
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                children: [
                  listTile('Bronze', trailingText: '500.2 Points', () {}),
                  listTile('Rewards', () {}),
                  listTile('My Orders', () {}),
                  listTile('Saved Places', () {}),
                  listTile('Settings', () {
                    Get.to(() => SettingsPage());
                  }),
                  Gap(48),
                  WidgetButton(
                    text: 'Log out',
                    backgroundColor: Palette.red,
                    onPressed: () {
                      showAdaptiveDialog(
                        context: context,
                        builder: (context) {
                          return WidgetExitDialog(
                            title: 'Exit Application',
                            content: 'Are you sure you want to exit?',
                            continuePressed: () {
                              Get.offAll(() => LoginPage());
                            },
                          );
                        },
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  listTile(String? text, VoidCallback onTap, {String? trailingText}) {
    return Column(
      children: [
        ListTile(
          contentPadding: EdgeInsets.zero,
          title: WidgetText(
            text: text,
            size: 14,
          ),
          trailing: trailingText != null
              ? WidgetText(
                  text: trailingText,
                  color: Palette.primary,
                  size: 14,
                )
              : Icon(
                  Icons.arrow_forward_ios,
                  size: 14,
                ),
          onTap: onTap,
        ),
        Divider(),
      ],
    );
  }
}
