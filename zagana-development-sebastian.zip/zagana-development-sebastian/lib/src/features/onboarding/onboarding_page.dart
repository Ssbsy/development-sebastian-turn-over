import 'dart:async'; // For Timer
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_button.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';
import 'package:zagana/src/features/auth/login/login_page.dart';

class OnboardingPage extends StatefulWidget {
  const OnboardingPage({super.key});

  @override
  State<OnboardingPage> createState() => _OnboardingPageState();
}

class _OnboardingPageState extends State<OnboardingPage> {
  int _currentPage = 0;

  final List<String> _images = [
    'assets/images/purchase_image.png',
    'assets/images/track_image.png',
    'assets/images/delivery_image.png',
  ];

  final List<String> _titles = [
    'Purchase\nThe Products',
    'Track your\nOrders Anytime!',
    'And Get\nyour Order!'
  ];

  final List<String> _descriptions = [
    'Check the products you like and save for future reference.',
    'Track your delivery time to time.',
    'Get your fresh goods on time.',
  ];

  late Timer _timer;

  void _switchContent() {
    setState(() {
      _currentPage = (_currentPage + 1) % _images.length;
    });
  }

  @override
  void initState() {
    super.initState();

    _timer = Timer.periodic(const Duration(seconds: 5), (timer) {
      _switchContent();
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Palette.white,
      appBar: AppBar(
        backgroundColor: Palette.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  AnimatedSwitcher(
                    duration: const Duration(seconds: 1),
                    child: Center(
                      key: ValueKey<int>(_currentPage),
                      child: Image.asset(
                        height: 300,
                        _images[_currentPage],
                        isAntiAlias: true,
                        key: ValueKey<int>(_currentPage),
                      ),
                    ),
                  ),
                  Gap(24),
                  AnimatedSwitcher(
                    duration: const Duration(seconds: 1),
                    child: WidgetText(
                      key: ValueKey<int>(_currentPage),
                      text: _titles[_currentPage],
                      align: TextAlign.center,
                      size: 28,
                      weight: FontWeight.w600,
                    ),
                  ),
                  Gap(18),
                  AnimatedSwitcher(
                    duration: const Duration(seconds: 1),
                    child: WidgetText(
                      key: ValueKey<int>(_currentPage),
                      text: _descriptions[_currentPage],
                      color: Palette.gray,
                      align: TextAlign.center,
                      size: 14,
                    ),
                  ),
                ],
              ),
            ),
            WidgetButton(
              text: 'Get Started',
              onPressed: () {
                Get.off(() => LoginPage());
                _timer.cancel();
              },
            ),
          ],
        ),
      ),
    );
  }
}
