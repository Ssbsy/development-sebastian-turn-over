import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:zagana/src/core/constants/colors.dart';

class WidgetButton extends StatelessWidget {
  final String? text;
  final VoidCallback? onPressed;
  final Color? borderColor;
  final Color? backgroundColor;
  final IconData? icon;
  final Color? iconColor;
  final Color? textColor;
  final double? fontSize;
  final double? borderRadius;
  final String? imageAsset;
  final String? imageAssetTwo;
  final FontWeight? fontWeight;
  final double? iconSize;
  final MainAxisAlignment? mainAxisAlignment;
  final double? elevation;
  final Color? shadowColor;

  const WidgetButton({
    super.key,
    this.text,
    this.onPressed,
    this.backgroundColor,
    this.textColor,
    this.fontSize,
    this.borderRadius,
    this.fontWeight,
    this.borderColor,
    this.imageAsset,
    this.imageAssetTwo,
    this.icon,
    this.iconColor,
    this.iconSize,
    this.mainAxisAlignment,
    this.elevation,
    this.shadowColor,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 50,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          shape: RoundedRectangleBorder(
            side: BorderSide(
              color: borderColor ?? Palette.transparent,
            ),
            borderRadius: BorderRadius.circular(borderRadius ?? 25),
          ),
          elevation: elevation,
          shadowColor: shadowColor ?? Palette.transparent,
          backgroundColor: backgroundColor ?? Palette.primary,
        ),
        child: Row(
          mainAxisAlignment: mainAxisAlignment ?? MainAxisAlignment.center,
          children: [
            if (imageAsset != null && imageAsset!.isNotEmpty)
              Row(
                children: [
                  Image.asset(
                    imageAsset!,
                    height: 24,
                  ),
                  const Gap(8),
                ],
              ),
            if (icon != null)
              Row(
                children: [
                  Icon(
                    icon,
                    color: iconColor,
                    size: iconSize,
                  ),
                  const Gap(8),
                ],
              ),
            Text(
              text ?? '',
              style: TextStyle(
                fontFamily: 'Poppins',
                color: textColor ?? Palette.white,
                fontSize: fontSize ?? 14,
                fontWeight: fontWeight ?? FontWeight.w600,
              ),
            ),
            if (imageAssetTwo != null && imageAssetTwo!.isNotEmpty)
              Row(
                children: [
                  const Gap(8),
                  Image.asset(
                    imageAssetTwo!,
                    height: 24,
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }
}
