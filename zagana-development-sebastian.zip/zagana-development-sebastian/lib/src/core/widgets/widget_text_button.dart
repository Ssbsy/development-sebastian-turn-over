import 'package:flutter/material.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';

class WidgetTextButton extends StatelessWidget {
  final VoidCallback onPressed;
  final String text;
  const WidgetTextButton({super.key, required this.text, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return TextButton(
      onPressed: onPressed,
      child: WidgetText(
        text: text,
        color: Palette.primary,
        size: 12,
        weight: FontWeight.w500,
      ),
    );
  }
}
