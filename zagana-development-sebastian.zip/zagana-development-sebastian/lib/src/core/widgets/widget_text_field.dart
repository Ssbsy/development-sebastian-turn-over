import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:zagana/src/core/constants/colors.dart';

class WidgetTextField extends StatefulWidget {
  final String? hintText;
  final TextEditingController? controller;
  final TextInputType? keyboardType;
  final bool obscureText;
  final bool enabled;
  final Color? fillColor;
  final Color? borderColor;
  final Widget? prefixIcon;
  final IconButton? suffixIcon;
  final String? labelText;
  final String? prefixText;
  final String? Function(String?)? validator;
  final int? maxLength;
  final int? maxLines;
  final FocusNode? focusNode;
  final void Function(String)? onFieldSubmitted;
  final void Function(String)? onChanged;
  final List<TextInputFormatter>? inputFormatters;
  final bool enableSuggestions;
  final double? borderRadius;
  final Color? hintColor;
  final double? hintSize;
  final bool? isFilled;

  const WidgetTextField({
    this.hintText,
    this.controller,
    this.keyboardType,
    this.obscureText = false,
    this.enabled = true,
    this.prefixIcon,
    this.suffixIcon,
    this.labelText,
    this.prefixText,
    this.validator,
    this.focusNode,
    this.onFieldSubmitted,
    this.onChanged,
    this.maxLength,
    this.maxLines,
    this.fillColor,
    this.inputFormatters,
    this.enableSuggestions = true,
    super.key,
    this.borderColor,
    this.borderRadius,
    this.hintColor,
    this.hintSize,
    this.isFilled,
  });

  @override
  // ignore: library_private_types_in_public_api
  _WidgetTextFieldState createState() => _WidgetTextFieldState();
}

class _WidgetTextFieldState extends State<WidgetTextField> {
  bool _isPasswordVisible = false;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      cursorColor: Palette.primary,
      controller: widget.controller,
      keyboardType: widget.keyboardType,
      obscuringCharacter: '*',
      obscureText: widget.obscureText ? !_isPasswordVisible : false,
      maxLength: widget.maxLength,
      maxLines: widget.maxLines ?? 1,
      enabled: widget.enabled,
      style: const TextStyle(
        color: Palette.black,
        fontSize: 14,
      ),
      focusNode: widget.focusNode,
      onFieldSubmitted: widget.onFieldSubmitted,
      onChanged: widget.onChanged,
      inputFormatters: widget.inputFormatters,
      enableSuggestions: widget.enableSuggestions,
      decoration: InputDecoration(
        prefixIcon: widget.prefixIcon,
        hoverColor: Palette.primary,
        floatingLabelBehavior: FloatingLabelBehavior.never,
        counterText: '',
        prefixText: widget.prefixText,
        prefixStyle: const TextStyle(
          fontFamily: 'Roboto',
          color: Palette.black,
          fontSize: 14,
        ),
        hintText: widget.hintText,
        hintStyle: TextStyle(
          fontFamily: 'Roboto',
          color: widget.hintColor ?? Palette.black,
          fontSize: widget.hintSize ?? 14,
        ),
        filled: widget.isFilled,
        fillColor: widget.fillColor,
        suffixIcon: widget.keyboardType == TextInputType.visiblePassword
            ? IconButton(
                icon: Icon(
                  _isPasswordVisible ? Icons.visibility_off : Icons.visibility,
                ),
                onPressed: () {
                  setState(() {
                    _isPasswordVisible = !_isPasswordVisible;
                  });
                },
              )
            : widget.suffixIcon,
        labelText: widget.labelText,
        labelStyle: const TextStyle(
          fontFamily: 'Roboto',
          color: Palette.black,
          fontSize: 14,
        ),
        // border: OutlineInputBorder(
        //   borderSide: BorderSide(
        //     color: widget.borderColor ?? Palette.transparent,
        //   ),
        //   borderRadius: BorderRadius.circular(widget.borderRadius ?? 8),
        // ),
        // enabledBorder: OutlineInputBorder(
        //   borderSide: BorderSide(
        //     color: widget.borderColor ?? Palette.transparent,
        //   ),
        //   borderRadius: BorderRadius.circular(widget.borderRadius ?? 8),
        // ),
        // focusedBorder: OutlineInputBorder(
        //   borderSide: const BorderSide(
        //     color: Palette.primary,
        //   ),
        //   borderRadius: BorderRadius.circular(widget.borderRadius ?? 8),
        // ),
      ),
      validator: widget.validator,
    );
  }
}
