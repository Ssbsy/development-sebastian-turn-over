import 'package:flutter/material.dart';
import 'package:zagana/src/core/constants/colors.dart';

class WidgetText extends StatelessWidget {
  final String? text;
  final TextAlign? align;
  final Color? color;
  final String? family;
  final double? size;
  final FontWeight? weight;
  final TextDecoration? textDecoration;
  const WidgetText(
      {super.key,
      this.text,
      this.align,
      this.color,
      this.family,
      this.size,
      this.weight, this.textDecoration});

  @override
  Widget build(BuildContext context) {
    return Text(
      text ?? '',
      textAlign: align ?? TextAlign.start,
      style: TextStyle(
        color: color ?? Palette.black,
        fontFamily: family ?? 'Poppins',
        fontSize: size ?? 12,
        fontWeight: weight ?? FontWeight.normal,
        decoration: textDecoration,
      ),
    );
  }
}
