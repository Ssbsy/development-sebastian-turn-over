import 'package:flutter/material.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';

class WidgetExitDialog extends StatelessWidget {
  final String? title;
  final String? content;
  final VoidCallback continuePressed;
  const WidgetExitDialog({super.key, this.title, this.content, required this.continuePressed});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: WidgetText(
        text: title,
        size: 14,
        weight: FontWeight.w600,
      ),
      content: WidgetText(
        text: content,
      ),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.of(context).pop(false);
          },
          child: WidgetText(
            text: 'Back',
            color: Palette.primary,
          ),
        ),
        TextButton(
          onPressed: continuePressed,
          child: WidgetText(
            text: 'Continue',
            color: Palette.red,
          ),
        ),
      ],
    );
  }
}
