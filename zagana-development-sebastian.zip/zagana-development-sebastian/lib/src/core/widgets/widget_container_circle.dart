import 'package:flutter/material.dart';
import 'package:zagana/src/core/constants/colors.dart';
import 'package:zagana/src/core/widgets/widget_text.dart';

class WidgetContainerCircle extends StatefulWidget {
  final String? countText;
  const WidgetContainerCircle({super.key, this.countText});

  @override
  State<WidgetContainerCircle> createState() => _WidgetContainerCircleState();
}

class _WidgetContainerCircleState extends State<WidgetContainerCircle> {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(
          color: Palette.primary,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: WidgetText(
          text: '${widget.countText}x',
          weight: FontWeight.w600,
          size: 8,
        ),
      ),
    );
  }
}
