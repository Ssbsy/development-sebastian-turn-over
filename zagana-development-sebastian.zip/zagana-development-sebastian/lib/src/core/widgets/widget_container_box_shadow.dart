import 'package:flutter/material.dart';
import 'package:zagana/src/core/constants/colors.dart';

class WidgetContainerBoxShadow extends StatelessWidget {
  final BorderRadius? borderRadius;
  final Offset? offSet;
  final double? spreadRadius;
  final double? blurRadius;
  final double? alpha;
  final dynamic children;
  final double? width;
  final BoxShape? boxShape;
  const WidgetContainerBoxShadow(
      {super.key,
      required this.children,
      this.borderRadius,
      this.offSet,
      this.spreadRadius,
      this.blurRadius,
      this.alpha,
      this.width, this.boxShape});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      decoration: BoxDecoration(
        shape: boxShape ?? BoxShape.rectangle,
        color: Palette.white,
        borderRadius: borderRadius,
        boxShadow: [
          BoxShadow(
            offset: offSet ?? Offset.zero,
            spreadRadius: spreadRadius ?? 0.0,
            blurRadius: blurRadius ?? 0.0,
            color: Palette.black.withValues(alpha: alpha),
          ),
        ],
      ),
      child: children,
    );
  }
}
