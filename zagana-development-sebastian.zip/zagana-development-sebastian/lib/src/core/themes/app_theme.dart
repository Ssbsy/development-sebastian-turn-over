import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:zagana/src/core/constants/colors.dart';

class AppTheme {
  static ThemeData lightTheme() {
    SystemChrome.setPreferredOrientations(
      [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown],
    );
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: Palette.white,
        statusBarIconBrightness: Brightness.dark,
        systemNavigationBarColor: Palette.white,
        systemNavigationBarIconBrightness: Brightness.dark,
      ),
    );
    return ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: Palette.semiWhite,
      brightness: Brightness.light,
      colorScheme: ColorScheme.fromSeed(seedColor: Palette.primary),
      appBarTheme: AppBarTheme(
        centerTitle: true,
        backgroundColor: Palette.semiWhite,
        iconTheme: IconThemeData(color: Palette.black),
      ),
      tabBarTheme: TabBarTheme(
        overlayColor: WidgetStatePropertyAll(Palette.transparent),
        labelStyle: TextStyle(
          fontFamily: 'Roboto',
          fontSize: 18,
        ),
        unselectedLabelStyle: TextStyle(
          fontFamily: 'Roboto',
          fontSize: 18,
        ),
        dividerColor: Palette.transparent,
        indicatorSize: TabBarIndicatorSize.label,
        indicatorColor: Palette.secondary,
      ),
      datePickerTheme: DatePickerThemeData(
        backgroundColor: Palette.white,
        dividerColor: Palette.transparent,
      ),
      drawerTheme: DrawerThemeData(
        elevation: 0,
        backgroundColor: Palette.primary,
        shape: BeveledRectangleBorder(
          borderRadius: BorderRadius.circular(0),
        ),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: Palette.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
      dropdownMenuTheme: DropdownMenuThemeData(
        menuStyle: MenuStyle(
          backgroundColor: WidgetStatePropertyAll(Palette.white),
        ),
      ),
    );
  }
}
