import 'package:flutter/material.dart';

class Palette {
  static const Color transparent = Colors.transparent;
  static const Color primary = Color(0xFF2CB154);
  static const Color secondary = Color(0xFFF8CA2E);
  static const Color white = Color(0xFFFCFCFC);
  static const Color semiWhite = Color(0xFFF2F2F2);
  static const Color black = Color(0xFF1A1A1A);
  static const Color gray = Color(0xFF96969B);
  static const Color red = Color(0xFFE90000);
}
